const api = window.api;
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtSize = n => (n < 1024 ? `${n} o` : n < 1048576 ? `${(n / 1024).toFixed(0)} Ko` : `${(n / 1048576).toFixed(1)} Mo`);
const fmtDate = t => new Date(t).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
const fmtTime = t => {
  const d = new Date(t), now = new Date();
  return d.toDateString() === now.toDateString() ? d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : fmtDate(t);
};

// ---------- Icônes (trait, 24x24) ----------
const ICONS = {
  play: '<path d="M7 4.5v15l12-7.5z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
  restart: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
  external: '<path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  terminal: '<path d="M5 8l4 4-4 4"/><path d="M12 16h7"/>',
  code: '<path d="M9 7l-5 5 5 5"/><path d="M15 7l5 5-5 5"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8"/><path d="M4 4v4h4"/><path d="M4 13a8 8 0 0 0 14.3 4.9L20 16"/><path d="M20 20v-4h-4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  alert: '<path d="M12 3.5l9.5 16.5h-19z"/><path d="M12 10v4.5M12 17.5v.01"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.01"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="1.5"/><path d="M5 15V5a1 1 0 0 1 1-1h10"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5l8.5 6.5 8.5-6.5"/>',
  send: '<path d="M21 3L10 14"/><path d="M21 3l-7 18-4-7-7-4z"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/>',
  tablet: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M11 18h2"/>',
  phone: '<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/>',
  file: '<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/>',
  clip: '<path d="M21 11.5l-8.5 8.5a5 5 0 0 1-7-7L14 4.5a3.3 3.3 0 0 1 4.7 4.7L10.2 17.7a1.7 1.7 0 0 1-2.4-2.4L15.5 7.6"/>',
  power: '<path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  github: '<path d="M9 19c-4.3 1.4-4.3-2.5-6-3m12 5v-3.5c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.2 4.2 0 0 0-.1-3.2s-1.1-.3-3.5 1.3a12.3 12.3 0 0 0-6.2 0C6.5 2.8 5.4 3.1 5.4 3.1a4.2 4.2 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 9.5c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2V21"/>',
  bug: '<rect x="8" y="6" width="8" height="14" rx="4"/><path d="M19 7l-3 2M5 7l3 2M19 19l-3-2M5 19l3-2M20 13h-4M4 13h4M10 4l1 2M14 4l-1 2"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01"/>',
  server: '<rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="13" width="18" height="7" rx="1.5"/><path d="M7 7.5h.01M7 16.5h.01"/>',
  shield: '<path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
  wrench: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/>',
  archive: '<rect x="3" y="4" width="18" height="4" rx="1"/><path d="M5 8v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8M10 12h4"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.6 2.6 0 0 1 5 .8c0 1.7-2.5 2.2-2.5 3.7M12 17v.01"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v15H6a2 2 0 0 0-2 2z"/><path d="M4 20a2 2 0 0 0 2 2h13v-4"/><path d="M8 7h7M8 11h5"/>'
};
const icon = name => `<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]}</svg>`;

// ---------- État ----------
let state = { projects: [], servers: [], tools: {}, extraRoots: [], settings: {}, mail: {} };
let view = 'projects';
let selected = null;
const tabOf = new Map();          // path -> onglet affiché
const logs = new Map();           // path -> texte de la console
const messages = new Map();       // path -> dernier message d'erreur
const runningAction = new Map();  // path -> id de l'action en cours
const errorsCache = new Map();    // path -> { items, at }
let actionModal = null;
let follow = true;                // console : défilement automatique
let scanned = false;              // première détection terminée (sinon : squelette de chargement)
let panelKey = '';                // projet + onglet affichés : l'animation d'entrée ne se joue qu'au changement
let services = {};
const MAX_LOG = 200000;
const logView = { path: null, file: null, data: null, level: 'all', q: '', live: false, open: new Set() };
const mailState = { list: [], selected: null, detail: null, tab: 'preview', device: 'desktop', filter: '' };

const STATUS_LABEL = { stopped: 'Arrêté', starting: 'Démarrage', running: 'En cours', error: 'Erreur', external: 'Lancé à la main' };
const project = p => state.projects.find(x => x.path === p);
const externalUrl = p => (p && p.external && p.external.length ? `http://localhost:${p.external[0].port}` : null);
const isActive = p => p.status === 'running' || p.status === 'starting';

function apply(snap) {
  if (!snap || !snap.projects) return;
  state = snap;
  renderNav();
  renderStatusbar();
  renderList();
  if (view === 'projects') renderDetail();
}

// ---------- Thème ----------
function storedTheme() { try { return localStorage.getItem('theme'); } catch { return null; } }
function setTheme(t) {
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem('theme', t); } catch { /* stockage indisponible */ }
  $('#btn-theme').innerHTML = icon(t === 'dark' ? 'sun' : 'moon');
  $('#btn-theme').title = t === 'dark' ? 'Passer au thème clair' : 'Passer au thème sombre';
  if (typeof syncGuideTheme === 'function') syncGuideTheme();
}

// ---------- Chargements ----------
// Squelette : la forme du contenu attendu, animée, à la place d'un simple « Chargement... ».
function skeleton(kind = 'panel', label = '') {
  const line = (w, cls = '') => `<span class="sk sk-line ${cls}" style="width:${w}%"></span>`;
  let body;
  if (kind === 'list') body = Array.from({ length: 8 }, (_, i) => `<div class="sk-row"><span class="sk sk-dot"></span><div class="sk-col">${line(48 + (i * 17) % 40)}${line(30 + (i * 11) % 30, 'sm')}</div><span class="sk sk-pill"></span></div>`).join('');
  else if (kind === 'doc') body = `<div class="sk-doc">${line(36, 'lg')}${line(94)}${line(82)}${line(88)}${line(60)}<div class="sk-gap"></div>${line(28, 'lg')}${line(92)}${line(76)}${line(84)}</div>`;
  else body = [0, 1].map(i => `<div class="sk-card">${line(28, 'lg')}${line(92)}${line(74)}${line(84 - i * 22)}</div>`).join('');
  return `<div class="sk-wrap" aria-busy="true" aria-live="polite">${label ? `<div class="sk-label"><span class="spinner"></span>${esc(label)}</div>` : ''}${body}</div>`;
}

// Bouton en attente : roue + libellé, désactivé ; renvoie la fonction qui le rétablit.
function busyButton(btn, text) {
  if (!btn) return () => {};
  const html = btn.innerHTML, dis = btn.disabled;
  btn.disabled = true; btn.classList.add('is-busy');
  btn.innerHTML = `<span class="spinner"></span> ${esc(text)}`;
  return () => { if (!btn.isConnected) return; btn.innerHTML = html; btn.disabled = dis; btn.classList.remove('is-busy'); };
}

// Joue une animation d'entrée une seule fois (la classe est retirée à la fin pour pouvoir la rejouer).
function animateIn(el, cls = 'enter') {
  if (!el) return;
  el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls);
  el.addEventListener('animationend', () => el.classList.remove(cls), { once: true });
}

// ---------- Modales ----------
function openModal({ title, body, foot, wide = false, onClose }) {
  const overlay = document.createElement('div');
  overlay.className = 'overlay';
  overlay.innerHTML = `
    <div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="modal-head"><h2>${esc(title)}</h2><button class="btn ghost btn-icon sm" data-close title="Fermer">${icon('x')}</button></div>
      <div class="modal-body">${body}</div>
      ${foot ? `<div class="modal-foot">${foot}</div>` : ''}
    </div>`;
  const ctrl = {
    el: overlay, body: $('.modal-body', overlay), foot: $('.modal-foot', overlay),
    close() { overlay.remove(); document.removeEventListener('keydown', onKey); if (onClose) onClose(); }
  };
  const onKey = e => { if (e.key === 'Escape') ctrl.close(); };
  document.addEventListener('keydown', onKey);
  overlay.addEventListener('mousedown', e => { if (e.target === overlay) ctrl.close(); });
  overlay.addEventListener('click', e => { if (e.target.closest('[data-close]')) ctrl.close(); });
  $('#modal-root').appendChild(overlay);
  const focus = $('[data-autofocus]', overlay) || $('.modal-foot .btn:last-child', overlay);
  if (focus) focus.focus();
  return ctrl;
}

function confirmDialog({ title, message, detail = '', confirmLabel = 'Confirmer', danger = false }) {
  return new Promise(resolve => {
    let answered = false;
    const m = openModal({
      title, body: `<div>${message}</div>${detail}`,
      foot: `<button class="btn" data-close>Annuler</button><button class="btn ${danger ? 'danger' : 'primary'}" data-ok>${esc(confirmLabel)}</button>`,
      onClose: () => { if (!answered) resolve(false); }
    });
    $('[data-ok]', m.el).onclick = () => { answered = true; m.close(); resolve(true); };
  });
}

function actionDialog(p, a) {
  if (!a) return;
  if (runningAction.get(p.path)) return toast({ kind: 'warn', title: 'Action déjà en cours', text: 'Attends la fin de l\'action en cours sur ce projet.' });
  const m = openModal({
    title: a.label,
    body: `
      <div class="muted">${esc(p.name)} · ${esc(p.label)}</div>
      <div>${esc(a.desc)}</div>
      ${a.danger ? `<div class="alert error">${icon('alert')}<div class="grow"><b>Action destructrice.</b> Vérifie que tu es sur la bonne base de données (fichier .env du projet) avant de continuer.</div></div>` : ''}
      <div class="field"><label>Commande exécutée</label><div class="cmd">${esc(a.cmd)}</div></div>
      ${isDbAction(p, a) ? '<div data-target class="faint small"><span class="spinner" style="display:inline-block;vertical-align:middle"></span> Vérification du serveur MySQL du projet...</div>' : ''}
      ${a.danger ? `<label class="check"><input type="checkbox" data-ack> <span>Je comprends que les données concernées seront perdues.</span></label>` : ''}`,
    foot: `<button class="btn" data-close>Annuler</button>
           <button class="btn ${a.danger ? 'danger' : 'primary'}" data-run ${a.danger || isDbAction(p, a) ? 'disabled' : ''}>${icon('play')} Exécuter</button>`,
    onClose: () => { if (actionModal && actionModal.m === m) actionModal = null; }
  });
  const ack = $('[data-ack]', m.el);
  let targetOk = !isDbAction(p, a);
  const refreshRun = () => { $('[data-run]', m.el).disabled = !targetOk || (ack && !ack.checked); };
  if (ack) ack.onchange = refreshRun;
  if (isDbAction(p, a)) checkDbTarget(p, $('[data-target]', m.el), ok => { targetOk = ok; refreshRun(); }, force => start(force));
  const start = (force = false) => {
    $('.modal', m.el).classList.add('wide');
    m.body.innerHTML = `
      <div class="run-state" data-state><span class="spinner"></span> Exécution en cours...</div>
      <div class="cmd">${esc(a.cmd)}</div>
      <pre class="console" data-out></pre>`;
    m.foot.innerHTML = `<span class="grow">Tu peux fermer cette fenêtre : l'action continue et sa sortie reste dans la console du projet.</span>
      <button class="btn" data-close>Fermer</button>`;
    actionModal = { m, path: p.path, id: a.id, out: $('[data-out]', m.el), stateEl: $('[data-state]', m.el) };
    api.action(p.path, a.id, { force });
  };
  $('[data-run]', m.el).onclick = () => start(false);
}

const DB_ACTION_IDS = new Set(['migrate', 'status', 'seed', 'rollback', 'fresh']);
const isDbAction = (p, a) => p.type === 'laravel' && DB_ACTION_IDS.has(a.id);
const dbTargetCache = new Map(); // path -> résultat de api.dbTarget

// Affiche sur quel MySQL l'action va s'exécuter ; si ce n'est pas celui du serveur du projet, propose de basculer.
async function checkDbTarget(p, box, setOk, runWith) {
  let t;
  try { t = await api.dbTarget(p.path); } catch { t = { applicable: false }; }
  dbTargetCache.set(p.path, t);
  if (!box || !box.isConnected) return;
  if (!t.applicable) {
    box.innerHTML = t.remote ? `${icon('info')} Base distante (${esc(t.host)}) : exécution sur ce serveur.` : '';
    return setOk(true);
  }
  if (t.match) {
    box.className = 'hint-line ok';
    box.innerHTML = `${icon('check')} Exécution sur le MySQL de <b>${esc(t.listening && t.listening.type ? t.listening.type : 'ce poste')}</b> (port ${t.port}${t.database ? `, base ${esc(t.database)}` : ''}).`;
    return setOk(true);
  }
  setOk(false);
  box.className = '';
  const own = t.projectServer ? t.projectServer.type : null;
  const other = t.listening ? (t.listening.type || t.listening.name) : null;
  box.innerHTML = `<div class="alert error">${icon('alert')}<div class="grow">
    ${!t.running ? `<b>Aucun MySQL ne tourne sur le port ${t.port}.</b> Ce projet appartient à ${esc(own)} : démarre son MySQL pour exécuter l'action.`
      : `<b>Mauvais serveur MySQL.</b> Ce projet appartient à <b>${esc(own)}</b>, mais c'est le MySQL de <b>${esc(other)}</b> qui répond sur le port ${t.port}. L'action modifierait la base « ${esc(t.database)} » de ${esc(other)}.`}
    <div class="btns">
      ${own ? `<button class="btn sm primary" data-switch>${t.running ? `Basculer vers le MySQL de ${esc(own)} puis exécuter` : `Démarrer le MySQL de ${esc(own)} puis exécuter`}</button>` : ''}
      ${t.running ? `<button class="btn sm danger-outline" data-force-run>Exécuter quand même sur ${esc(other)}</button>` : ''}
    </div></div></div>`;
  const sw = $('[data-switch]', box);
  if (sw) sw.onclick = async () => {
    sw.disabled = true; sw.innerHTML = '<span class="spinner"></span> Bascule...';
    const r = await api.switchMysqlFor(p.path);
    if (r.ok) { toast({ kind: 'success', title: 'MySQL basculé', text: esc(r.message) }); dbTargetCache.delete(p.path); runWith(false); refreshServices(); }
    else { sw.disabled = false; sw.textContent = 'Réessayer'; box.insertAdjacentHTML('beforeend', `<div class="hint-line err">${icon('alert')} ${esc(r.message)}</div>`); }
  };
  const fr = $('[data-force-run]', box);
  if (fr) fr.onclick = () => runWith(true);
}

function finishBlockedModal(target) {
  const am = actionModal;
  if (!am) return;
  am.stateEl.className = 'run-state err';
  am.stateEl.innerHTML = `${icon('alert')} Action bloquée : le MySQL qui répond n'est pas celui du serveur du projet${target && target.projectServer ? ` (${esc(target.projectServer.type)})` : ''}.`;
  am.m.foot.innerHTML = '<button class="btn primary" data-close>Fermer</button>';
}

function finishActionModal(code) {
  const am = actionModal;
  if (!am) return;
  const ok = code === 0;
  am.stateEl.className = `run-state ${ok ? 'ok' : 'err'}`;
  am.stateEl.innerHTML = ok ? `${icon('check')} Terminé avec succès` : `${icon('alert')} Échec (code ${code}). Lis la sortie ci-dessous ou l'onglet Erreurs du projet.`;
  am.m.foot.innerHTML = `${ok ? '' : `<button class="btn" data-goto-errors>${icon('bug')} Voir les erreurs</button>`}<button class="btn primary" data-close>Fermer</button>`;
  const g = $('[data-goto-errors]', am.m.el);
  if (g) g.onclick = () => { const path = am.path; am.m.close(); select(path, 'errors'); };
}

function portDialog(p, field = 'port') {
  const current = p.config[field];
  const label = field === 'vitePort' ? 'Port de Vite' : 'Port du serveur';
  const m = openModal({
    title: `${label} · ${p.name}`,
    body: `
      <div class="field">
        <label for="port-input">${label}</label>
        <div class="inline">
          <input id="port-input" type="number" min="1" max="65535" value="${current}" data-autofocus>
          <button class="btn" data-suggest>Trouver un port libre</button>
        </div>
        <div class="hint-line" data-hint></div>
      </div>
      <div class="faint">Le projet sera accessible sur <span class="mono" data-preview>http://localhost:${current}</span></div>`,
    foot: `<button class="btn" data-close>Annuler</button><button class="btn primary" data-save>Enregistrer</button>`
  });
  const input = $('#port-input', m.el), hint = $('[data-hint]', m.el), save = $('[data-save]', m.el);
  let seq = 0;
  const check = async () => {
    const value = input.value;
    $('[data-preview]', m.el).textContent = `http://localhost:${value}`;
    if (Number(value) === current) { hint.className = 'hint-line faint'; hint.textContent = 'Port actuel.'; save.disabled = false; return; }
    const my = ++seq;
    hint.className = 'hint-line faint'; hint.innerHTML = '<span class="spinner"></span> Vérification...';
    const r = await api.portInfo(p.path, value);
    if (my !== seq) return;
    save.disabled = !r.ok;
    if (!r.ok) { hint.className = 'hint-line err'; hint.innerHTML = `${icon('alert')} ${esc(r.reason)}`; }
    else if (r.warn) { hint.className = 'hint-line warn'; hint.innerHTML = `${icon('alert')} ${esc(r.warn)}`; }
    else { hint.className = 'hint-line ok'; hint.innerHTML = `${icon('check')} Port libre.`; }
  };
  let t;
  input.oninput = () => { clearTimeout(t); t = setTimeout(check, 250); };
  input.onkeydown = e => { if (e.key === 'Enter' && !save.disabled) save.click(); };
  $('[data-suggest]', m.el).onclick = async () => {
    const port = await api.suggestPort(p.path, field === 'port' ? p.defaultPort : 5173);
    if (port) { input.value = port; check(); }
  };
  save.onclick = async () => {
    const value = Number(input.value);
    m.close();
    if (value === current) return;
    messages.delete(p.path);
    const snap = await api.setConfig(p.path, { [field]: value });
    apply(snap);
    portSavedToast(p, value, snap.envChanges);
  };
  check();
}

// Notification après un changement de port, avec les lignes du .env mises à jour automatiquement.
function portSavedToast(p, port, changes = []) {
  const ok = (changes || []).filter(c => !c.error);
  const err = (changes || []).find(c => c.error);
  const detail = ok.length ? `<br>Mis à jour automatiquement : ${ok.map(c => `<span class="mono">${esc(c.key)}</span>${c.file !== '.env' ? ` (${esc(c.file)})` : ''}`).join(', ')}` : '';
  toast({ kind: err ? 'warn' : 'success', title: 'Port enregistré', text: `${esc(p.name)} utilisera le port ${port}.${detail}${err ? `<br>.env non modifié : ${esc(err.error)}` : ''}`, timeout: ok.length ? 9000 : 5000 });
  if (ok.length && isActive(project(p.path) || p)) toast({ kind: 'info', title: 'Redémarre le projet', text: 'Le nouveau port et le .env seront pris en compte au prochain lancement.' });
}

// ---------- Paramètres ----------
function settingsDialog() {
  const s = state.settings;
  const row = (key, title, desc, extra = '') => `
    <div class="set-row"><div><div class="t">${title}</div><div class="s">${desc}</div></div>
      <label class="toggle"><input type="checkbox" data-set="${key}" ${s[key] ? 'checked' : ''} ${extra}><span class="track"></span></label></div>`;
  const m = openModal({
    title: 'Paramètres',
    body: `
      <div class="set-section"><h3>Au démarrage</h3>
        ${row('autostartWindows', 'Lancer DevLauncher avec Windows', state.canAutostart
          ? 'DevLauncher démarre à l\'ouverture de session : services et projets automatiques sont prêts sans rien lancer. Son icône apparaît près de l\'horloge.'
          : 'Disponible dans la version installée (DevLauncher-Setup).', state.canAutostart ? '' : 'disabled')}
        ${row('autostartShow', 'Ouvrir la fenêtre au démarrage de Windows', 'Désactivé : DevLauncher reste discret en arrière-plan (notification et icône près de l\'horloge pour l\'ouvrir).', state.canAutostart && s.autostartWindows ? '' : 'disabled')}
        ${row('startMysql', 'Démarrer MySQL automatiquement', 'Démarre le MySQL de XAMPP / Laragon / WAMP à l\'ouverture de DevLauncher s\'il est arrêté.')}
        ${row('startApache', 'Démarrer Apache automatiquement', 'Utile pour phpMyAdmin et les sites servis directement par Apache.')}
        ${row('keepRunning', 'Garder les serveurs actifs fenêtre fermée', 'Fermer la fenêtre n\'arrête plus les projets. Quitte DevLauncher avec le bouton ci-dessous.')}
        <div class="faint small" style="padding-top:8px">Pour lancer un projet automatiquement, active « Lancer automatiquement » dans sa vue d'ensemble.</div>
      </div>
      <div class="set-section"><h3>Mails de test</h3>
        ${row('mailCapture', 'Intercepter les mails des projets', 'Les mails envoyés par les projets lancés depuis DevLauncher arrivent dans la boîte de test au lieu d\'être envoyés.')}
        <div class="set-row"><div><div class="t">Port SMTP de la boîte de test</div><div class="s" data-smtp-hint>${state.mail.error ? esc(state.mail.error) : `Actif sur 127.0.0.1:${state.mail.port}`}</div></div>
          <div class="inline" style="display:flex;gap:6px"><input type="number" min="1024" max="65535" value="${s.smtpPort}" data-smtp style="width:96px" class="mono"><button class="btn sm" data-smtp-save>Appliquer</button></div></div>
      </div>`,
    foot: `<button class="btn danger-outline" data-quit>${icon('power')} Quitter DevLauncher</button><span class="grow"></span><button class="btn primary" data-close>Fermer</button>`
  });
  $$('[data-set]', m.el).forEach(inp => {
    inp.onchange = async () => {
      try {
        apply(await api.setSettings({ [inp.dataset.set]: inp.checked }));
        toast({ kind: 'success', title: 'Paramètre enregistré', text: esc($('.t', inp.closest('.set-row')).textContent), timeout: 2500 });
      } catch (err) {
        inp.checked = !inp.checked;
        toast({ kind: 'error', title: 'Impossible d\'appliquer', text: esc(err.message) });
      }
    };
  });
  $('[data-smtp-save]', m.el).onclick = async () => {
    try {
      apply(await api.setSettings({ smtpPort: Number($('[data-smtp]', m.el).value) }));
      $('[data-smtp-hint]', m.el).textContent = state.mail.error || `Actif sur 127.0.0.1:${state.mail.port}`;
    } catch (err) { toast({ kind: 'error', title: 'Port SMTP refusé', text: esc(err.message) }); }
  };
  $('[data-quit]', m.el).onclick = async () => {
    const ok = await confirmDialog({ title: 'Quitter DevLauncher', message: 'Tous les projets lancés par DevLauncher seront arrêtés.', detail: '<div class="faint">MySQL et Apache continuent de tourner.</div>', confirmLabel: 'Quitter', danger: true });
    if (ok) { await api.quitApp(); document.body.innerHTML = '<div class="empty"><div><h2>DevLauncher est fermé</h2><div>Tu peux fermer cette fenêtre.</div></div></div>'; }
  };
}

function aboutDialog() {
  openModal({
    title: 'À propos',
    body: `
      <div class="about">
        <img src="logo.svg" width="84" height="84" alt="">
        <h2>DevLauncher</h2>
        <div class="faint">Version ${esc(state.version || '')}</div>
        <div style="margin-top:6px">Lance, surveille et débogue tes projets web locaux.</div>
        <div class="tricolor" style="width:120px;margin:10px 0 6px"><i></i><i></i><i></i></div>
        <div>Conçu et développé par <b>Hilaire AINADOU</b></div>
        <div class="muted"><b>Novatech Solution</b> · Abomey-Calavi, Bénin</div>
        <div class="links">
          <button class="btn sm" data-url="https://novatechbenin.com">${icon('globe')} novatechbenin.com</button>
          <button class="btn sm" data-url="https://github.com/hilairesevnainadou-gif">${icon('github')} GitHub</button>
        </div>
        <div class="faint small" style="margin-top:12px">© 2026 Novatech Solution. Tous droits réservés.</div>
      </div>`,
    foot: '<button class="btn primary" data-close>Fermer</button>'
  }).el.addEventListener('click', e => { const b = e.target.closest('[data-url]'); if (b) api.openUrl(b.dataset.url); });
}

// ---------- Notifications ----------
function toast({ kind = 'info', title, text, onClick, timeout = 7000 }) {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.innerHTML = `<div class="grow"><div class="title">${esc(title)}</div><div class="muted">${text || ''}</div></div>
    <button class="btn ghost btn-icon sm" title="Fermer">${icon('x')}</button>`;
  $('button', el).onclick = e => { e.stopPropagation(); el.remove(); };
  if (onClick) { el.style.cursor = 'pointer'; el.onclick = () => { onClick(); el.remove(); }; }
  $('#toasts').appendChild(el);
  while ($('#toasts').children.length > 4) $('#toasts').firstChild.remove();
  setTimeout(() => el.remove(), timeout);
}

// ---------- Navigation & barre d'état ----------
function renderNav() {
  const unread = (state.mail && state.mail.unread) || 0;
  $('[data-view="projects"]').innerHTML = `${icon('list')} Projets`;
  $('[data-view="mail"]').innerHTML = `${icon('mail')} Boîte mail ${unread ? `<span class="badge">${unread}</span>` : ''}`;
  const problems = serverState.diag ? serverState.diag.reduce((n, d) => n + ['mysql', 'apache'].reduce((m, k) => m + (d[k] && d[k].running && d[k].issues.length ? 1 : 0), 0), 0) : 0;
  $('[data-view="server"]').innerHTML = `${icon('server')} Serveur ${problems ? `<span class="badge danger">${problems}</span>` : ''}`;
  $('[data-view="guide"]').innerHTML = `${icon('help')} Aide`;
}

function setView(v) {
  const changed = view !== v;
  view = v;
  $$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === v));
  for (const id of ['projects', 'mail', 'server', 'guide']) $(`#view-${id}`).hidden = v !== id;
  if (changed) animateIn($(`#view-${v}`), 'view-enter');
  $('#btn-add').hidden = $('#btn-scan').hidden = v !== 'projects';
  renderBanner();
  if (v === 'mail') loadMails();
  else if (v === 'server') loadServer();
  else if (v === 'guide') renderGuide();
  else renderDetail();
}
$('#nav').addEventListener('click', e => { const b = e.target.closest('[data-view]'); if (b) setView(b.dataset.view); });

function renderStatusbar() {
  // Avant la première détection : pas de faux « introuvable », juste l'indication que la recherche est en cours.
  if (!scanned) { $('#statusbar').innerHTML = '<span class="item grow"><span class="spinner"></span> Recherche des serveurs locaux, de PHP, Composer et Node.js...</span>'; return; }
  const t = state.tools;
  const tool = (name, p, extra = '') => `<span class="item" title="${esc(p || 'Introuvable')}"><span class="${p ? 'ok' : 'ko'}">${icon(p ? 'check' : 'x')}</span>${name}${extra}</span>`;
  const serversTxt = state.servers.length ? state.servers.map(s => `${s.type} : ${s.root}`).join('   ·   ') : 'Aucun serveur local détecté';
  const phps = (t.phps || []).map(x => x.version).join(', ');
  const svc = name => {
    const s = services[name];
    if (!s || (!s.available && !s.running)) return '';
    return `<span class="item" title="${esc(s.server || '')} · port ${s.port}"><span class="dot ${s.running ? 'running' : ''}"></span>${s.label} ${s.running ? '' : `<button class="btn" data-service="${name}">Démarrer</button>`}</span>`;
  };
  const mail = state.mail || {};
  $('#statusbar').innerHTML = `
    <span class="item grow" title="${esc(serversTxt)}">${esc(serversTxt)}</span>
    ${tool('PHP', t.php, phps ? ` <span class="faint">${esc(phps)}</span>` : '')}
    ${tool('Composer', t.composer)}
    ${tool('Node', t.node)}
    <span class="sep"></span>
    ${svc('apache')}${svc('mysql')}
    <span class="item" title="${esc(mail.error || 'Boîte de test des mails')}"><span class="dot ${mail.running ? 'running' : 'error'}"></span>Mails ${mail.running ? `<span class="faint">:${mail.port}</span>` : '<span class="faint">arrêtée</span>'}</span>`;
}
$('#statusbar').addEventListener('click', async e => {
  const b = e.target.closest('[data-service]');
  if (!b) return;
  b.disabled = true; b.textContent = 'Démarrage...';
  const st = await api.startService(b.dataset.service);
  services[b.dataset.service] = st;
  renderStatusbar();
  toast(st.running ? { kind: 'success', title: `${st.label} démarré`, text: `Écoute sur le port ${st.port}.` }
    : { kind: 'error', title: `${st.label} n'a pas démarré`, text: 'Démarre-le depuis le panneau de ton serveur local (XAMPP, Laragon...) pour voir l\'erreur.' });
});
async function refreshServices() {
  const s = await api.services();
  if (JSON.stringify(s) !== JSON.stringify(services)) { services = s; renderStatusbar(); }
}

// ---------- Liste des projets ----------
function matchesFilter(p) {
  const q = $('#search').value.trim().toLowerCase();
  if (q && !`${p.name} ${p.label} ${p.rel || ''}`.toLowerCase().includes(q)) return false;
  const f = $('#filter').value;
  if (!f) return true;
  if (f === 'running') return ['running', 'starting', 'external'].includes(p.status);
  if (f === 'external') return p.status === 'external';
  if (f === 'react') return p.type === 'cra' || p.label.includes('React');
  if (f === 'other') return !['laravel', 'next', 'nuxt', 'cra'].includes(p.type) && !p.label.includes('React');
  return p.type === f;
}

function renderBanner() {
  const ext = state.projects.filter(p => p.status === 'external');
  const el = $('#banner');
  el.hidden = !ext.length || view !== 'projects';
  if (el.hidden) return;
  el.innerHTML = `${icon('info')}<span>${ext.length} projet${ext.length > 1 ? 's' : ''} lancé${ext.length > 1 ? 's' : ''} en dehors de DevLauncher :</span> ` +
    `<span class="notice-items">${ext.map(p => `<button class="link notice-chip" data-select="${esc(p.path)}">${esc(p.name)} <span class="mono">:${(p.external || []).map(e => e.port).join(', :')}</span></button>`).join('')}</span>`;
}

// Logo du framework d'un projet détecté (type + libellé : « Vite · React », « Node · Express »...).
function projectLogo(p) {
  const t = p.type, l = String(p.label || '').toLowerCase();
  const id = { laravel: 'laravel', next: 'next', nuxt: 'nuxt', angular: 'angular', astro: 'astro', php: 'php', cra: 'react', vuecli: 'vue' }[t]
    || (t === 'vite' && (/svelte/.test(l) ? 'svelte' : /vue/.test(l) ? 'vue' : /react|remix/.test(l) ? 'react' : null))
    || (t === 'node' && /express/.test(l) ? 'express' : null);
  if (!id && t === 'static') return `<svg class="fw-logo row-logo" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="#e34f26" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></g></svg>`;
  return id ? window.logoSvg(id, 'row-logo') : '';
}

function renderList() {
  renderBanner();
  const visible = state.projects.filter(matchesFilter);
  const running = state.projects.filter(p => isActive(p) || p.status === 'external').length;
  $('#counts').textContent = !scanned ? '' : `${visible.length} projet${visible.length > 1 ? 's' : ''}${running ? ` · ${running} en cours` : ''}`;
  const groups = new Map();
  for (const p of visible) {
    if (!groups.has(p.root)) groups.set(p.root, []);
    groups.get(p.root).push(p);
  }
  if (!groups.size) {
    $('#list').innerHTML = !scanned ? skeleton('list', 'Recherche des serveurs et des projets...')
      : '<div class="faint" style="padding:24px 12px;text-align:center">Aucun projet ne correspond.</div>';
    return;
  }
  let html = '';
  for (const [root, items] of groups) {
    const removable = state.extraRoots.includes(root);
    html += `<div class="group"><span title="${esc(root)}">${esc(root)}</span>` +
      (removable ? `<button class="btn ghost sm" data-remove-root="${esc(root)}">Retirer</button>` : '') + '</div>';
    for (const p of items) {
      const action = isActive(p)
        ? `<button class="btn ghost btn-icon sm" data-stop="${esc(p.path)}" title="Arrêter">${icon('stop')}</button>`
        : p.status === 'external'
          ? `<button class="btn ghost btn-icon sm" data-open="${esc(p.path)}" title="Ouvrir dans le navigateur">${icon('external')}</button>`
          : `<button class="btn ghost btn-icon sm" data-start="${esc(p.path)}" title="Lancer">${icon('play')}</button>`;
      const port = p.status === 'external' ? p.external[0].port : p.config.port;
      html += `
      <div class="row-item ${p.path === selected ? 'selected' : ''}" data-path="${esc(p.path)}">
        <span class="dot ${p.status}" title="${STATUS_LABEL[p.status]}"></span>
        <div style="min-width:0">
          <div class="name">${projectLogo(p)}<span class="nm">${esc(p.name)}</span></div>
          <div class="sub">${esc(p.label)}${p.rel ? ` · ${esc(p.rel)}` : p.discovered || p.root === 'Ajoutés manuellement' ? ` · ${esc(p.path.replace(/\\[^\\]+$/, ''))}` : ''}</div>
        </div>
        <span class="port mono ${p.conflict ? 'conflict' : ''}" title="${p.conflict ? 'Port en conflit avec un autre projet' : 'Port'}">:${port}</span>
        ${action}
      </div>`;
    }
  }
  $('#list').innerHTML = html;
}

function select(path, tab) {
  if (view !== 'projects') setView('projects');
  selected = path;
  if (tab) tabOf.set(path, tab);
  renderList();
  renderDetail();
  loadErrors(path);
  loadDbTarget(path);
}

// Vérifie en arrière-plan que le MySQL qui répond est celui du serveur du projet (alerte dans la vue d'ensemble).
async function loadDbTarget(path) {
  const p = project(path);
  if (!p || p.type !== 'laravel') return;
  try { dbTargetCache.set(path, await api.dbTarget(path)); } catch { return; }
  const t = dbTargetCache.get(path);
  if (path === selected && view === 'projects' && t.applicable && !t.match && (tabOf.get(path) || 'overview') === 'overview') renderDetail();
}

$('#list').addEventListener('click', async e => {
  const b = e.target.closest('button');
  if (b && b.dataset.start) return startProject(b.dataset.start);
  if (b && b.dataset.stop) return api.stop(b.dataset.stop);
  if (b && b.dataset.open) return api.openUrl(externalUrl(project(b.dataset.open)));
  if (b && b.dataset.removeRoot) {
    const ok = await confirmDialog({ title: 'Retirer le dossier', message: `Ne plus scanner <span class="mono">${esc(b.dataset.removeRoot)}</span> ?`, detail: '<div class="faint">Les fichiers ne sont pas supprimés.</div>', confirmLabel: 'Retirer' });
    if (ok) apply(await api.removeRoot(b.dataset.removeRoot));
    return;
  }
  const item = e.target.closest('.row-item');
  if (item) select(item.dataset.path);
});
$('#banner').addEventListener('click', e => { const b = e.target.closest('[data-select]'); if (b) select(b.dataset.select); });
$('#search').addEventListener('input', renderList);
$('#filter').addEventListener('change', renderList);

function startProject(path) {
  messages.delete(path);
  const p = project(path);
  if (p && p.status === 'external') return select(path);
  api.start(path);
}

// ---------- Détail d'un projet ----------
const TABS = [['overview', 'Vue d\'ensemble'], ['console', 'Console'], ['errors', 'Erreurs'], ['logs', 'Logs'], ['database', 'Base de données'], ['seeders', 'Seeders'], ['queue', 'File d\'attente'], ['uml', 'Diagrammes UML']];
// Onglets qui gèrent eux-mêmes leur défilement (console, listes, éditeur) ; les autres défilent avec la page.
const FILL_TABS = new Set(['console', 'errors', 'logs', 'uml']);
const tabsFor = p => TABS.filter(([id]) => !['database', 'seeders', 'queue'].includes(id) || p.type === 'laravel');

function renderDetail() {
  const p = project(selected);
  const el = $('#detail');
  if (!p) {
    el.innerHTML = `<div class="empty"><div><img src="logo.svg" width="56" height="56" alt=""><h2>Aucun projet sélectionné</h2><div>Choisis un projet dans la liste pour le lancer, lire ses erreurs et ses logs.</div></div></div>`;
    return;
  }
  const active = isActive(p);
  const ext = p.status === 'external' && p.external && p.external.length ? p.external : null;
  const tab = tabOf.get(p.path) || 'overview';
  const errs = errorsCache.get(p.path);
  const errCount = errs ? errs.items.length : 0;
  const primary = active
    ? `<button class="btn" id="d-restart">${icon('restart')} Redémarrer</button><button class="btn danger" id="d-stop">${icon('stop')} Arrêter</button>`
    : ext ? `<button class="btn" id="x-open-top">${icon('external')} Ouvrir</button>` : `<button class="btn primary" id="d-start">${icon('play')} Lancer</button>`;

  el.innerHTML = `
    <div class="d-header">
      <div style="min-width:0">
        <div class="d-title"><h1>${esc(p.name)}</h1><span class="pill ${p.status}"><span class="dot ${p.status}"></span>${STATUS_LABEL[p.status]}</span></div>
        <div class="d-meta">
          <span>${esc(p.label)}</span>
          ${p.phpVersion ? `<span class="sep">|</span><span title="${esc(p.php)}">PHP ${esc(p.phpVersion)}</span>` : ''}
          <span class="sep">|</span><span class="mono" title="${esc(p.path)}">${esc(p.path)}</span>
        </div>
      </div>
      <div class="d-actions">
        <button class="btn btn-icon" id="d-folder" title="Ouvrir le dossier">${icon('folder')}</button>
        <button class="btn btn-icon" id="d-term" title="Ouvrir un terminal dans le projet">${icon('terminal')}</button>
        <button class="btn btn-icon" id="d-code" title="Ouvrir dans VS Code">${icon('code')}</button>
        ${p.discovered || p.root === 'Ajoutés manuellement' ? `<button class="btn btn-icon" id="d-forget" title="Retirer ce projet de la liste (les fichiers ne sont pas touchés)">${icon('trash')}</button>` : ''}
        ${primary}
      </div>
    </div>
    <div class="tabs">${tabsFor(p).map(([id, label]) => `<button class="tab ${tab === id ? 'active' : ''}" data-tab="${id}">${label}${id === 'errors' && errCount ? ` <span class="badge danger">${errCount}</span>` : ''}</button>`).join('')}<span class="grow"></span>${helpBtn(TAB_HELP[tab] || 'lancer')}</div>
    <div class="panel ${FILL_TABS.has(tab) ? 'fill' : ''}" id="panel"></div>`;

  const on = (sel, fn) => { const b = $(sel, el); if (b) b.onclick = fn; };
  on('#d-start', () => startProject(p.path));
  on('#d-stop', () => api.stop(p.path));
  on('#d-restart', () => { messages.delete(p.path); api.restart(p.path); });
  on('#x-open-top', () => api.openUrl(externalUrl(p)));
  on('#d-folder', () => api.openFolder(p.path));
  on('#d-term', () => api.openTerminal(p.path).catch(err => toast({ kind: 'error', title: 'Terminal impossible à ouvrir', text: esc(err.message) })));
  on('#d-code', () => api.openEditor(p.path));
  on('#d-forget', async () => {
    const ok = await confirmDialog({ title: 'Retirer de la liste', message: `Retirer <b>${esc(p.name)}</b> de DevLauncher ?`,
      detail: `<div class="faint">Le dossier <span class="mono">${esc(p.path)}</span> n'est pas supprimé.${p.discovered ? ' Il ne sera plus ajouté automatiquement quand il tourne.' : ''}</div>`, confirmLabel: 'Retirer' });
    if (!ok) return;
    selected = null;
    apply(await api.forgetProject(p.path));
  });
  $$('[data-tab]', el).forEach(b => { b.onclick = () => { tabOf.set(p.path, b.dataset.tab); renderDetail(); }; });

  const panel = $('#panel', el);
  if (panelKey !== p.path + '|' + tab) { panelKey = p.path + '|' + tab; animateIn(panel, 'panel-enter'); }
  if (tab === 'overview') renderOverview(p, panel);
  else if (tab === 'console') renderConsole(p, panel);
  else if (tab === 'errors') renderErrors(p, panel);
  else if (tab === 'database' && p.type === 'laravel') renderDatabase(p, panel);
  else if (tab === 'uml') renderUml(p, panel);
  else if (tab === 'queue' && p.type === 'laravel') renderQueue(p, panel);
  else if (tab === 'seeders' && p.type === 'laravel') renderSeeders(p, panel);
  else renderLogs(p, panel);
}

// ---------- Seeders (Laravel) : fichiers, code, sélection ordonnée et exécution ----------
const seedState = { path: null, data: null, order: [], preview: null };
let seedModal = null;

async function renderSeeders(p, panel) {
  if (seedState.path !== p.path) {
    Object.assign(seedState, { path: p.path, data: null, order: [], preview: null });
    panel.innerHTML = `<div class="panel-body">${skeleton('panel', 'Lecture des seeders du projet...')}</div>`;
  }
  try { seedState.data = await api.seedersList(p.path); }
  catch (err) { panel.innerHTML = `<div class="empty"><div><h2>Seeders illisibles</h2><div>${esc(err.message)}</div></div></div>`; return; }
  if (selected !== p.path || tabOf.get(p.path) !== 'seeders') return;
  const d = seedState.data;
  if (!d.seeders.length) {
    panel.innerHTML = `<div class="empty"><div>${icon('list')}<h2>Aucun seeder</h2><div>Ce projet n'a pas de dossier <span class="mono">database/seeders</span>. Un seeder se crée avec <span class="mono">php artisan make:seeder NomSeeder</span>.</div></div></div>`;
    return;
  }
  const byClass = new Map(d.seeders.map(s => [s.class, s]));
  seedState.order = seedState.order.filter(c => byClass.has(c));
  if (!seedState.preview) seedState.preview = (d.seeders.find(s => !s.main) || d.seeders[0]).file;
  const pos = c => seedState.order.indexOf(c);
  const item = s => {
    const i = pos(s.class), on = i >= 0;
    return `<div class="seed-item ${on ? 'on' : ''} ${seedState.preview === s.file ? 'cur' : ''}" data-file="${esc(s.file)}">
      <label class="seed-check" title="${s.main ? 'DatabaseSeeder lance les autres seeders dans son ordre' : 'Inclure dans la sélection'}">
        <input type="checkbox" data-seed="${esc(s.class)}" ${on ? 'checked' : ''}><span class="seed-num">${on ? i + 1 : ''}</span></label>
      <div class="seed-text">
        <b>${esc(s.class)}${s.main ? ' <span class="pill">principal</span>' : ''}</b>
        <span>${s.main ? `Lance ${s.calls.length} seeder${s.calls.length > 1 ? 's' : ''} : ${esc(s.calls.join(', ') || 'aucun')}` : `Remplit : ${esc(s.fills.join(', ') || 'non déterminé')}`}</span>
        <span class="faint">${s.position ? `Appelé par DatabaseSeeder en ${s.position}${s.position === 1 ? 'er' : 'e'}` : s.main ? esc(s.file) : 'Non appelé par DatabaseSeeder'} · ${s.lines} lignes</span>
      </div>
      ${on && !s.main ? `<div class="seed-move"><button class="btn ghost btn-icon sm" data-up="${esc(s.class)}" title="Plus tôt" ${i === 0 ? 'disabled' : ''}>▲</button><button class="btn ghost btn-icon sm" data-down="${esc(s.class)}" title="Plus tard" ${i === seedState.order.length - 1 ? 'disabled' : ''}>▼</button></div>` : ''}
    </div>`;
  };
  const n = seedState.order.length;
  // Affichage : DatabaseSeeder, puis la sélection dans son ordre d'exécution, puis les autres seeders.
  const ordered = [...d.seeders.filter(s => s.main), ...seedState.order.map(c => byClass.get(c)).filter(s => s && !s.main), ...d.seeders.filter(s => !s.main && !seedState.order.includes(s.class))];
  panel.innerHTML = `<div class="panel-body seed-wrap">
    <div class="toolbar seed-bar">
      <div class="seg"><button data-preset="default" title="Sélectionne les seeders appelés par DatabaseSeeder, dans le même ordre">Ordre de DatabaseSeeder</button><button data-preset="none">Tout décocher</button></div>
      <span class="grow"></span>
      <button class="btn" data-run-main ${byClass.has('DatabaseSeeder') ? '' : 'disabled'} title="php artisan db:seed">${icon('play')} Tout lancer (DatabaseSeeder)</button>
      <button class="btn primary" data-run-sel ${n ? '' : 'disabled'}>${icon('play')} Lancer la sélection${n ? ` (${n})` : ''}</button>
    </div>
    <div class="seed-cols">
      <div class="seed-list">${ordered.map(item).join('')}</div>
      <div class="seed-code card"><div class="card-head"><h3>${icon('file')} <span data-code-name></span></h3><button class="btn sm" data-edit>${icon('code')} Ouvrir dans l'éditeur</button></div><pre class="console seed-pre" data-code></pre></div>
    </div>
    <div class="faint small">Coche des seeders pour les lancer dans l'ordre affiché (numéros) ; les flèches changent l'ordre. Dossier : <span class="mono">${esc(d.dir)}</span></div>
  </div>`;
  const loadCode = async file => {
    seedState.preview = file;
    $$('.seed-item', panel).forEach(x => x.classList.toggle('cur', x.dataset.file === file));
    $('[data-code-name]', panel).textContent = file;
    try { $('[data-code]', panel).textContent = (await api.seederRead(p.path, file)).text; }
    catch (err) { $('[data-code]', panel).textContent = err.message; }
  };
  loadCode(seedState.preview);
  $$('.seed-item', panel).forEach(el => el.addEventListener('click', e => { if (!e.target.closest('label, button')) loadCode(el.dataset.file); }));
  $$('[data-seed]', panel).forEach(c => { c.onchange = () => {
    const cls = c.dataset.seed;
    if (c.checked && !seedState.order.includes(cls)) seedState.order.push(cls);
    if (!c.checked) seedState.order = seedState.order.filter(x => x !== cls);
    renderSeeders(p, panel);
  }; });
  const move = (cls, dir) => { const i = seedState.order.indexOf(cls), j = i + dir; if (j < 0 || j >= seedState.order.length) return; [seedState.order[i], seedState.order[j]] = [seedState.order[j], seedState.order[i]]; renderSeeders(p, panel); };
  $$('[data-up]', panel).forEach(b => { b.onclick = () => move(b.dataset.up, -1); });
  $$('[data-down]', panel).forEach(b => { b.onclick = () => move(b.dataset.down, 1); });
  $$('[data-preset]', panel).forEach(b => { b.onclick = () => { seedState.order = b.dataset.preset === 'default' ? [...d.order] : []; renderSeeders(p, panel); }; });
  $('[data-edit]', panel).onclick = () => api.openFile(p.path + '\\' + seedState.preview.replace(/\//g, '\\'));
  $('[data-run-sel]', panel).onclick = () => seedDialog(p, [...seedState.order]);
  $('[data-run-main]', panel).onclick = () => seedDialog(p, ['DatabaseSeeder']);
}

function seedDialog(p, list) {
  const m = openModal({
    title: list.length === 1 && list[0] === 'DatabaseSeeder' ? 'Lancer DatabaseSeeder' : `Lancer ${list.length} seeder${list.length > 1 ? 's' : ''}`,
    wide: true,
    body: `<div class="muted">${esc(p.name)} · dans cet ordre :</div>
      <ol class="create-steps seed-steps" data-steps>${list.map(c => `<li class="st-todo"><span class="st-i"></span>${esc(c)}<span class="st-time"></span></li>`).join('')}</ol>
      <div class="alert warn">${icon('alert')}<div class="grow">Les seeders <b>ajoutent des données</b> dans la base du projet. Relancer un seeder déjà exécuté peut créer des doublons, sauf s'il utilise firstOrCreate / updateOrCreate.</div></div>
      <div data-target class="faint small"><span class="spinner" style="display:inline-block;vertical-align:middle"></span> Vérification du serveur MySQL du projet...</div>
      <pre class="console create-console" data-out hidden></pre>`,
    foot: `<button class="btn" data-close>Annuler</button><button class="btn primary" data-go disabled>${icon('play')} Lancer</button>`,
    onClose: () => { if (seedModal && seedModal.m === m) seedModal = null; }
  });
  const go = $('[data-go]', m.el);
  let ok = false;
  checkDbTarget(p, $('[data-target]', m.el), v => { ok = v; go.disabled = !v; }, force => start(force));
  const start = async (force = false) => {
    go.disabled = true;
    const out = $('[data-out]', m.el);
    out.hidden = false; out.textContent = '';
    seedModal = { m, path: p.path, out, list, started: Date.now() };
    $('[data-target]', m.el).remove();
    m.foot.innerHTML = '<span class="grow faint small">Tu peux fermer : l\'exécution continue (sortie dans la Console du projet).</span><button class="btn" data-close>Fermer</button>';
    try {
      const r = await api.seedRun(p.path, list, { force });
      if (r && r.blocked) { toast({ kind: 'error', title: 'Seeders bloqués', text: 'Le MySQL qui répond n\'est pas celui du serveur du projet.' }); m.close(); }
    } catch (err) { toast({ kind: 'error', title: 'Seeders impossibles', text: esc(err.message) }); m.close(); }
  };
  go.onclick = () => ok && start(false);
}

api.on('seed', e => {
  const sm = seedModal;
  if (!sm || sm.path !== e.path) return;
  const items = $$('[data-steps] li', sm.m.el);
  if (e.step !== undefined && items[e.step]) {
    const li = items[e.step];
    li.className = 'st-' + (e.state === 'run' ? 'run' : e.state === 'ok' ? 'done' : 'error');
    $('.st-i', li).innerHTML = e.state === 'run' ? '<span class="spinner"></span>' : icon(e.state === 'ok' ? 'check' : 'alert');
    if (e.state === 'run') sm.stepAt = Date.now(); else $('.st-time', li).textContent = fmtDuration(Date.now() - sm.stepAt);
  }
  if (e.running === false) {
    items.forEach((li, i) => { if (li.className === 'st-todo' && e.ok === false && i > e.failedAt) li.insertAdjacentHTML('beforeend', ' <span class="faint">(non lancé)</span>'); });
    sm.m.foot.innerHTML = `<span class="run-state ${e.ok ? 'ok' : 'err'} grow">${e.ok ? `${icon('check')} Seeders exécutés` : `${icon('alert')} Arrêt sur une erreur : lis la sortie ci-dessous`}</span>${e.ok ? '' : `<button class="btn" data-errs>${icon('bug')} Erreurs</button>`}<button class="btn primary" data-close>Fermer</button>`;
    const b = $('[data-errs]', sm.m.el); if (b) b.onclick = () => { sm.m.close(); select(e.path, 'errors'); };
    toast({ kind: e.ok ? 'success' : 'error', title: e.ok ? 'Seeders exécutés' : 'Seeder en échec', text: esc(project(e.path) ? project(e.path).name : '') });
  }
});

// ---------- File d'attente (e-mails, notifications, tâches) ----------
const queueState = { path: null, info: null, busy: null };
const KIND_ICON = { 'E-mail': 'mail', Notification: 'info', 'Tâche': 'list' };
const fmtWhen = d => (d ? new Date(d.replace(' ', 'T')).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');

async function renderQueue(p, panel, refresh = true) {
  if (queueState.path !== p.path) Object.assign(queueState, { path: p.path, info: null, busy: null });
  if (refresh || !queueState.info) {
    if (!queueState.info) panel.innerHTML = `<div class="panel-body">${skeleton('panel', 'Lecture de la file d\'attente...')}</div>`;
    try { queueState.info = await api.queueInfo(p.path); } catch (err) { queueState.info = { error: err.message, pending: [], failed: [] }; }
    if (selected !== p.path || tabOf.get(p.path) !== 'queue') return;
  }
  const q = queueState.info;
  const busy = queueState.busy;
  const alerts = [];
  const t = q.target;
  if (t && t.applicable && !t.match) alerts.push(`<div class="alert error">${icon('alert')}<div class="grow"><b>Ce n'est pas le MySQL de ${esc(t.projectServer ? t.projectServer.type : 'ce projet')} qui répond</b> : la file affichée et les envois viendraient de la base d'un autre serveur.<div class="btns"><button class="btn sm primary" data-q="switch">Basculer vers le bon MySQL</button></div></div></div>`);
  if (q.connection === 'sync') alerts.push(`<div class="alert info">${icon('info')}<div class="grow"><b>Pas de file d'attente</b> : avec <span class="mono">QUEUE_CONNECTION=sync</span>, les e-mails partent immédiatement, pendant la requête (rien n'attend ici).
      <div class="btns">${q.tableMissing ? `<button class="btn sm" data-q="createTable">Créer la table de file d'attente</button>` : `<button class="btn sm" data-q="enable">Utiliser une file d'attente</button>`}</div></div></div>`);
  else if (q.connection !== 'database') alerts.push(`<div class="alert warn">${icon('info')}<div class="grow">File « ${esc(q.connection)} » : DevLauncher ne peut pas lister son contenu (seul le pilote « database » est lisible), mais les actions ci-dessous fonctionnent.</div></div>`);
  if (q.tableMissing && q.connection === 'database') alerts.push(`<div class="alert error">${icon('alert')}<div class="grow">La table <span class="mono">${esc(q.table || 'jobs')}</span> n'existe pas encore dans la base.<div class="btns"><button class="btn sm primary" data-q="createTable">Créer la table et migrer</button></div></div></div>`);
  if (q.error) alerts.push(`<div class="alert error">${icon('alert')}<div class="grow">${esc(q.error)}</div></div>`);
  if (!q.mailCapture) alerts.push(`<div class="alert warn">${icon('alert')}<div class="grow">L'interception des mails est désactivée pour ce projet : traiter la file enverra les e-mails <b>réellement</b>.</div></div>`);

  const counts = { waiting: q.pending.filter(j => j.state === 'waiting').length, scheduled: q.pending.filter(j => j.state === 'scheduled').length, running: q.pending.filter(j => j.state === 'running').length };
  const row = (j, failed) => `<tr>
      <td style="width:auto;font-family:inherit;color:inherit;white-space:nowrap">${icon(KIND_ICON[j.kind] || 'list')} ${esc(j.kind)}</td>
      <td><b>${esc(j.subject || j.title)}</b>${j.subject && j.title !== j.subject ? `<div class="faint small">${esc(j.title)}</div>` : ''}</td>
      <td>${j.recipients.length ? esc(j.recipients.join(', ')) : '<span class="faint">—</span>'}</td>
      ${failed ? `<td style="color:var(--danger)" title="${esc(j.error)}">${esc(j.error.length > 90 ? j.error.slice(0, 88) + '…' : j.error)}</td><td>${fmtWhen(j.failed)}</td>`
        : `<td>${j.state === 'running' ? '<span class="pill starting">En cours</span>' : j.state === 'scheduled' ? `<span class="pill">Prévu ${fmtWhen(j.available)}</span>` : '<span class="pill external">En attente</span>'}${j.attempts ? ` <span class="faint small">${j.attempts} essai${j.attempts > 1 ? 's' : ''}</span>` : ''}</td><td>${fmtWhen(j.created)}</td>`}
      <td style="text-align:right;white-space:nowrap">${failed ? `<button class="btn sm" data-q="retry" data-id="${esc(j.uuid)}" ${busy ? 'disabled' : ''}>Relancer</button> <button class="btn sm btn-icon danger-outline" data-q="forget" data-id="${esc(j.uuid)}" title="Supprimer">${icon('trash')}</button>`
        : j.state !== 'running' ? `<button class="btn sm btn-icon danger-outline" data-q="deletePending" data-id="${j.id}" title="Retirer de la file">${icon('trash')}</button>` : ''}</td>
    </tr>`;
  const head = cols => `<tr>${cols.map(h => `<td style="font-weight:600;color:var(--text-2);font-family:inherit;width:auto">${h}</td>`).join('')}</tr>`;
  panel.innerHTML = `<div class="panel-body">
    ${alerts.join('')}
    <section class="card">
      <div class="card-head"><h3>${icon('mail')} En attente <span class="faint">(${q.pending.length})</span></h3>
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <button class="btn sm primary" data-q="process" ${busy || !q.pending.length ? 'disabled' : ''}>${busy === 'process' ? '<span class="spinner"></span> Envoi...' : `${icon('send')} Envoyer maintenant`}</button>
          <button class="btn sm danger-outline" data-q="deletePending" data-id="all" ${busy || !(counts.waiting + counts.scheduled) ? 'disabled' : ''}>Vider la file</button>
          <button class="btn sm btn-icon ghost" data-q="refresh" title="Actualiser">${icon('refresh')}</button>
        </div></div>
      <div class="card-body">
        <div class="kv"><span class="k">Traitement automatique</span>
          <span class="v">${q.worker ? '<span class="pill running"><span class="dot running"></span>Actif : les éléments partent dès leur arrivée</span>' : '<span class="muted">Arrêté : les éléments attendent un envoi manuel</span>'}</span>
          <button class="btn sm" data-q="worker">${q.worker ? `${icon('stop')} Arrêter` : `${icon('play')} Démarrer`}</button></div>
        <div class="kv"><span class="k">Au lancement</span><span class="v muted">Démarrer le traitement automatique avec le projet</span>
          <label class="toggle"><input type="checkbox" data-q="auto" ${q.autoWorker ? 'checked' : ''}><span class="track"></span></label></div>
        ${q.mailCapture ? `<div class="faint small" style="padding:8px 0">Les e-mails envoyés depuis DevLauncher arrivent dans la <button class="link" data-q="mailbox">Boîte mail</button> de test.</div>` : ''}
      </div>
      ${q.pending.length ? `<div style="overflow-x:auto"><table class="headers-table" style="border-top:1px solid var(--border)">${head(['Type', 'Contenu', 'Destinataires', 'État', 'Ajouté le', ''])}${q.pending.map(j => row(j, false)).join('')}</table></div>`
        : `<div class="faint" style="padding:12px 14px">${q.connection === 'database' && !q.tableMissing ? 'Aucun élément en attente.' : 'Rien à afficher.'}</div>`}
    </section>
    <section class="card">
      <div class="card-head"><h3>${icon('alert')} En échec <span class="faint">(${q.failed.length})</span></h3>
        <div style="display:flex;gap:6px">
          <button class="btn sm" data-q="retry" data-id="" ${busy || !q.failed.length ? 'disabled' : ''}>Tout relancer</button>
          <button class="btn sm danger-outline" data-q="forget" data-id="" ${busy || !q.failed.length ? 'disabled' : ''}>Tout supprimer</button>
        </div></div>
      ${q.failed.length ? `<div style="overflow-x:auto"><table class="headers-table">${head(['Type', 'Contenu', 'Destinataires', 'Erreur', 'Échoué le', ''])}${q.failed.map(j => row(j, true)).join('')}</table></div>`
        : `<div class="faint" style="padding:12px 14px">${q.failedMissing ? 'Table des échecs absente.' : 'Aucun échec.'}</div>`}
    </section>
  </div>`;

  const run = async (what, arg, confirmOpts) => {
    if (confirmOpts && !(await confirmDialog(confirmOpts))) return;
    queueState.busy = what;
    renderQueue(p, panel, false);
    let r;
    try { r = await api.queueRun(p.path, what, arg); } catch (err) { r = { ok: false, error: err.message }; }
    if (r && r.blocked) {
      const ok = await confirmDialog({ title: 'Mauvais serveur MySQL', message: `Ce projet appartient à <b>${esc(r.target.projectServer ? r.target.projectServer.type : '?')}</b>, mais c'est le MySQL de <b>${esc(r.target.listening ? r.target.listening.type || r.target.listening.name : '?')}</b> qui répond.`, detail: '<div class="faint">Basculer arrête l\'autre MySQL et démarre le bon, puis l\'opération est exécutée.</div>', confirmLabel: 'Basculer et continuer' });
      if (ok) { const s = await api.switchMysqlFor(p.path); if (s.ok) r = await api.queueRun(p.path, what, arg); else toast({ kind: 'error', title: 'Bascule impossible', text: esc(s.message) }); }
    }
    queueState.busy = null;
    if (r && !r.blocked) toast(r.ok ? { kind: 'success', title: { process: 'File traitée', retry: 'Relancé', forget: 'Supprimé', deletePending: 'Retiré de la file', enable: 'File d\'attente activée', createTable: 'Table créée' }[what] || 'Terminé', text: r.message ? esc(r.message) : what === 'process' ? 'Les éléments en attente ont été envoyés. Les échecs éventuels apparaissent plus bas.' : '' }
      : { kind: 'error', title: 'Opération échouée', text: esc(r.error || `Code ${r.code} : voir la console du projet.`), onClick: () => { tabOf.set(p.path, 'console'); renderDetail(); } });
    renderQueue(p, panel, true);
  };
  $$('[data-q]', panel).forEach(b => {
    const what = b.dataset.q, id = b.dataset.id;
    if (what === 'auto') { b.onchange = async () => { await api.queueWorker(p.path, q.worker, { auto: b.checked }); /* n'arrête ni ne démarre le traitement en cours */ toast({ kind: 'success', title: b.checked ? 'Traitement automatique au lancement' : 'Démarrage manuel', text: b.checked ? 'La file sera traitée dès que le projet est lancé.' : '', timeout: 3500 }); renderQueue(p, panel, true); }; return; }
    b.onclick = async () => {
      if (what === 'refresh') return renderQueue(p, panel, true);
      if (what === 'mailbox') return setView('mail');
      if (what === 'switch') { const s = await api.switchMysqlFor(p.path); toast(s.ok ? { kind: 'success', title: 'MySQL basculé', text: esc(s.message) } : { kind: 'error', title: 'Bascule impossible', text: esc(s.message) }); refreshServices(); return renderQueue(p, panel, true); }
      if (what === 'worker') {
        const r = await api.queueWorker(p.path, !q.worker);
        if (r.blocked) return toast({ kind: 'error', title: 'Mauvais serveur MySQL', text: 'Bascule d\'abord vers le MySQL du projet.' });
        return setTimeout(() => renderQueue(p, panel, true), 600);
      }
      if (what === 'process') return run('process', null, !q.mailCapture ? { title: 'Envoi réel', message: 'L\'interception des mails est désactivée : les e-mails partiront vers leurs vrais destinataires.', confirmLabel: 'Envoyer', danger: true } : null);
      if (what === 'retry') return run('retry', id);
      if (what === 'forget') return run('forget', id, { title: id ? 'Supprimer l\'échec' : 'Supprimer tous les échecs', message: id ? 'Cet élément en échec sera supprimé définitivement.' : `Les ${q.failed.length} éléments en échec seront supprimés définitivement.`, confirmLabel: 'Supprimer', danger: true });
      if (what === 'deletePending') return run('deletePending', id === 'all' ? 'all' : Number(id), { title: id === 'all' ? 'Vider la file' : 'Retirer de la file', message: id === 'all' ? `Les ${counts.waiting + counts.scheduled} éléments en attente seront supprimés sans être envoyés.` : 'Cet élément sera supprimé sans être envoyé.', confirmLabel: 'Supprimer', danger: true });
      if (what === 'enable') return run('enable', null, { title: 'Utiliser une file d\'attente', message: 'Le .env passera à <span class="mono">QUEUE_CONNECTION=database</span> : les e-mails mis en file attendront ici jusqu\'à leur envoi.', detail: '<div class="faint">Redémarre le projet pour appliquer. Active le traitement automatique pour qu\'ils partent seuls.</div>', confirmLabel: 'Activer' });
      if (what === 'createTable') return run('createTable', null, { title: 'Créer la table de file d\'attente', message: 'La table de file d\'attente va être ajoutée à la base du projet.', detail: '<div class="faint">Seule cette migration est exécutée : les autres migrations en attente du projet ne sont pas lancées.</div>', confirmLabel: 'Créer' });
    };
  });
}
// Traitement automatique actif : la file est relue régulièrement pour voir les éléments partir
setInterval(() => {
  const q = queueState.info;
  if (!q || !q.worker || queueState.busy || view !== 'projects' || selected !== queueState.path || tabOf.get(selected) !== 'queue') return;
  const panel = $('#panel');
  if (panel) renderQueue(project(selected), panel, true);
}, 5000);
api.on('queue', s => {
  if (s.path === selected && tabOf.get(s.path) === 'queue' && view === 'projects' && !queueState.busy) { const panel = $('#panel'); if (panel) renderQueue(project(s.path), panel, true); }
});

// ---------- Diagrammes UML ----------
const umlState = { path: null, list: [], name: null, text: '', saved: '', zoom: 1, editor: true, render: null };
const UML_TYPE = { class: 'Classes', sequence: 'Séquence', activity: 'Activité' };
const umlDirty = () => umlState.name && umlState.text !== umlState.saved;

async function renderUml(p, panel, openName) {
  if (umlState.path !== p.path) {
    Object.assign(umlState, { path: p.path, list: [], name: null, text: '', saved: '', render: null });
    panel.innerHTML = `<div class="panel-body">${skeleton('panel', 'Lecture des diagrammes du projet...')}</div>`;
  }
  try { umlState.list = await api.umlList(p.path); } catch { umlState.list = []; }
  if (selected !== p.path || tabOf.get(p.path) !== 'uml') return;
  if (openName) await umlOpen(p, openName, true);
  else if (!umlState.name && umlState.list.length) await umlOpen(p, umlState.list[0].name, true);
  if (!umlState.list.length) {
    panel.innerHTML = `<div class="empty"><div style="max-width:520px">${icon('list')}<h2>Diagrammes UML</h2>
      <div>Crée des diagrammes de <b>classes</b>, de <b>séquence</b> et d'<b>activité</b> pour ce projet : générés depuis le code ou écrits à la main, puis exportés en PNG ou PDF.
      Ils sont enregistrés dans <span class="mono">docs/uml</span> du projet.</div>
      <div style="display:flex;gap:8px;justify-content:center;margin-top:14px">
        <button class="btn primary" id="u-gen">${icon('code')} Générer depuis le code</button>
        <button class="btn" id="u-new">${icon('plus')} Diagramme vide</button></div></div></div>`;
    $('#u-gen', panel).onclick = () => umlGenerateDialog(p, panel);
    $('#u-new', panel).onclick = () => umlNewDialog(p, panel);
    return;
  }
  const cur = umlState.list.find(d => d.name === umlState.name);
  panel.innerHTML = `
    <div class="toolbar">
      <select id="u-sel" title="Diagramme" style="max-width:340px">${['class', 'sequence', 'activity'].filter(t => umlState.list.some(d => d.type === t)).map(t => {
        const group = umlState.list.filter(d => d.type === t).sort((a, b) => a.name.localeCompare(b.name, 'fr'));
        return `<optgroup label="${UML_TYPE[t]} (${group.length})">${group.map(d => `<option value="${esc(d.name)}" ${d.name === umlState.name ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</optgroup>`;
      }).join('')}</select>
      <span class="faint small">${umlState.list.length} diagramme${umlState.list.length > 1 ? 's' : ''}</span>
      <button class="btn sm" id="u-new">${icon('plus')} Nouveau</button>
      <button class="btn sm" id="u-gen" title="Générer un diagramme depuis le code du projet">${icon('code')} Générer</button>
      <button class="btn sm primary" id="u-save" ${umlDirty() ? '' : 'disabled'}>Enregistrer</button>
      <span class="grow"></span>
      <button class="btn sm ${umlState.editor ? 'active' : ''}" id="u-edit" title="Afficher / masquer l'éditeur">${icon('edit')} Éditeur</button>
      <div class="seg"><button id="u-zm" title="Réduire">−</button><button id="u-zr" title="Taille réelle">${Math.round((umlState.zoom || 1) * 100)} %</button><button id="u-zp" title="Agrandir">+</button><button id="u-zf" title="Ajuster à la fenêtre">Ajuster</button></div>
      <button class="btn sm" id="u-png">${icon('download')} PNG</button>
      <button class="btn sm" id="u-pdf">${icon('download')} PDF</button>
      <button class="btn sm btn-icon" id="u-folder" title="Ouvrir le dossier docs/uml">${icon('folder')}</button>
      <button class="btn sm btn-icon danger-outline" id="u-del" title="Supprimer ce diagramme">${icon('trash')}</button>
    </div>
    <div class="uml-wrap">
      <div class="uml-editor" ${umlState.editor ? '' : 'hidden'}>
        <textarea id="u-text" spellcheck="false">${esc(umlState.text)}</textarea>
        <div class="uml-status" id="u-status"></div>
      </div>
      <div class="uml-preview" id="u-preview"><div class="uml-canvas" id="u-canvas"></div></div>
    </div>`;
  const ta = $('#u-text', panel);
  let t;
  ta.oninput = () => { umlState.text = ta.value; $('#u-save', panel).disabled = !umlDirty(); clearTimeout(t); t = setTimeout(() => umlPreview(panel), 200); };
  ta.onkeydown = e => {
    if (e.key === 'Tab') { e.preventDefault(); const s = ta.selectionStart; ta.setRangeText('  ', s, ta.selectionEnd, 'end'); ta.oninput(); }
    if (e.key === 's' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); umlSave(p, panel); }
  };
  $('#u-sel', panel).onchange = async e => {
    if (umlDirty() && !(await confirmDialog({ title: 'Modifications non enregistrées', message: `Abandonner les modifications de « ${esc(umlState.name)} » ?`, confirmLabel: 'Abandonner', danger: true }))) { e.target.value = umlState.name; return; }
    await umlOpen(p, e.target.value); renderUml(p, panel);
  };
  $('#u-new', panel).onclick = () => umlNewDialog(p, panel);
  $('#u-gen', panel).onclick = () => umlGenerateDialog(p, panel);
  $('#u-save', panel).onclick = () => umlSave(p, panel);
  $('#u-edit', panel).onclick = () => { umlState.editor = !umlState.editor; renderUml(p, panel); };
  const zoom = z => { umlState.zoom = Math.min(3, Math.max(0.2, z || 1)); $('#u-zr', panel).textContent = `${Math.round(umlState.zoom * 100)} %`; umlApplyZoom(panel); };
  $('#u-zm', panel).onclick = () => zoom(umlState.zoom - 0.1);
  $('#u-zp', panel).onclick = () => zoom(umlState.zoom + 0.1);
  $('#u-zr', panel).onclick = () => zoom(1);
  $('#u-zf', panel).onclick = () => { const r = umlState.render, box = $('#u-preview', panel); if (r) zoom(Math.min((box.clientWidth - 40) / r.width, (box.clientHeight - 40) / r.height, 1.5)); };
  $('#u-png', panel).onclick = () => umlExport(p, panel, 'png');
  $('#u-pdf', panel).onclick = () => umlExport(p, panel, 'pdf');
  $('#u-folder', panel).onclick = () => api.umlOpenFolder(p.path);
  $('#u-del', panel).onclick = async () => {
    if (!(await confirmDialog({ title: 'Supprimer le diagramme', message: `Supprimer « ${esc(umlState.name)} » et ses exports PNG / PDF ?`, confirmLabel: 'Supprimer', danger: true }))) return;
    await api.umlDelete(p.path, umlState.name);
    umlState.name = null; umlState.text = umlState.saved = '';
    renderUml(p, panel);
  };
  void cur;
  umlPreview(panel);
}

async function umlOpen(p, name, quiet) {
  try {
    const text = await api.umlRead(p.path, name);
    Object.assign(umlState, { name, text, saved: text, zoom: null }); // zoom null : ajusté à l'ouverture
  } catch (err) { if (!quiet) toast({ kind: 'error', title: 'Ouverture impossible', text: esc(err.message) }); }
}

function umlPreview(panel) {
  const canvas = $('#u-canvas', panel), status = $('#u-status', panel);
  if (!canvas) return;
  try {
    const r = window.UML.render(umlState.text);
    umlState.render = r;
    canvas.innerHTML = r.svg;
    if (umlState.zoom === null) {
      const box = $('#u-preview', panel);
      umlState.zoom = Math.max(0.3, Math.min(1, (box.clientWidth - 40) / r.width));
      const zr = $('#u-zr', panel); if (zr) zr.textContent = `${Math.round(umlState.zoom * 100)} %`;
    }
    umlApplyZoom(panel);
    if (status) status.innerHTML = r.errors.length
      ? `<span style="color:var(--danger)">${icon('alert')} ${r.errors.length} ligne${r.errors.length > 1 ? 's' : ''} ignorée${r.errors.length > 1 ? 's' : ''}</span> <span class="faint">${esc(r.errors.slice(0, 2).join(' · '))}</span>`
      : `<span class="faint">${UML_TYPE[r.type]} · ${r.width} × ${r.height} px · Ctrl+S pour enregistrer</span>`;
  } catch (err) {
    if (status) status.innerHTML = `<span style="color:var(--danger)">${icon('alert')} ${esc(err.message)}</span>`;
  }
}

function umlApplyZoom(panel) {
  const svg = $('#u-canvas svg', panel), r = umlState.render;
  const z = umlState.zoom || 1;
  if (svg && r) { svg.style.width = `${r.width * z}px`; svg.style.height = `${r.height * z}px`; }
}

async function umlSave(p, panel, silent) {
  if (!umlState.name) return;
  await api.umlSave(p.path, umlState.name, umlState.text);
  umlState.saved = umlState.text;
  const b = $('#u-save', panel); if (b) b.disabled = true;
  if (!silent) toast({ kind: 'success', title: 'Diagramme enregistré', text: `docs/uml/${esc(umlState.name)}.puml`, timeout: 2500 });
}

async function umlExport(p, panel, format) {
  const r = umlState.render;
  if (!r) return toast({ kind: 'warn', title: 'Rien à exporter', text: 'Le diagramme contient une erreur : corrige-la dans l\'éditeur pour qu\'il s\'affiche.' });
  const restore = busyButton($(`#u-${format}`, panel), 'Export…');
  try {
    if (umlDirty()) await umlSave(p, panel, true);
    const data = format === 'png' ? { png: await window.UML.toPng(r.svg, r.width, r.height, 2) } : { svg: r.svg, width: r.width, height: r.height };
    const res = await api.umlExport(p.path, umlState.name, format, data);
    toast({ kind: 'success', title: `${format.toUpperCase()} enregistré`, timeout: 9000, onClick: () => api.umlOpenFile(p.path, umlState.name, format),
      text: `docs/uml/${esc(umlState.name)}.${format} · clique pour l'ouvrir${res && res.scaled ? '<br>Diagramme très grand : réduit pour tenir sur une page PDF.' : ''}` });
  } catch (err) { toast({ kind: 'error', title: `Export ${format.toUpperCase()} impossible`, text: esc(err.message), timeout: 12000 }); }
  finally { restore(); }
}

function umlNewDialog(p, panel) {
  let type = 'class';
  const m = openModal({
    title: 'Nouveau diagramme',
    body: `<div class="field"><label for="un-name">Nom</label><input id="un-name" value="diagramme-classes" data-autofocus></div>
      <div class="field"><label>Type</label><div class="seg" style="align-self:flex-start">${Object.entries(UML_TYPE).map(([k, v]) => `<button data-t="${k}" class="${k === type ? 'on' : ''}">${v}</button>`).join('')}</div></div>
      <div class="faint small">Le diagramme démarre avec un exemple à modifier. La syntaxe est celle de PlantUML (voir le guide).</div>`,
    foot: `<button class="btn" data-close>Annuler</button><button class="btn primary" data-ok>Créer</button>`
  });
  $$('[data-t]', m.el).forEach(b => { b.onclick = () => { type = b.dataset.t; $$('[data-t]', m.el).forEach(x => x.classList.toggle('on', x === b)); const n = $('#un-name', m.el); if (/^diagramme-/.test(n.value)) n.value = `diagramme-${{ class: 'classes', sequence: 'sequence', activity: 'activite' }[type]}`; }; });
  $('[data-ok]', m.el).onclick = async () => {
    const name = $('#un-name', m.el).value.trim();
    if (!name) return;
    if (umlState.list.some(d => d.name.toLowerCase() === name.toLowerCase())) return toast({ kind: 'warn', title: 'Nom déjà utilisé', text: 'Choisis un autre nom.' });
    const r = await api.umlSave(p.path, name, window.UML.TEMPLATES[type]);
    m.close();
    umlState.name = null;
    renderUml(p, panel, r.name);
  };
}

// Liste à cocher filtrable : items [{ value, label, sub }]
function checklist(items, { checked = true, placeholder = 'Filtrer...' } = {}) {
  return `<div class="checklist">
    <div class="checklist-tools"><input type="search" data-cl-q placeholder="${esc(placeholder)}">
      <button class="btn sm" data-cl-all>Tout cocher</button><button class="btn sm" data-cl-none>Tout décocher</button><span class="faint small" data-cl-count></span></div>
    <div class="checklist-items">${items.map(it => `<label class="check" data-cl-item><input type="checkbox" value="${esc(it.value)}" ${checked ? 'checked' : ''}> <span class="mono">${esc(it.label)}</span>${it.sub ? ` <span class="faint small">${esc(it.sub)}</span>` : ''}</label>`).join('')}</div>
  </div>`;
}
function bindChecklist(root, onChange = () => {}) {
  const items = $$('[data-cl-item]', root), count = $('[data-cl-count]', root);
  const update = () => { const n = items.filter(i => $('input', i).checked).length; count.textContent = `${n} / ${items.length} sélectionné${n > 1 ? 's' : ''}`; onChange(n); };
  $('[data-cl-q]', root).oninput = e => { const q = e.target.value.toLowerCase(); items.forEach(i => { i.hidden = q && !i.textContent.toLowerCase().includes(q); }); };
  // « Tout cocher » ne touche que les éléments visibles (après filtrage)
  $('[data-cl-all]', root).onclick = () => { items.filter(i => !i.hidden).forEach(i => { $('input', i).checked = true; }); update(); };
  $('[data-cl-none]', root).onclick = () => { items.filter(i => !i.hidden).forEach(i => { $('input', i).checked = false; }); update(); };
  items.forEach(i => { $('input', i).onchange = update; });
  update();
  return () => items.filter(i => $('input', i).checked).map(i => $('input', i).value);
}

async function umlGenerateDialog(p, panel) {
  const src = await api.umlSources(p.path);
  let type = 'class', mode = 'single', lang = 'human';
  const m = openModal({
    title: 'Générer depuis le code',
    wide: true,
    body: `<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <div class="seg">${[...Object.entries(UML_TYPE), ['project', 'Projet complet']].map(([k, v]) => `<button data-t="${k}" class="${k === type ? 'on' : ''}">${v}</button>`).join('')}</div>
        <div class="seg" data-mode hidden><button data-m="single" class="on">Un diagramme</button><button data-m="multi">Plusieurs</button></div>
        <div class="seg" data-langsel title="Vocabulaire des diagrammes"><button data-l="human" class="on">Langage courant</button><button data-l="tech">Technique</button></div>
      </div>
      <div class="faint small" data-langhint>Les diagrammes sont rédigés en phrases simples : aucune route, méthode, commande ni nom de contrôleur.</div>
      <div data-opts></div>
      <div class="field" data-name-field><label for="ug-name">Nom du diagramme</label><input id="ug-name"></div>
      <label class="check" data-overwrite hidden><input type="checkbox" id="ug-over"> <span>Remplacer les diagrammes qui existent déjà (sinon ils sont conservés)</span></label>`,
    foot: `<span class="grow" data-hint></span><button class="btn" data-close>Annuler</button><button class="btn primary" data-ok>${icon('code')} Générer</button>`
  });
  const box = $('[data-opts]', m.el), name = $('#ug-name', m.el), hint = $('[data-hint]', m.el);
  const modeBox = $('[data-mode]', m.el), okBtn = $('[data-ok]', m.el);
  $('.modal', m.el).style.maxWidth = '900px';
  let routes = null, files = null, actionsList = null, getChecked = null;
  const setOk = n => { okBtn.disabled = !n; okBtn.innerHTML = `${icon('code')} ${n > 1 ? `Générer ${n} diagrammes` : 'Générer'}`; };
  const classSource = () => (src.laravel && src.models ? { source: 'models' } : src.prisma ? { source: 'prisma' } : src.typescript ? { source: 'typescript' } : src.folders.length ? { source: 'folder', folder: src.folders[0] } : null);
  const renderOpts = async () => {
    hint.textContent = '';
    getChecked = null;
    const multiCapable = type === 'sequence' ? src.laravel : type === 'activity';
    modeBox.hidden = !multiCapable;
    if (!multiCapable && type !== 'project') mode = 'single';
    $$('[data-m]', m.el).forEach(x => x.classList.toggle('on', x.dataset.m === mode));
    const batch = type === 'project' || mode === 'multi';
    $('[data-name-field]', m.el).hidden = batch;
    $('[data-overwrite]', m.el).hidden = !batch;
    setOk(1);
    if (type === 'project') {
      box.innerHTML = '<div class="faint"><span class="spinner" style="display:inline-block;vertical-align:middle"></span> Analyse du projet...</div>';
      routes = routes || (src.laravel ? await api.umlRoutes(p.path) : []);
      actionsList = actionsList || (src.laravel ? await api.umlActions(p.path) : []);
      const cs = classSource();
      box.innerHTML = `<div class="field"><label>Contenu</label>
        ${cs ? `<label class="check"><input type="checkbox" data-part="class" checked> <span><b>Diagramme de classes</b> <span class="faint small">(${esc({ models: 'modèles Laravel', prisma: 'Prisma', typescript: 'TypeScript', folder: cs.folder }[cs.source])})</span></span></label>` : ''}
        ${routes.length ? `<label class="check"><input type="checkbox" data-part="sequence" checked> <span><b>${routes.length} diagrammes de séquence</b> <span class="faint small">un par route</span></span></label>` : ''}
        ${actionsList.length ? `<label class="check"><input type="checkbox" data-part="activity" checked> <span><b>${actionsList.length} diagrammes d'activité</b> <span class="faint small">un par action de contrôleur</span></span></label>` : ''}
        ${!routes.length && !actionsList.length ? '<div class="faint small">Pas de routes Laravel : pour les activités d\'un projet JavaScript, utilise Activité → Plusieurs.</div>' : ''}
        </div><div class="faint small">Les diagrammes sont enregistrés dans docs/uml, puis classés par type dans la liste.</div>`;
      const count = () => { const n = ($('[data-part="class"]', box) || {}).checked ? 1 : 0; const s = ($('[data-part="sequence"]', box) || {}).checked ? routes.length : 0; const a = ($('[data-part="activity"]', box) || {}).checked ? actionsList.length : 0; setOk(n + s + a); };
      $$('[data-part]', box).forEach(c => { c.onchange = count; });
      count();
      return;
    }
    if (type === 'sequence' && mode === 'multi') {
      routes = routes || await api.umlRoutes(p.path);
      box.innerHTML = `<div class="field"><label>Routes (un diagramme de séquence par route)</label>${checklist(routes.map((r, i) => ({ value: i, label: lang === 'tech' ? `${r.verb.padEnd(6)} ${r.uri}` : r.title, sub: lang === 'tech' ? `${r.controller.split('\\').pop()}@${r.method}` : `${r.verb} ${r.uri}` })), { placeholder: 'Filtrer : /admin, store, Invoice...' })}</div>`;
      getChecked = bindChecklist(box, setOk);
      return;
    }
    if (type === 'activity' && mode === 'multi') {
      if (src.laravel) {
        actionsList = actionsList || await api.umlActions(p.path);
        box.innerHTML = `<div class="field"><label>Actions de contrôleur (un diagramme d'activité par action)</label>${checklist(actionsList.map((a, i) => ({ value: i, label: lang === 'tech' ? `${a.controller}@${a.method}` : a.title, sub: lang === 'tech' ? a.routes.slice(0, 2).join(' · ') + (a.routes.length > 2 ? ' …' : '') : `${a.controller}@${a.method}` })), { placeholder: 'Filtrer : Admin, store, Invoice...' })}</div>`;
      } else {
        files = files || await api.umlFiles(p.path);
        box.innerHTML = `<div class="field"><label>Fichiers (un diagramme d'activité par fonction de chaque fichier coché)</label>${checklist(files.map(f => ({ value: f, label: f })), { checked: false, placeholder: 'Filtrer : components, api, page.tsx...' })}</div>`;
      }
      getChecked = bindChecklist(box, setOk);
      return;
    }
    if (type === 'class') {
      const opts = [];
      if (src.laravel && src.models) opts.push(['models', 'Modèles Laravel (app/Models) avec les colonnes des migrations et les relations']);
      if (src.prisma) opts.push(['prisma', 'Schéma Prisma (prisma/schema.prisma)']);
      if (src.typescript) opts.push(['typescript', 'Classes et interfaces TypeScript']);
      for (const f of src.folders.filter(f => f !== 'app/Models' && f !== 'src')) opts.push([`folder:${f}`, `Toutes les classes PHP de ${f}`]);
      if (!opts.length) { box.innerHTML = '<div class="alert warn">Aucune source de classes reconnue dans ce projet.</div>'; return; }
      box.innerHTML = `<div class="field"><label>Source</label>${opts.map(([v, l], i) => `<label class="check"><input type="radio" name="ug-src" value="${esc(v)}" ${i === 0 ? 'checked' : ''}> <span>${esc(l)}</span></label>`).join('')}</div>
        <div style="display:flex;gap:16px"><label class="check"><input type="checkbox" id="ug-attr" checked> <span>Attributs</span></label><label class="check"><input type="checkbox" id="ug-meth" checked> <span>Méthodes et relations</span></label></div>`;
      const className = v => (lang === 'tech' ? 'classes-' + (v.startsWith('folder:') ? v.slice(7).replace(/\//g, '-').toLowerCase() : v) : (v === 'models' || v === 'prisma' ? 'Classes - Modèle des données' : `Classes - ${v.startsWith('folder:') ? v.slice(7).replace(/\//g, ' ') : 'Organisation du code'}`));
      name.value = className(opts[0][0]);
      $('[name="ug-src"]', box).forEach(r => { r.onchange = () => { name.value = className(r.value); }; });
      if (lang !== 'tech') $('#ug-meth', box).closest('label').hidden = true;
    } else if (type === 'sequence') {
      if (!src.laravel) { box.innerHTML = '<div class="alert info">La génération de séquence part d\'une route Laravel. Pour ce projet, crée un diagramme vide de type Séquence et décris les échanges.</div>'; return; }
      routes = routes || await api.umlRoutes(p.path);
      box.innerHTML = `<div class="field"><label for="ug-rq">Route</label><input id="ug-rq" type="search" placeholder="Filtrer : /signup, store, Post...">
        <select id="ug-route" size="10" style="height:auto;font-family:var(--mono);font-size:12px">${routes.map((r, i) => `<option value="${i}">${lang === 'tech' ? `${esc(r.verb.padEnd(6))} ${esc(r.uri)}  →  ${esc(r.controller.split('\\').pop())}@${esc(r.method)}` : `${esc(r.title)}   ·   ${esc(r.verb)} ${esc(r.uri)}`}</option>`).join('')}</select></div>`;
      const sel = $('#ug-route', box);
      $('#ug-rq', box).oninput = e => { const q = e.target.value.toLowerCase(); [...sel.options].forEach(o => { o.hidden = q && !o.textContent.toLowerCase().includes(q); }); };
      sel.onchange = () => { const r = routes[sel.value]; if (lang !== 'tech') { name.value = `Séquence - ${r.title}`; return; } name.value = `sequence-${r.verb.toLowerCase()}-${r.uri.replace(/[{}]/g, '').replace(/[^\w]+/g, '-').replace(/^-|-$/g, '') || 'racine'}`; };
      if (routes.length) { sel.value = '0'; sel.onchange(); } else box.innerHTML = '<div class="alert warn">Aucune route trouvée dans routes/*.php.</div>';
    } else {
      files = files || await api.umlFiles(p.path);
      box.innerHTML = `<div style="display:grid;grid-template-columns:1.3fr 1fr;gap:10px">
        <div class="field"><label for="ug-fq">Fichier</label><input id="ug-fq" type="search" placeholder="Filtrer : Controller, Service, page.tsx...">
          <select id="ug-file" size="10" style="height:auto;font-family:var(--mono);font-size:12px">${files.map(f => `<option>${esc(f)}</option>`).join('')}</select></div>
        <div class="field"><label for="ug-fn">Fonction / méthode</label><select id="ug-fn" size="10" style="height:auto;font-family:var(--mono);font-size:12px"></select></div></div>`;
      const fsel = $('#ug-file', box), fn = $('#ug-fn', box);
      $('#ug-fq', box).oninput = e => { const q = e.target.value.toLowerCase(); [...fsel.options].forEach(o => { o.hidden = q && !o.textContent.toLowerCase().includes(q); }); };
      fsel.onchange = async () => {
        fn.innerHTML = '<option disabled>Lecture...</option>';
        const list = await api.umlFunctions(p.path, fsel.value);
        fn.innerHTML = list.map(f => `<option value="${esc(f.name)}" data-title="${esc(f.title || f.name)}">${esc(f.class ? f.class + '::' : '')}${esc(f.name)}()  · l.${f.line}</option>`).join('') || '<option disabled>Aucune fonction</option>';
        if (list.length) { fn.value = list[0].name; fn.onchange(); }
      };
      fn.onchange = () => { if (lang !== 'tech') { const o = fn.options[fn.selectedIndex]; name.value = `Activité - ${o ? o.dataset.title : fn.value}`; return; } name.value = `activite-${fsel.value.split(/[\\/]/).pop().replace(/\.\w+$/, '')}-${fn.value}`; };
      const ctrl = files.findIndex(f => /Controller\.php$/.test(f) && !/[\\/]Controller\.php$/.test(f));
      if (ctrl >= 0) { fsel.selectedIndex = ctrl; fsel.onchange(); }
    }
  };
  $$('[data-t]', m.el).forEach(b => { b.onclick = () => { type = b.dataset.t; $$('[data-t]', m.el).forEach(x => x.classList.toggle('on', x === b)); renderOpts(); }; });
  $('[data-m]', m.el).forEach(b => { b.onclick = () => { mode = b.dataset.m; renderOpts(); }; });
  $('[data-l]', m.el).forEach(b => { b.onclick = () => { lang = b.dataset.l; $('[data-l]', m.el).forEach(x => x.classList.toggle('on', x === b)); $('[data-langhint]', m.el).textContent = lang === 'tech' ? 'Vocabulaire du code : routes, méthodes, contrôleurs et types techniques.' : 'Les diagrammes sont rédigés en phrases simples : aucune route, méthode, commande ni nom de contrôleur.'; renderOpts(); }; });
  await renderOpts();
  $('[data-ok]', m.el).onclick = async () => {
    // Génération en lot (Plusieurs / Projet complet)
    if (type === 'project' || mode === 'multi') {
      let jobs = [];
      if (type === 'project') {
        const cs = classSource();
        if (cs && ($('[data-part="class"]', box) || {}).checked) jobs.push({ kind: 'class', opts: cs });
        if (($('[data-part="sequence"]', box) || {}).checked) jobs.push(...routes.map((r, i) => ({ kind: 'sequence', route: i })));
        if (($('[data-part="activity"]', box) || {}).checked) jobs.push(...actionsList.map(a => ({ kind: 'activity', file: a.file, fn: a.method })));
      } else if (type === 'sequence') jobs = getChecked().map(i => ({ kind: 'sequence', route: Number(i) }));
      else if (src.laravel) jobs = getChecked().map(i => ({ kind: 'activity', file: actionsList[i].file, fn: actionsList[i].method }));
      else jobs = getChecked().map(f => ({ kind: 'activity-file', file: f }));
      if (!jobs.length) return;
      return umlRunBatch(p, panel, m, jobs.map(j => ({ ...j, lang })), $('#ug-over', m.el).checked);
    }
    const n = name.value.trim();
    if (!n) return;
    let opts = {};
    if (type === 'class') {
      const v = ($('[name="ug-src"]:checked', box) || {}).value;
      if (!v) return;
      opts = v.startsWith('folder:') ? { source: 'folder', folder: v.slice(7) } : { source: v };
      opts.attributes = $('#ug-attr', box).checked; opts.methods = $('#ug-meth', box).checked; opts.lang = lang;
    } else if (type === 'sequence') {
      const s = $('#ug-route', box); if (!s || s.value === '') return; opts = { route: Number(s.value) };
    } else {
      const f = $('#ug-file', box), fn = $('#ug-fn', box); if (!f || !f.value || !fn.value) return; opts = { file: f.value, fn: fn.value };
    }
    const exists = umlState.list.some(d => d.name.toLowerCase() === n.toLowerCase());
    if (exists && !(await confirmDialog({ title: 'Remplacer le diagramme', message: `Un diagramme « ${esc(n)} » existe déjà. Le remplacer ?`, confirmLabel: 'Remplacer', danger: true }))) return;
    const b = $('[data-ok]', m.el); b.disabled = true; b.innerHTML = '<span class="spinner"></span> Analyse du code...';
    try {
      opts.lang = lang;
      const text = await api.umlGenerate(p.path, type, opts);
      const r = await api.umlSave(p.path, n, text);
      m.close();
      umlState.name = null;
      renderUml(p, panel, r.name);
    } catch (err) {
      b.disabled = false; b.innerHTML = `${icon('code')} Générer`;
      hint.innerHTML = `<span style="color:var(--danger)">${esc(err.message)}</span>`;
    }
  };
}

// Exécute un lot de générations avec progression, puis affiche le récapitulatif.
let umlBatchProgress = null;
async function umlRunBatch(p, panel, m, jobs, overwrite) {
  m.body.innerHTML = `<div class="run-state" data-state><span class="spinner"></span> Préparation de ${jobs.length} diagramme${jobs.length > 1 ? 's' : ''}...</div>
    <div style="height:6px;background:var(--hover);border-radius:3px;overflow:hidden"><div data-bar style="height:100%;width:0;background:var(--accent);transition:width .15s"></div></div>
    <div class="faint small mono" data-cur></div>`;
  m.foot.innerHTML = '<button class="btn" data-close>Fermer</button>';
  umlBatchProgress = s => {
    if (s.path !== p.path) return;
    const bar = $('[data-bar]', m.el), cur = $('[data-cur]', m.el), st = $('[data-state]', m.el);
    if (bar) bar.style.width = `${Math.round(s.i / s.n * 100)}%`;
    if (cur) cur.textContent = s.name;
    if (st) st.innerHTML = `<span class="spinner"></span> Génération ${s.i} / ${s.n}...`;
  };
  try {
    const r = await api.umlGenerateBatch(p.path, jobs, { overwrite });
    umlBatchProgress = null;
    const made = r.created.length + r.replaced.length;
    const st = $('[data-state]', m.el);
    if (st) { st.className = `run-state ${made ? 'ok' : 'err'}`; st.innerHTML = `${icon(made ? 'check' : 'alert')} ${made} diagramme${made > 1 ? 's' : ''} généré${made > 1 ? 's' : ''}`; }
    const bar = $('[data-bar]', m.el); if (bar) bar.style.width = '100%';
    const cur = $('[data-cur]', m.el); if (cur) cur.textContent = '';
    m.body.insertAdjacentHTML('beforeend', `<ul style="margin:0;padding-left:20px">
      ${r.created.length ? `<li>${r.created.length} créé${r.created.length > 1 ? 's' : ''}</li>` : ''}
      ${r.replaced.length ? `<li>${r.replaced.length} remplacé${r.replaced.length > 1 ? 's' : ''}</li>` : ''}
      ${r.skipped.length ? `<li>${r.skipped.length} déjà présent${r.skipped.length > 1 ? 's' : ''}, conservé${r.skipped.length > 1 ? 's' : ''} <span class="faint">(coche « Remplacer » pour les regénérer)</span></li>` : ''}
      ${r.failed.length ? `<li style="color:var(--danger)">${r.failed.length} en erreur : ${r.failed.slice(0, 4).map(f => `${esc(f.name)} (${esc(f.error)})`).join(', ')}${r.failed.length > 4 ? '…' : ''}</li>` : ''}
    </ul>`);
    const first = r.created[0] || r.replaced[0];
    m.foot.innerHTML = `<button class="btn" id="ub-folder">${icon('folder')} Ouvrir docs/uml</button><span class="grow"></span><button class="btn ${first ? '' : 'primary'}" data-close>Fermer</button>${first ? `<button class="btn primary" id="ub-open">Voir les diagrammes</button>` : ''}`;
    $('#ub-folder', m.el).onclick = () => api.umlOpenFolder(p.path);
    const open = $('#ub-open', m.el);
    if (open) open.onclick = () => { m.close(); umlState.name = null; renderUml(p, panel, first); };
    if (!first) { umlState.name = umlState.name || null; renderUml(p, panel); }
  } catch (err) {
    umlBatchProgress = null;
    const st = $('[data-state]', m.el);
    if (st) { st.className = 'run-state err'; st.innerHTML = `${icon('alert')} ${esc(err.message)}`; }
  }
}
api.on('uml-batch', s => { if (umlBatchProgress) umlBatchProgress(s); });

// ---------- Base de données ----------
const dbCache = new Map(); // path -> info
const slug = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 48) || 'app';
const randomPass = () => Array.from(crypto.getRandomValues(new Uint8Array(12)), b => 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 56]).join('');

async function renderDatabase(p, panel, refresh = false) {
  let info = dbCache.get(p.path);
  if (!info || refresh) {
    panel.innerHTML = `<div class="panel-body">${skeleton('panel', 'Lecture de la configuration et connexion au serveur...')}</div>`;
    try { info = await api.dbInfo(p.path); } catch (err) { info = { error: err.message, conn: {} }; }
    dbCache.set(p.path, info);
    if (selected !== p.path || tabOf.get(p.path) !== 'database') return;
  }
  const c = info.conn || {};
  const sqlite = c.connection === 'sqlite';
  const alerts = [];
  if (!info.envExists) alerts.push(`<div class="alert info">${icon('info')}<div class="grow">Pas encore de fichier .env : il sera créé à partir de .env.example lors de l'enregistrement.</div></div>`);
  if (info.unsupported) alerts.push(`<div class="alert warn">${icon('alert')}<div class="grow">Connexion « ${esc(c.connection)} » : DevLauncher gère la création de base pour MySQL, MariaDB et SQLite. Tu peux tout de même modifier la configuration ci-dessous.</div></div>`);
  if (!sqlite && !info.unsupported && !info.mysqlRunning) alerts.push(`<div class="alert error">${icon('alert')}<div class="grow">Le serveur MySQL est arrêté.<div class="btns"><button class="btn sm" data-db="start-mysql">Démarrer MySQL</button></div></div></div>`);
  else if (info.error) alerts.push(`<div class="alert error">${icon('alert')}<div class="grow">${esc(info.error)}</div></div>`);
  if (p.configCached) alerts.push(`<div class="alert warn">${icon('alert')}<div class="grow">La configuration Laravel est en cache : après une modification du .env, lance « Vider les caches ».<div class="btns"><button class="btn sm" data-action="clear">Vider les caches</button></div></div></div>`);

  const field = (id, label, value, attrs = '') => `<div class="kv"><label class="k" for="${id}">${label}</label><input id="${id}" class="v" value="${esc(value ?? '')}" ${attrs} style="height:28px"><span></span></div>`;
  const stateHtml = sqlite ? `
      <div class="kv"><span class="k">Fichier</span><span class="v mono" title="${esc(info.sqlite.file)}">${esc(info.sqlite.file)}</span><span></span></div>
      <div class="kv"><span class="k">État</span><span class="v">${info.sqlite.exists ? `<span class="pill running">Existe</span> <span class="faint">${fmtSize(info.sqlite.size)}</span>` : '<span class="pill error">Absent</span>'}</span><span></span></div>`
    : `
      <div class="kv"><span class="k">Serveur</span><span class="v">${info.connected ? `${esc(info.serverVersion || 'MySQL')} <span class="faint">· ${esc(c.host)}:${esc(c.port)}</span>` : `<span class="faint">${info.mysqlRunning ? 'Connexion refusée' : 'Arrêté'}</span>`}</span><span></span></div>
      <div class="kv"><span class="k">Base</span><span class="v">${c.database ? `<span class="mono">${esc(c.database)}</span> ${info.connected ? (info.exists ? '<span class="pill running">Existe</span>' : '<span class="pill error">Absente</span>') : ''}` : '<span class="faint">non définie (DB_DATABASE)</span>'}</span><span></span></div>
      ${info.exists ? `
      <div class="kv"><span class="k">Tables</span><span class="v">${info.tables} <span class="faint">· ${fmtSize(info.size || 0)}</span></span><span></span></div>
      <div class="kv"><span class="k">Migrations</span><span class="v">${info.migrations == null ? '<span style="color:var(--warning)">jamais exécutées</span>' : `${info.migrations} exécutée${info.migrations > 1 ? 's' : ''}`}</span><span></span></div>` : ''}`;
  const canCreate = sqlite ? !info.sqlite.exists : (info.connected && !info.exists);

  panel.innerHTML = `<div class="panel-body">
    ${alerts.join('')}
    <div class="grid">
      <section class="card">
        <div class="card-head"><h3>${icon('settings')} Connexion (.env)</h3></div>
        <div class="card-body">
          <div class="kv"><label class="k" for="db-conn">Type</label>
            <select id="db-conn" class="v" style="height:28px">${['mysql', 'mariadb', 'sqlite', 'pgsql'].map(t => `<option value="${t}" ${c.connection === t ? 'selected' : ''}>${{ mysql: 'MySQL', mariadb: 'MariaDB', sqlite: 'SQLite (fichier)', pgsql: 'PostgreSQL' }[t]}</option>`).join('')}</select><span></span></div>
          <div data-net ${sqlite ? 'hidden' : ''}>
            ${field('db-host', 'Hôte', c.host)}
            ${field('db-port', 'Port', c.port, 'inputmode="numeric"')}
          </div>
          ${field('db-name', sqlite ? 'Fichier' : 'Base', c.database, sqlite ? 'placeholder="database/database.sqlite"' : '')}
          <div data-net ${sqlite ? 'hidden' : ''}>
            ${field('db-user', 'Utilisateur', c.username)}
            <div class="kv"><label class="k" for="db-pass">Mot de passe</label><input id="db-pass" class="v" type="password" placeholder="${c.hasPassword ? '•••••• (inchangé)' : '(vide)'}" style="height:28px" autocomplete="new-password"><span></span></div>
          </div>
          <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:10px 0">
            <button class="btn sm" data-db="test">${icon('check')} Tester la connexion</button>
            <button class="btn sm primary" data-db="save">Enregistrer dans .env</button>
            <span class="hint-line" data-db-result style="flex-basis:100%"></span>
          </div>
        </div>
      </section>
      <section class="card">
        <div class="card-head"><h3>${icon('list')} État de la base</h3><button class="btn ghost sm btn-icon" data-db="refresh" title="Actualiser">${icon('refresh')}</button></div>
        <div class="card-body">${stateHtml}
          <div style="display:flex;gap:6px;flex-wrap:wrap;padding:10px 0">
            ${canCreate ? `<button class="btn sm primary" data-db="create">${icon('plus')} Créer la base</button>` : ''}
            ${!sqlite && info.connected ? `<button class="btn sm" data-db="create-new">${icon('plus')} Nouvelle base…</button>` : ''}
            <button class="btn sm" data-action="migrate" ${(sqlite ? info.sqlite.exists : info.exists) ? '' : 'disabled title="Crée d\'abord la base"'}>Migrer</button>
            <button class="btn sm" data-action="status" ${(sqlite ? info.sqlite.exists : info.exists) ? '' : 'disabled'}>État des migrations</button>
            ${!sqlite && info.phpmyadmin && info.phpmyadmin.available ? `<button class="btn sm" data-db="pma">${icon('external')} phpMyAdmin</button>` : ''}
          </div>
        </div>
      </section>
    </div>
    ${!sqlite && info.connected && info.databases ? `
    <section class="card">
      <div class="card-head"><h3>Bases du serveur <span class="faint">(${info.databases.length})</span></h3><span class="faint small">Clique sur une base pour l'utiliser dans ce projet</span></div>
      <div class="card-body" style="padding:10px 14px;display:flex;flex-wrap:wrap;gap:6px">
        ${info.databases.length ? info.databases.map(d => `<button class="file ${d.toLowerCase() === String(c.database).toLowerCase() ? '' : 'dep'}" data-use-db="${esc(d)}">${d.toLowerCase() === String(c.database).toLowerCase() ? '<span class="tag">ACTUELLE</span>' : ''}<span>${esc(d)}</span></button>`).join('') : '<span class="faint">Aucune base utilisateur sur ce serveur.</span>'}
      </div>
    </section>` : ''}
  </div>`;

  const val = id => $('#' + id, panel).value.trim();
  const form = () => {
    const v = { connection: val('db-conn'), database: val('db-name') };
    if (v.connection !== 'sqlite') Object.assign(v, { host: val('db-host'), port: val('db-port'), username: val('db-user') });
    const pass = $('#db-pass', panel).value;
    if (pass) v.password = pass;
    return v;
  };
  const result = (kind, html) => { const r = $('[data-db-result]', panel); r.className = `hint-line ${kind}`; r.innerHTML = html; };
  $('#db-conn', panel).onchange = e => { $$('[data-net]', panel).forEach(n => { n.hidden = e.target.value === 'sqlite'; }); };
  const on = (key, fn) => $$(`[data-db="${key}"]`, panel).forEach(b => { b.onclick = fn; });
  on('refresh', () => renderDatabase(p, panel, true));
  on('start-mysql', async () => { await runFix(p, 'mysql'); renderDatabase(p, panel, true); });
  on('pma', () => api.openPhpMyAdmin(c.database || ''));
  on('test', async () => {
    result('faint', '<span class="spinner"></span> Test en cours...');
    try { const r = await api.dbTest(p.path, form()); result('ok', `${icon('check')} ${esc(r.message)}`); }
    catch (err) { result('err', `${icon('alert')} ${esc(err.message)}`); }
  });
  on('save', () => saveDbEnv(p, form(), c, () => renderDatabase(p, panel, true)));
  on('create', () => createDbDialog(p, info, () => renderDatabase(p, panel, true)));
  on('create-new', () => createDbDialog(p, { ...info, conn: { ...c, database: '' } }, () => renderDatabase(p, panel, true)));
  $$('[data-use-db]', panel).forEach(b => { b.onclick = () => { $('#db-name', panel).value = b.dataset.useDb; result('warn', `${icon('info')} Base « ${esc(b.dataset.useDb)} » sélectionnée : clique sur « Enregistrer dans .env » pour l'appliquer.`); }; });
  $$('[data-action]', panel).forEach(b => { b.onclick = () => actionDialog(p, p.actions.find(x => x.id === b.dataset.action)); });
}

async function saveDbEnv(p, values, current, done) {
  const labels = { connection: 'DB_CONNECTION', host: 'DB_HOST', port: 'DB_PORT', database: 'DB_DATABASE', username: 'DB_USERNAME', password: 'DB_PASSWORD' };
  const changes = Object.entries(values).filter(([k, v]) => k === 'password' ? v !== undefined : String(current[k] ?? '') !== String(v));
  if (!changes.length) return toast({ kind: 'info', title: 'Aucun changement', text: 'La configuration du .env est déjà à jour.' });
  const ok = await confirmDialog({
    title: 'Enregistrer dans le .env',
    message: `Ces valeurs vont être écrites dans le fichier <span class="mono">.env</span> de <b>${esc(p.name)}</b> :`,
    detail: `<div class="cmd">${changes.map(([k, v]) => `${labels[k]}=${k === 'password' ? '••••••' : esc(v)}`).join('\n')}</div>
      <div class="faint small">Le reste du fichier n'est pas modifié. Une copie de l'ancien fichier est gardée dans <span class="mono">.env.devlauncher.bak</span>.${isActive(p) ? ' Redémarre le projet pour appliquer.' : ''}</div>`,
    confirmLabel: 'Enregistrer'
  });
  if (!ok) return;
  try {
    await api.dbSaveEnv(p.path, Object.fromEntries(changes));
    toast({ kind: 'success', title: '.env mis à jour', text: changes.map(([k]) => labels[k]).join(', ') });
    done();
  } catch (err) { toast({ kind: 'error', title: 'Écriture impossible', text: esc(err.message) }); }
}

function createDbDialog(p, info, done) {
  const c = info.conn || {};
  const sqlite = c.connection === 'sqlite';
  if (sqlite) {
    return confirmDialog({ title: 'Créer la base SQLite', message: `Créer le fichier <span class="mono">${esc(info.sqlite.file)}</span> ?`, confirmLabel: 'Créer' }).then(async ok => {
      if (!ok) return;
      try { const r = await api.dbCreate(p.path, { name: 'sqlite' }); toast({ kind: 'success', title: 'Base créée', text: esc(r.message) }); done(); }
      catch (err) { toast({ kind: 'error', title: 'Création impossible', text: esc(err.message) }); }
    });
  }
  const name = c.database || slug(p.name);
  const m = openModal({
    title: 'Créer une base de données',
    body: `
      <div class="muted">Serveur <span class="mono">${esc(c.host)}:${esc(c.port)}</span>${info.serverVersion ? ` · ${esc(info.serverVersion)}` : ''}</div>
      <div class="field"><label for="cd-name">Nom de la base</label><input id="cd-name" class="mono" value="${esc(name)}" data-autofocus>
        <div class="hint-line" data-name-hint></div></div>
      <div class="field"><label for="cd-coll">Interclassement</label>
        <select id="cd-coll"><option value="utf8mb4_unicode_ci">utf8mb4_unicode_ci (recommandé pour Laravel)</option><option value="utf8mb4_general_ci">utf8mb4_general_ci</option><option value="utf8mb4_0900_ai_ci">utf8mb4_0900_ai_ci (MySQL 8)</option></select></div>
      <label class="check"><input type="checkbox" id="cd-user-on"> <span><b>Créer un utilisateur dédié</b> à ce projet (plus sûr que root)</span></label>
      <div id="cd-user" hidden style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div class="field"><label for="cd-u">Utilisateur</label><input id="cd-u" class="mono" value="${esc(slug(p.name).slice(0, 32))}"></div>
        <div class="field"><label for="cd-p">Mot de passe</label><input id="cd-p" class="mono" value="${esc(randomPass())}"></div>
      </div>
      <details class="trace"><summary>Compte utilisé pour la création : <b>${esc(c.username || 'root')}</b></summary>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
          <div class="field"><label for="cd-au">Administrateur</label><input id="cd-au" class="mono" value="${esc(c.username || 'root')}"></div>
          <div class="field"><label for="cd-ap">Mot de passe</label><input id="cd-ap" type="password" placeholder="${c.hasPassword ? 'celui du .env' : '(vide)'}"></div>
        </div></details>
      <label class="check"><input type="checkbox" id="cd-env" checked> <span>Enregistrer la base${''} dans le .env du projet</span></label>`,
    foot: `<button class="btn" data-close>Annuler</button><button class="btn primary" data-create>${icon('plus')} Créer</button>`
  });
  const nameInput = $('#cd-name', m.el), hint = $('[data-name-hint]', m.el), btn = $('[data-create]', m.el);
  const checkName = () => {
    const n = nameInput.value.trim();
    const exists = (info.databases || []).some(d => d.toLowerCase() === n.toLowerCase());
    const valid = /^[A-Za-z0-9_$-]{1,64}$/.test(n);
    btn.disabled = !valid || exists;
    hint.className = `hint-line ${!valid || exists ? 'err' : 'ok'}`;
    hint.innerHTML = !valid ? `${icon('alert')} Lettres, chiffres, _ et - uniquement.` : exists ? `${icon('alert')} Une base porte déjà ce nom.` : `${icon('check')} Nom disponible.`;
  };
  nameInput.oninput = checkName;
  checkName();
  $('#cd-user-on', m.el).onchange = e => { $('#cd-user', m.el).hidden = !e.target.checked; $('#cd-env', m.el).nextElementSibling.textContent = e.target.checked ? 'Enregistrer la base, l\'utilisateur et le mot de passe dans le .env' : 'Enregistrer la base dans le .env du projet'; };
  btn.onclick = async () => {
    const opts = { name: nameInput.value.trim(), collation: $('#cd-coll', m.el).value, charset: 'utf8mb4', writeEnv: $('#cd-env', m.el).checked, admin: { username: $('#cd-au', m.el).value.trim() } };
    const ap = $('#cd-ap', m.el).value;
    if (ap) opts.admin.password = ap;
    if ($('#cd-user-on', m.el).checked) opts.user = { username: $('#cd-u', m.el).value.trim(), password: $('#cd-p', m.el).value };
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Création...';
    try {
      const r = await api.dbCreate(p.path, opts);
      m.body.innerHTML = `<div class="alert ok">${icon('check')}<div class="grow"><b>${esc(r.message)}</b>${opts.writeEnv ? '<br>Le .env du projet a été mis à jour.' : ''}</div></div>
        ${opts.user ? `<div class="field"><label>Identifiants de l'utilisateur dédié</label><div class="cmd">DB_USERNAME=${esc(opts.user.username)}\nDB_PASSWORD=${esc(opts.user.password)}</div></div>` : ''}
        <div>Étape suivante : créer les tables avec les migrations.</div>`;
      m.foot.innerHTML = `<button class="btn" data-close>Fermer</button><button class="btn primary" data-migrate>Migrer maintenant</button>`;
      $('[data-migrate]', m.el).onclick = () => { m.close(); actionDialog(p, p.actions.find(a => a.id === 'migrate')); };
      done();
    } catch (err) {
      btn.disabled = false; btn.innerHTML = `${icon('plus')} Créer`;
      hint.className = 'hint-line err'; hint.innerHTML = `${icon('alert')} ${esc(err.message)}`;
    }
  };
}

function renderOverview(p, panel) {
  const active = isActive(p);
  const ext = p.status === 'external' && p.external && p.external.length ? p.external : null;
  const url = ext ? externalUrl(p) : `http://localhost:${p.config.port}`;
  const busy = runningAction.get(p.path);
  const alerts = [];
  if (ext) {
    alerts.push(`<div class="alert warn">${icon('info')}<div class="grow">
      <b>Ce projet a été lancé en dehors de DevLauncher</b> (terminal, VS Code...).
      <div class="muted">${ext.map(e => `Port <span class="mono">${e.port}</span> · ${esc(e.name)} · PID ${e.pid}`).join('<br>')}</div>
      <div class="btns">
        <button class="btn sm" id="x-open">${icon('external')} Ouvrir</button>
        ${ext[0].port !== p.config.port ? `<button class="btn sm" id="x-adopt">Utiliser le port ${ext[0].port} pour ce projet</button>` : ''}
        <button class="btn sm" id="x-takeover">${icon('restart')} Relancer avec DevLauncher</button>
        <button class="btn sm danger-outline" id="x-kill">${icon('stop')} Arrêter</button>
      </div></div></div>`);
  }
  const tgt = dbTargetCache.get(p.path);
  if (tgt && tgt.applicable && !tgt.match && tgt.projectServer) {
    alerts.push(`<div class="alert error">${icon('alert')}<div class="grow">
      ${tgt.running ? `<b>Ce projet utiliserait le MySQL de ${esc(tgt.listening.type || tgt.listening.name)}</b> alors qu'il appartient à <b>${esc(tgt.projectServer.type)}</b> : ses migrations et ses données iraient dans la mauvaise base.`
        : `<b>Le MySQL de ${esc(tgt.projectServer.type)} est arrêté</b> : le projet ne pourra pas accéder à sa base « ${esc(tgt.database)} ».`}
      <div class="btns"><button class="btn sm primary" id="d-switch-mysql">${tgt.running ? `Basculer vers le MySQL de ${esc(tgt.projectServer.type)}` : `Démarrer le MySQL de ${esc(tgt.projectServer.type)}`}</button></div></div></div>`);
  }
  if (p.conflict) alerts.push(`<div class="alert error">${icon('alert')}<div class="grow">Le port ${p.config.port} est aussi attribué à un autre projet.<div class="btns"><button class="btn sm" data-port-edit="port">Changer de port</button></div></div></div>`);
  if (messages.get(p.path) && p.status !== 'running') alerts.push(`<div class="alert error">${icon('alert')}<div class="grow">${esc(messages.get(p.path))}${/port/i.test(messages.get(p.path)) ? '<div class="btns"><button class="btn sm" data-port-edit="port">Changer de port</button></div>' : ''}</div></div>`);
  if (p.type === 'laravel' && !p.hasVendor) alerts.push(`<div class="alert info">${icon('info')}<div class="grow">Dépendances PHP absentes (vendor) : elles seront installées automatiquement au premier lancement.</div></div>`);
  if (p.type === 'laravel' && !p.hasEnv) alerts.push(`<div class="alert info">${icon('info')}<div class="grow">Fichier .env absent : il sera créé depuis .env.example lors de l'installation.</div></div>`);
  if (!['laravel', 'php'].includes(p.type) && !p.hasNodeModules) alerts.push(`<div class="alert info">${icon('info')}<div class="grow">Dépendances absentes (node_modules) : elles seront installées automatiquement au premier lancement.</div></div>`);
  if (p.configCached && p.mailCapture) alerts.push(`<div class="alert warn">${icon('alert')}<div class="grow">La configuration Laravel est en cache : l'interception des mails ne fonctionnera pas tant que le cache n'est pas vidé.<div class="btns"><button class="btn sm" data-action="clear">Vider les caches</button></div></div></div>`);

  const groups = new Map();
  for (const a of p.actions) { if (!groups.has(a.group)) groups.set(a.group, []); groups.get(a.group).push(a); }
  const actionsHtml = [...groups].map(([g, list]) => `
    <div class="act-group">${esc(g)}</div>
    ${list.map(a => `
      <div class="act">
        <div style="min-width:0"><div class="t ${a.danger ? 'danger' : ''}">${esc(a.label)}</div><div class="s" title="${esc(a.desc)}">${esc(a.desc)}</div></div>
        <button class="btn sm ${a.danger ? 'danger-outline' : ''}" data-action="${a.id}" ${busy ? 'disabled' : ''}>${busy === a.id ? '<span class="spinner"></span> En cours' : 'Exécuter'}</button>
      </div>`).join('')}`).join('');

  const errs = errorsCache.get(p.path);
  const top = errs ? errs.items.slice(0, 3) : [];
  const toggle = (id, checked, disabled = false) => `<label class="toggle"><input type="checkbox" id="${id}" ${checked ? 'checked' : ''} ${disabled ? 'disabled' : ''}><span class="track"></span></label>`;
  const mailHelp = !state.settings.mailCapture ? 'Désactivé dans les paramètres' : p.mailCapture ? `Vers la boîte de test (port ${state.mail.port || state.settings.smtpPort})` : 'Les mails partent avec la configuration du .env';

  panel.innerHTML = `<div class="panel-body">
    ${alerts.join('')}
    <div class="grid">
      <section class="card">
        <div class="card-head"><h3>Serveur</h3></div>
        <div class="card-body">
          <div class="kv"><span class="k">Adresse</span>
            <span class="v">${p.status === 'running' || ext ? `<button class="link mono" id="d-url">${esc(url)}</button>` : `<span class="mono faint">${esc(url)}</span>`}</span>
            <button class="btn btn-icon sm ghost" id="d-copy" title="Copier l'adresse">${icon('copy')}</button></div>
          <div class="kv"><span class="k">Port</span><span class="v mono">${p.config.port}</span>
            <button class="btn sm" data-port-edit="port" ${active ? 'disabled title="Arrête le projet pour changer de port"' : ''}>${icon('edit')} Modifier</button></div>
          ${p.config.vitePort !== undefined ? `
          <div class="kv"><span class="k">Vite (assets)</span><span class="v muted">Lancer avec le serveur</span>${toggle('d-vite', p.config.withVite, active)}</div>
          <div class="kv"><span class="k">Port Vite</span><span class="v mono">${p.config.vitePort}</span>
            <button class="btn sm" data-port-edit="vitePort" ${active ? 'disabled' : ''}>${icon('edit')} Modifier</button></div>` : ''}
          <div class="kv"><span class="k">Mails</span><span class="v muted" title="${esc(mailHelp)}">${esc(mailHelp)}</span>${toggle('d-mail', p.mailCapture, !state.settings.mailCapture)}</div>
          <div class="kv"><span class="k">Démarrage</span><span class="v muted">Lancer à l'ouverture de DevLauncher</span>${toggle('d-auto', p.config.autostart)}</div>
        </div>
      </section>
      <section class="card">
        <div class="card-head"><h3>Actions</h3></div>
        <div class="card-body">${actionsHtml || '<div class="faint" style="padding:10px 0">Aucune action pour ce type de projet.</div>'}</div>
      </section>
    </div>
    <section class="card">
      <div class="card-head"><h3>${icon('bug')} Dernières erreurs</h3>${errs && errs.items.length ? `<button class="btn ghost sm" data-goto="errors">Tout voir (${errs.items.length})</button>` : ''}</div>
      <div class="card-body">${!errs ? '<div class="faint" style="padding:10px 0"><span class="spinner" style="display:inline-block;vertical-align:middle"></span> Analyse...</div>'
        : !top.length ? `<div class="faint" style="padding:10px 0">${icon('check')} Aucune erreur détectée dans les logs et la console.</div>`
        : top.map((e, i) => `
          <div class="act">
            <div style="min-width:0"><div class="t"><span class="lvl ${esc(e.level)}">${esc(e.level)}</span> ${esc(e.hint ? e.hint.title : (e.exception || 'Erreur'))}${e.count > 1 ? ` <span class="faint">×${e.count}</span>` : ''}</div>
              <div class="s" title="${esc(e.message)}">${esc(e.message)}</div></div>
            ${e.files && e.files[0] ? `<button class="file ${e.files[0].app ? '' : 'dep'}" data-file="${esc(e.files[0].path)}" data-line="${e.files[0].line || ''}" title="Ouvrir dans VS Code"><span>${esc(shortRel(e.files[0]))}</span></button>` : `<button class="btn sm" data-goto="errors" data-i="${i}">Détails</button>`}
          </div>`).join('')}
      </div>
    </section>
  </div>`;

  const on = (sel, fn) => { const b = $(sel, panel); if (b) b.onclick = fn; };
  on('#d-url', () => api.openUrl(url));
  on('#d-copy', () => navigator.clipboard.writeText(url).then(() => toast({ kind: 'success', title: 'Adresse copiée', text: esc(url), timeout: 2500 })));
  on('#d-switch-mysql', async () => {
    const b = $('#d-switch-mysql', panel);
    b.disabled = true; b.innerHTML = '<span class="spinner"></span> Bascule...';
    const r = await api.switchMysqlFor(p.path);
    toast(r.ok ? { kind: 'success', title: 'MySQL basculé', text: esc(r.message) } : { kind: 'error', title: 'Bascule impossible', text: esc(r.message), onClick: () => setView('server') });
    refreshServices();
    loadDbTarget(p.path).then(() => renderDetail());
  });
  on('#x-open', () => api.openUrl(externalUrl(p)));
  on('#x-adopt', async () => { const snap = await api.setConfig(p.path, { port: ext[0].port }); apply(snap); portSavedToast(p, ext[0].port, snap.envChanges); });
  on('#x-kill', async () => {
    const ok = await confirmDialog({
      title: 'Arrêter le serveur', message: `Arrêter <b>${esc(p.name)}</b>, lancé en dehors de DevLauncher ?`,
      detail: `<div class="cmd">${ext.map(e => `PID ${e.pid} · ${esc(e.name)} · port ${e.port}`).join('\n')}</div><div class="faint">Le terminal qui l'a lancé affichera que le processus s'est arrêté.</div>`,
      confirmLabel: 'Arrêter', danger: true
    });
    if (!ok) return;
    await api.killExternal(p.path);
    apply(await api.snapshot());
  });
  on('#x-takeover', async () => {
    const ok = await confirmDialog({
      title: 'Relancer avec DevLauncher',
      message: `Le serveur de <b>${esc(p.name)}</b> lancé à la main sera arrêté, puis relancé par DevLauncher sur le port <span class="mono">${p.config.port}</span>.`,
      detail: '<div class="faint">Tu profiteras de la console, de l\'analyse des erreurs et de l\'interception des mails.</div>', confirmLabel: 'Relancer'
    });
    if (!ok) return;
    await api.killExternal(p.path);
    messages.delete(p.path);
    apply(await api.snapshot());
    api.start(p.path);
  });
  $$('[data-port-edit]', panel).forEach(b => { b.onclick = () => portDialog(p, b.dataset.portEdit); });
  $$('[data-action]', panel).forEach(b => { b.onclick = () => actionDialog(p, p.actions.find(x => x.id === b.dataset.action)); });
  $$('[data-goto]', panel).forEach(b => { b.onclick = () => { tabOf.set(p.path, b.dataset.goto); renderDetail(); }; });
  $$('[data-file]', panel).forEach(b => { b.onclick = () => openFile(b.dataset.file, b.dataset.line); });
  const bind = (id, fn) => { const i = $('#' + id, panel); if (i) i.onchange = () => fn(i.checked); };
  bind('d-vite', async v => apply(await api.setConfig(p.path, { withVite: v })));
  bind('d-mail', async v => {
    apply(await api.setConfig(p.path, { mailCapture: v }));
    if (isActive(project(p.path))) toast({ kind: 'info', title: 'Redémarre le projet', text: 'Le changement s\'applique au prochain lancement.' });
  });
  bind('d-auto', async v => {
    apply(await api.setConfig(p.path, { autostart: v }));
    toast({ kind: 'success', title: v ? 'Lancement automatique activé' : 'Lancement automatique désactivé', text: v ? `${esc(p.name)} démarrera à chaque ouverture de DevLauncher.` : '', timeout: 3500 });
  });
}

function shortRel(f) { return `${f.rel}${f.line ? ':' + f.line : ''}`; }
function openFile(file, line) {
  api.openFile(file, line ? Number(line) : null).catch(err => toast({ kind: 'error', title: 'Impossible d\'ouvrir le fichier', text: esc(err.message) }));
}

// Console
function renderConsole(p, panel) {
  panel.innerHTML = `
    <div class="toolbar">
      <span class="muted small">Sortie du serveur, de Vite et des actions</span>
      <span class="grow"></span>
      <label class="toggle small"><input type="checkbox" id="c-follow" ${follow ? 'checked' : ''}><span class="track"></span>Suivre</label>
      <button class="btn sm" id="c-copy">${icon('copy')} Copier</button>
      <button class="btn sm" id="c-errors">${icon('bug')} Analyser</button>
      <button class="btn sm" id="c-clear">${icon('trash')} Effacer</button>
    </div>
    <pre class="console" id="console"></pre>`;
  const c = $('#console', panel);
  c.textContent = logs.get(p.path) || '';
  c.scrollTop = c.scrollHeight;
  $('#c-follow', panel).onchange = e => { follow = e.target.checked; };
  $('#c-copy', panel).onclick = () => navigator.clipboard.writeText(c.textContent).then(() => toast({ kind: 'success', title: 'Console copiée', text: '', timeout: 2000 }));
  $('#c-errors', panel).onclick = () => { tabOf.set(p.path, 'errors'); loadErrors(p.path); renderDetail(); };
  $('#c-clear', panel).onclick = () => { logs.set(p.path, ''); c.textContent = ''; api.clearConsole(p.path); loadErrors(p.path); };
}

// Erreurs interprétées
let errFilter = 'all';
async function loadErrors(path) {
  try {
    const r = await api.errors(path);
    errorsCache.set(path, { items: r.items, at: Date.now() });
  } catch { errorsCache.set(path, { items: [], at: Date.now() }); }
  if (path === selected && view === 'projects') {
    const tab = tabOf.get(path) || 'overview';
    if (tab === 'errors' || tab === 'overview') renderDetail();
    else { const t = $('[data-tab="errors"]'); if (t) { const n = errorsCache.get(path).items.length; t.innerHTML = `Erreurs${n ? ` <span class="badge danger">${n}</span>` : ''}`; } }
  }
}

function renderErrors(p, panel) {
  const data = errorsCache.get(p.path);
  const items = data ? data.items.filter(e => errFilter === 'all' || e.source === errFilter) : [];
  panel.innerHTML = `
    <div class="toolbar">
      <div class="seg">${[['all', 'Tout'], ['log', 'Log Laravel'], ['console', 'Console']].map(([id, l]) => `<button class="${errFilter === id ? 'on' : ''}" data-f="${id}">${l}</button>`).join('')}</div>
      <span class="muted small">${data ? `${items.length} erreur${items.length > 1 ? 's' : ''} · analysé à ${new Date(data.at).toLocaleTimeString('fr-FR')}` : 'Analyse...'}</span>
      <span class="grow"></span>
      <button class="btn sm" id="e-refresh">${icon('refresh')} Analyser à nouveau</button>
    </div>
    <div class="panel" style="flex:1"><div class="err-list" id="err-list">
      ${!data ? '<div class="faint"><span class="spinner" style="display:inline-block;vertical-align:middle"></span> Analyse des logs et de la console...</div>'
        : !items.length ? `<div class="empty" style="padding:40px"><div>${icon('check')}<h2>Aucune erreur détectée</h2><div>DevLauncher lit ${p.type === 'laravel' ? 'storage/logs et ' : ''}la console du projet. Les fichiers concernés s'affichent ici dès qu'une erreur apparaît.</div></div></div>`
        : items.map(errorCard).join('')}
    </div></div>`;
  $$('[data-f]', panel).forEach(b => { b.onclick = () => { errFilter = b.dataset.f; renderErrors(p, panel); }; });
  $('#e-refresh', panel).onclick = () => { errorsCache.delete(p.path); renderErrors(p, panel); loadErrors(p.path); };
  $$('[data-file]', panel).forEach(b => { b.onclick = () => openFile(b.dataset.file, b.dataset.line); });
  $$('[data-fix]', panel).forEach(b => { b.onclick = () => runFix(p, b.dataset.fix); });
  $$('.err-msg', panel).forEach(m => { m.onclick = () => m.classList.toggle('full'); });
}

function errorCard(e) {
  const app = e.files.filter(f => f.app), deps = e.files.filter(f => !f.app);
  const fileBtn = f => `<button class="file ${f.app ? '' : 'dep'}" data-file="${esc(f.path)}" data-line="${f.line || ''}" title="${esc(f.path)} — ouvrir dans VS Code">
    <span class="tag">${f.app ? (f.compiled ? 'VUE' : 'PROJET') : 'DÉP.'}</span><span>${esc(shortRel(f))}</span></button>`;
  const fixLabel = { mysql: 'Démarrer MySQL', install: 'Installer les dépendances', migrate: 'Migrer', status: 'État des migrations', port: 'Changer de port' };
  return `
  <div class="err-card ${e.level === 'WARNING' ? 'warning' : ''}">
    <div class="err-top">
      <span class="lvl ${esc(e.level)}">${esc(e.level)}</span>
      ${e.count > 1 ? `<b>×${e.count}</b>` : ''}
      <span>${e.source === 'log' ? `Log Laravel · ${esc(e.logFile || '')}` : 'Console'}</span>
      ${e.last ? `<span class="faint">· ${esc(e.last)}</span>` : ''}
    </div>
    <div class="err-msg" title="Cliquer pour afficher tout le message">${esc(e.message)}</div>
    ${e.exception ? `<div class="err-ex">${esc(e.exception)}</div>` : ''}
    ${e.hint ? `<div class="hint">${icon('info')}<div style="flex:1"><b>${esc(e.hint.title)}.</b> ${esc(e.hint.fix)}</div>${e.hint.action ? `<button class="btn sm" data-fix="${e.hint.action}">${fixLabel[e.hint.action] || 'Corriger'}</button>` : ''}</div>` : ''}
    ${app.length ? `<div class="files"><div class="files-title">Fichiers concernés</div>${app.map(fileBtn).join('')}</div>` : ''}
    ${deps.length ? `<details class="trace"><summary>${deps.length} fichier${deps.length > 1 ? 's' : ''} de dépendances (vendor, node_modules)</summary><div class="files" style="margin-top:6px">${deps.map(fileBtn).join('')}</div></details>` : ''}
    ${e.trace ? `<details class="trace"><summary>Trace complète</summary><pre>${esc(e.trace)}</pre></details>` : ''}
  </div>`;
}

function runFix(p, fix) {
  if (fix === 'mysql') return api.startService('mysql').then(st => { services.mysql = st; renderStatusbar(); toast(st.running ? { kind: 'success', title: 'MySQL démarré', text: '' } : { kind: 'error', title: 'MySQL n\'a pas démarré', text: '' }); });
  if (fix === 'port') return portDialog(p, 'port');
  actionDialog(p, p.actions.find(a => a.id === fix));
}

// Lecteur de log
async function renderLogs(p, panel, refresh = false) {
  if (logView.path !== p.path) Object.assign(logView, { path: p.path, file: null, data: null, open: new Set() });
  panel.innerHTML = `<div class="panel-body">${skeleton('panel', 'Recherche des fichiers de log...')}</div>`;
  const files = await api.logFiles(p.path);
  if (selected !== p.path || (tabOf.get(p.path) || 'overview') !== 'logs') return;
  if (!files.length) {
    panel.innerHTML = `<div class="empty"><div>${icon('file')}<h2>Aucun fichier de log</h2><div>${p.type === 'laravel' ? 'Laravel écrit ses logs dans storage/logs : le fichier apparaîtra ici dès la première erreur ou le premier Log::info().' : 'DevLauncher cherche les fichiers *.log à la racine du projet et dans logs/. Les messages du serveur sont dans l\'onglet Console.'}</div></div></div>`;
    return;
  }
  if (!logView.file || !files.some(f => f.path === logView.file)) logView.file = files[0].path;
  if (!logView.data || refresh || logView.data.file.path !== logView.file) {
    try { logView.data = await api.readLog(p.path, logView.file); } catch (err) { panel.innerHTML = `<div class="empty"><div><h2>Lecture impossible</h2><div>${esc(err.message)}</div></div></div>`; return; }
  }
  if (selected !== p.path || (tabOf.get(p.path) || 'overview') !== 'logs') return;
  const d = logView.data;
  const levels = [['all', 'Tous'], ['error', 'Erreurs'], ['warning', 'Avertissements'], ['info', 'Infos'], ['debug', 'Debug']];
  panel.innerHTML = `
    <div class="toolbar">
      <select id="l-file" title="Fichier de log">${files.map(f => `<option value="${esc(f.path)}" ${f.path === logView.file ? 'selected' : ''}>${esc(f.name)} · ${fmtSize(f.size)} · ${fmtDate(f.mtime)}</option>`).join('')}</select>
      ${d.entries ? `<div class="seg">${levels.map(([id, l]) => `<button class="${logView.level === id ? 'on' : ''}" data-lvl="${id}">${l}</button>`).join('')}</div>` : ''}
      <input type="search" id="l-q" placeholder="Filtrer le texte" value="${esc(logView.q)}">
      <span class="grow"></span>
      <label class="toggle small" title="Relit le fichier toutes les 3 secondes"><input type="checkbox" id="l-live" ${logView.live ? 'checked' : ''}><span class="track"></span>En direct</label>
      <button class="btn sm btn-icon" id="l-refresh" title="Relire">${icon('refresh')}</button>
      <button class="btn sm btn-icon" id="l-open" title="Ouvrir dans l'éditeur">${icon('code')}</button>
      <button class="btn sm btn-icon danger-outline" id="l-clear" title="Vider le fichier">${icon('trash')}</button>
    </div>
    ${d.truncated ? `<div class="alert info" style="border-radius:0">${icon('info')}<div class="grow">Fichier de ${fmtSize(d.size)} : seuls les 2 derniers Mo sont affichés.</div></div>` : ''}
    <div id="l-content" style="flex:1;min-height:0;display:flex;flex-direction:column"></div>`;
  renderLogContent(p, panel);
  $('#l-file', panel).onchange = e => { logView.file = e.target.value; logView.open.clear(); renderLogs(p, panel, true); };
  $$('[data-lvl]', panel).forEach(b => { b.onclick = () => { logView.level = b.dataset.lvl; $$('[data-lvl]', panel).forEach(x => x.classList.toggle('on', x === b)); renderLogContent(p, panel); }; });
  let t;
  $('#l-q', panel).oninput = e => { clearTimeout(t); t = setTimeout(() => { logView.q = e.target.value; renderLogContent(p, panel); }, 200); };
  $('#l-live', panel).onchange = e => { logView.live = e.target.checked; };
  $('#l-refresh', panel).onclick = () => renderLogs(p, panel, true);
  $('#l-open', panel).onclick = () => openFile(logView.file);
  $('#l-clear', panel).onclick = async () => {
    const ok = await confirmDialog({ title: 'Vider le fichier de log', message: `Effacer tout le contenu de <span class="mono">${esc(d.file.name)}</span> ?`, detail: `<div class="faint">${fmtSize(d.file.size)} seront supprimés. Le fichier reste en place et Laravel continuera d'y écrire.</div>`, confirmLabel: 'Vider', danger: true });
    if (!ok) return;
    await api.clearLog(p.path, logView.file);
    renderLogs(p, panel, true);
    loadErrors(p.path);
  };
}

const LEVEL_GROUP = { error: ['ERROR', 'CRITICAL', 'ALERT', 'EMERGENCY'], warning: ['WARNING', 'NOTICE'], info: ['INFO'], debug: ['DEBUG'] };
// Rend cliquables les chemins de fichiers (C:\...\fichier.php:12 ou fichier.php(12)) ; le reste est échappé.
const PATH_RE = /([A-Za-z]:\\[^\n:*?"<>|]+?\.(?:php|js|ts|vue|tsx|jsx|json))(?::(\d+)|\((\d+)\))?/g;
function linkifyPaths(text) {
  let out = '', last = 0, m;
  PATH_RE.lastIndex = 0;
  while ((m = PATH_RE.exec(text))) {
    out += esc(text.slice(last, m.index));
    const file = m[1].replace(/\\\\/g, '\\'); // chemins doublés dans le JSON des logs Laravel
    out += `<span class="flink" data-file="${esc(file)}" data-line="${m[2] || m[3] || ''}">${esc(m[0])}</span>`;
    last = m.index + m[0].length;
  }
  return out + esc(text.slice(last));
}

function renderLogContent(p, panel) {
  const box = $('#l-content', panel);
  const d = logView.data;
  const q = logView.q.trim().toLowerCase();
  if (!d.entries) {
    const lines = d.text.split('\n').filter(l => !q || l.toLowerCase().includes(q));
    box.innerHTML = `<pre class="log-raw">${linkifyPaths(lines.join('\n'))}</pre>`;
  } else {
    const allowed = logView.level === 'all' ? null : LEVEL_GROUP[logView.level];
    const list = d.entries.filter(e => (!allowed || allowed.includes(e.level)) && (!q || e.body.toLowerCase().includes(q) || e.message.toLowerCase().includes(q)));
    const shown = list.slice(-400).reverse(); // le plus récent en haut
    box.innerHTML = !shown.length ? '<div class="empty"><div><h2>Aucune entrée</h2><div>Rien ne correspond au filtre.</div></div></div>'
      : `<div class="log-list">${shown.map((e, i) => {
        const key = e.date + '|' + i + '|' + e.message.slice(0, 40);
        const open = logView.open.has(key);
        return `<div class="log-row ${open ? 'open' : ''}" data-key="${esc(key)}">
          <span class="time">${esc(e.date)}</span><span><span class="lvl ${esc(e.level)}">${esc(e.level)}</span></span>
          <span class="m">${esc(e.message)}</span>
          ${open ? `<div class="log-body">${linkifyPaths(e.body)}</div>` : ''}
        </div>`;
      }).join('')}${list.length > 400 ? `<div class="faint small" style="padding:10px 20px">${list.length - 400} entrées plus anciennes masquées : affine le filtre.</div>` : ''}</div>`;
    $$('.log-row', box).forEach(r => {
      r.onclick = e => {
        if (e.target.closest('.log-body')) return;
        const k = r.dataset.key;
        if (logView.open.has(k)) logView.open.delete(k); else logView.open.add(k);
        renderLogContent(p, panel);
      };
    });
  }
  $$('.flink', box).forEach(s => { s.onclick = e => { e.stopPropagation(); openFile(s.dataset.file, s.dataset.line); }; });
}

setInterval(() => {
  if (!logView.live || view !== 'projects') return;
  const p = project(selected);
  if (!p || (tabOf.get(p.path) || 'overview') !== 'logs' || p.path !== logView.path) return;
  const panel = $('#panel');
  if (panel) renderLogs(p, panel, true);
}, 3000);

// ---------- Boîte mail ----------
async function loadMails() {
  if (!mailState.loaded) $('#view-mail').innerHTML = `<div class="panel-body" style="flex:1">${skeleton('list', 'Lecture de la boîte mail...')}</div>`;
  mailState.list = await api.mails();
  mailState.loaded = true;
  renderMail();
}

function renderMail() {
  const el = $('#view-mail');
  const st = state.mail || {};
  const projectsWithMail = [...new Map(mailState.list.filter(m => m.project).map(m => [m.project, m.projectName || m.project])).entries()];
  const list = mailState.list.filter(m => !mailState.filter || (mailState.filter === '__none' ? !m.project : m.project === mailState.filter));
  el.innerHTML = `
    <aside class="mail-side">
      <div class="mail-head">
        <div class="mail-status"><span class="dot ${st.running ? 'running' : 'error'}"></span>
          ${st.running ? `Boîte de test active · <span class="mono">127.0.0.1:${st.port}</span>` : `<span style="color:var(--danger)">${esc(st.error || 'Boîte de test arrêtée')}</span>`}</div>
        <div class="mail-tools">
          <select id="m-filter"><option value="">Tous les projets (${mailState.list.length})</option>
            ${projectsWithMail.map(([p, n]) => `<option value="${esc(p)}" ${mailState.filter === p ? 'selected' : ''}>${esc(n)}</option>`).join('')}
            <option value="__none" ${mailState.filter === '__none' ? 'selected' : ''}>Autres envois</option></select>
          <button class="btn btn-icon" id="m-test" title="Envoyer un mail de test">${icon('send')}</button>
          <button class="btn btn-icon" id="m-config" title="Configuration">${icon('settings')}</button>
          <button class="btn btn-icon danger-outline" id="m-clear" title="Tout supprimer" ${mailState.list.length ? '' : 'disabled'}>${icon('trash')}</button>
        </div>
      </div>
      <div class="mail-list">${!list.length ? `<div class="faint" style="padding:24px 14px;text-align:center">Aucun mail capturé.</div>` : list.map(m => `
        <div class="mail-item ${m.read ? '' : 'unread'} ${m.id === mailState.selected ? 'selected' : ''}" data-mail="${m.id}">
          <div class="l1"><span>${esc(m.from || '(expéditeur inconnu)')}</span><span>${fmtTime(m.receivedAt)}</span></div>
          <div class="subj">${esc(m.subject)}</div>
          <div class="l3">${m.projectName ? `<span>${esc(m.projectName)}</span> ·` : ''} <span>À : ${esc(m.to.join(', ') || '—')}</span>${m.attachments.length ? ` · ${icon('clip')}${m.attachments.length}` : ''}</div>
        </div>`).join('')}</div>
    </aside>
    <section class="mail-view" id="mail-view"></section>`;
  $('#m-filter', el).onchange = e => { mailState.filter = e.target.value; renderMail(); };
  $('#m-test', el).onclick = sendTestMail;
  $('#m-config', el).onclick = mailConfigDialog;
  $('#m-clear', el).onclick = async () => {
    const ok = await confirmDialog({ title: 'Vider la boîte de test', message: `Supprimer les ${mailState.list.length} mails capturés ?`, confirmLabel: 'Tout supprimer', danger: true });
    if (!ok) return;
    await api.clearMails();
    mailState.selected = null; mailState.detail = null;
    apply(await api.snapshot());
    loadMails();
  };
  $$('[data-mail]', el).forEach(i => { i.onclick = () => openMail(i.dataset.mail); });
  renderMailView();
}

async function openMail(id) {
  mailState.selected = id;
  mailState.detail = await api.mail(id);
  const m = mailState.list.find(x => x.id === id);
  if (m && !m.read) { m.read = true; state.mail.unread = Math.max(0, (state.mail.unread || 1) - 1); renderNav(); }
  renderMail();
}

function renderMailView() {
  const box = $('#mail-view');
  const d = mailState.detail;
  if (!d || d.id !== mailState.selected) {
    box.innerHTML = `<div class="empty"><div>${icon('mail')}<h2>Boîte de test des mails</h2>
      <div style="max-width:440px;margin:0 auto">Les mails envoyés par tes projets lancés depuis DevLauncher arrivent ici au lieu d'être réellement envoyés. Tu vois exactement ce que recevra le destinataire.</div>
      <div style="display:flex;gap:8px;justify-content:center;margin-top:14px"><button class="btn primary" id="mv-test">${icon('send')} Envoyer un mail de test</button><button class="btn" id="mv-config">${icon('settings')} Configuration</button></div></div></div>`;
    $('#mv-test', box).onclick = sendTestMail;
    $('#mv-config', box).onclick = mailConfigDialog;
    return;
  }
  const atts = d.attachments.filter(a => !a.embedded);
  const devices = [['desktop', 'monitor', 'Ordinateur'], ['tablet', 'tablet', 'Tablette'], ['mobile', 'phone', 'Mobile']];
  box.innerHTML = `
    <div class="mail-meta">
      <div class="row"><h2>${esc(d.subject)}</h2>
        <div style="display:flex;gap:6px;flex:none">
          <a class="btn sm" href="/mail/${d.id}/eml" download title="Télécharger le fichier .eml (ouvrable dans Outlook, Thunderbird...)">${icon('download')} .eml</a>
          <button class="btn sm btn-icon danger-outline" id="mv-del" title="Supprimer">${icon('trash')}</button>
        </div></div>
      <dl>
        <dt>De</dt><dd>${esc(d.from || '—')}</dd>
        <dt>À</dt><dd>${esc(d.to.join(', ') || '—')}</dd>
        ${d.cc.length ? `<dt>Cc</dt><dd>${esc(d.cc.join(', '))}</dd>` : ''}
        ${d.replyTo ? `<dt>Répondre</dt><dd>${esc(d.replyTo)}</dd>` : ''}
        <dt>Date</dt><dd>${esc(d.date || fmtDate(d.receivedAt))}${d.projectName ? ` · envoyé par <b>${esc(d.projectName)}</b>` : ''} · ${fmtSize(d.size)}</dd>
      </dl>
      ${atts.length ? `<div class="atts">${atts.map(a => `<button class="att" data-att="${a.index}" title="Ouvrir dans DevLauncher">${icon(previewKind(a) === 'image' ? 'monitor' : 'clip')} ${esc(a.filename)} <span class="faint">${fmtSize(a.size)}</span></button>`).join('')}</div>` : ''}
    </div>
    <div class="tabs" style="justify-content:space-between;align-items:center">
      <div style="display:flex;gap:2px">${[['preview', 'Aperçu'], ['text', 'Texte brut'], ['headers', 'En-têtes']].map(([id, l]) => `<button class="tab ${mailState.tab === id ? 'active' : ''}" data-mtab="${id}">${l}</button>`).join('')}</div>
      ${mailState.tab === 'preview' && d.hasHtml ? `<div class="seg">${devices.map(([id, ic, l]) => `<button class="${mailState.device === id ? 'on' : ''}" data-dev="${id}" title="${l}">${icon(ic)}</button>`).join('')}</div>` : ''}
    </div>
    <div id="mv-body" style="flex:1;min-height:0;display:flex;flex-direction:column"></div>`;
  const body = $('#mv-body', box);
  if (mailState.tab === 'preview') {
    // Aperçu isolé : aucun script du mail n'est exécuté, les liens s'ouvrent dans le navigateur.
    body.innerHTML = `<div class="preview-wrap ${mailState.device}"><iframe sandbox="allow-popups allow-popups-to-escape-sandbox" src="/mail/${d.id}/${d.hasHtml ? 'html' : 'text'}" title="Aperçu du mail"></iframe></div>`;
  } else if (mailState.tab === 'text') {
    body.innerHTML = `<pre class="log-raw">${esc(d.text || '(Ce mail n\'a pas de version texte. Certains clients mail l\'afficheront mal : ajoute une vue texte.)')}</pre>`;
  } else {
    body.innerHTML = `<div style="overflow:auto;flex:1;background:var(--surface)"><table class="headers-table">
      ${d.envelope && d.envelope.from ? `<tr><td>Enveloppe (MAIL FROM)</td><td>${esc(d.envelope.from)}</td></tr><tr><td>Enveloppe (RCPT TO)</td><td>${esc((d.envelope.to || []).join(', '))}</td></tr>` : ''}
      ${d.headers.map(h => `<tr><td>${esc(h.name)}</td><td>${esc(h.value)}</td></tr>`).join('')}</table></div>`;
  }
  $$('[data-att]', box).forEach(b => { b.onclick = () => attachmentDialog(d, d.attachments.find(a => a.index === Number(b.dataset.att))); });
  $$('[data-mtab]', box).forEach(b => { b.onclick = () => { mailState.tab = b.dataset.mtab; renderMailView(); }; });
  $$('[data-dev]', box).forEach(b => { b.onclick = () => { mailState.device = b.dataset.dev; renderMailView(); }; });
  $('#mv-del', box).onclick = async () => {
    await api.deleteMail(d.id);
    mailState.selected = null; mailState.detail = null;
    apply(await api.snapshot());
    loadMails();
  };
}

// Type d'aperçu d'une pièce jointe (même règles que le serveur).
function previewKind(a) {
  const ct = String(a.contentType || '').toLowerCase(), n = String(a.filename || '').toLowerCase();
  if ((/^image\/(png|jpe?g|gif|webp|bmp|x-icon)$/.test(ct)) || /\.(png|jpe?g|gif|webp|bmp)$/.test(n)) return 'image';
  if (ct === 'application/pdf' || n.endsWith('.pdf')) return 'pdf';
  if (ct.startsWith('text/') || ct === 'image/svg+xml' || /json|xml|csv|calendar|vcard|javascript/.test(ct) || /\.(txt|csv|tsv|json|xml|log|md|ics|vcf|html?|css|js|sql|ya?ml|ini|env|svg)$/.test(n)) return 'text';
  return null;
}

// Ouvre une pièce jointe dans l'application, sans l'enregistrer sur l'appareil.
async function attachmentDialog(d, a) {
  if (!a) return;
  const kind = previewKind(a);
  const url = `/mail/${d.id}/view/${a.index}`;
  const m = openModal({
    title: a.filename,
    wide: true,
    body: `<div class="muted small">${esc(a.contentType || 'type inconnu')} · ${fmtSize(a.size)}</div><div data-viewer style="height:min(68vh,720px);display:flex"></div>`,
    foot: `<span class="grow">Affiché dans DevLauncher : rien n'est enregistré sur l'appareil.</span>
      <a class="btn" href="/mail/${d.id}/att/${a.index}" download="${esc(a.filename)}">${icon('download')} Télécharger</a><button class="btn primary" data-close>Fermer</button>`
  });
  $('.modal', m.el).style.maxWidth = '1000px';
  const v = $('[data-viewer]', m.el);
  if (kind === 'image') {
    v.innerHTML = `<div class="preview-wrap" style="padding:12px;border-radius:8px;align-items:center"><img src="${url}" alt="${esc(a.filename)}" style="max-width:100%;max-height:100%;object-fit:contain;background:#fff;border:1px solid var(--border)"></div>`;
  } else if (kind === 'pdf') {
    v.innerHTML = `<iframe src="${url}" title="${esc(a.filename)}" style="flex:1;border:1px solid var(--border);border-radius:8px;background:#fff"></iframe>`;
  } else if (kind === 'text') {
    const text = await (await fetch(url)).text();
    if (/\.(csv|tsv)$/i.test(a.filename) || /csv/.test(String(a.contentType))) {
      // CSV / TSV affiché en tableau (séparateur détecté sur la première ligne)
      const first = text.split(/\r?\n/)[0] || '';
      const sep = /\.tsv$/i.test(a.filename) ? '\t' : [';', ',', '\t'].sort((x, y) => first.split(y).length - first.split(x).length)[0];
      const rows = text.split(/\r?\n/).filter(l => l.trim()).slice(0, 1000).map(l => l.split(sep).map(c => c.replace(/^"|"$/g, '')));
      v.innerHTML = `<div style="flex:1;overflow:auto;border:1px solid var(--border);border-radius:8px;background:var(--surface)"><table class="headers-table">
        ${rows.map((r, i) => `<tr>${r.map(c => i === 0 ? `<td style="font-weight:600;background:var(--surface-2)">${esc(c)}</td>` : `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</table></div>`;
    } else {
      v.innerHTML = `<pre class="log-raw" style="flex:1;border:1px solid var(--border);border-radius:8px">${esc(text)}</pre>`;
    }
  } else {
    v.innerHTML = `<div class="empty" style="border:1px dashed var(--border-strong);border-radius:8px"><div>${icon('file')}<h2>Aperçu non disponible</h2>
      <div>Ce format (${esc(a.filename.split('.').pop().toUpperCase())}) ne peut pas être affiché dans DevLauncher.<br>Tu peux le télécharger pour l'ouvrir avec son application.</div></div></div>`;
  }
}

async function sendTestMail() {
  try { await api.sendSampleMail(); }
  catch (err) { toast({ kind: 'error', title: 'Envoi impossible', text: esc(err.message) }); }
}

function mailConfigDialog() {
  const st = state.mail || {};
  const port = st.port || state.settings.smtpPort;
  const envSnippet = `MAIL_MAILER=smtp\nMAIL_HOST=127.0.0.1\nMAIL_PORT=${port}\nMAIL_USERNAME=null\nMAIL_PASSWORD=null\nMAIL_ENCRYPTION=null`;
  const nodeSnippet = `nodemailer.createTransport({\n  host: '127.0.0.1',\n  port: ${port},\n  secure: false\n})`;
  const m = openModal({
    title: 'Configuration de la boîte de test',
    wide: true,
    body: `
      <div class="alert ${st.running ? 'ok' : 'error'}">${icon(st.running ? 'check' : 'alert')}<div class="grow">${st.running ? `Serveur SMTP de test actif sur <span class="mono">127.0.0.1:${port}</span>. Aucun mail n'est réellement envoyé.` : esc(st.error || 'Boîte de test arrêtée.')}</div></div>
      <div><b>Automatique pour les projets lancés depuis DevLauncher.</b> Au lancement, DevLauncher redirige les mails du projet vers cette boîte, sans modifier ton fichier .env. Désactivable projet par projet dans sa vue d'ensemble.</div>
      <div class="field"><label>Projet lancé à la main (Laravel) : à mettre dans le .env</label><div class="cmd" id="cfg-env">${esc(envSnippet)}</div>
        <div><button class="btn sm" data-copy="cfg-env">${icon('copy')} Copier</button></div></div>
      <div class="field"><label>Node.js (Nodemailer)</label><div class="cmd" id="cfg-node">${esc(nodeSnippet)}</div>
        <div><button class="btn sm" data-copy="cfg-node">${icon('copy')} Copier</button></div></div>
      <div class="faint small">Laravel : si la configuration est en cache (php artisan config:cache), lance « Vider les caches » pour que le changement soit pris en compte. Le port se modifie dans les paramètres.</div>`,
    foot: `<button class="btn" id="cfg-test">${icon('send')} Envoyer un mail de test</button><button class="btn primary" data-close>Fermer</button>`
  });
  $$('[data-copy]', m.el).forEach(b => { b.onclick = () => navigator.clipboard.writeText($('#' + b.dataset.copy, m.el).textContent).then(() => toast({ kind: 'success', title: 'Copié', text: '', timeout: 2000 })); });
  $('#cfg-test', m.el).onclick = sendTestMail;
}

// ---------- Maintenance du serveur local ----------
const serverState = { diag: null, current: null, logTab: 'mysql', log: null, backups: null, creds: { user: 'root', password: '' }, loading: false, at: null };
const SVC_LABEL = { ok: 'En marche', warning: 'En marche · à surveiller', conflict: 'Port occupé', stopped: 'Arrêté' };
const SVC_PILL = { ok: 'running', warning: 'external', conflict: 'error', stopped: '' };

async function loadServer(refresh = true) {
  if (refresh) {
    serverState.loading = true;
    renderServer();
    try { serverState.diag = await api.serverDiagnose(); } catch (err) { toast({ kind: 'error', title: 'Diagnostic impossible', text: esc(err.message) }); }
    serverState.at = Date.now();
    serverState.loading = false;
    try { serverState.backups = await api.backupInfo(); } catch { /* dossier inaccessible */ }
    renderNav();
  }
  if (!serverState.current || !serverState.diag.some(d => d.id === serverState.current)) {
    // Par défaut : le serveur dont MySQL tourne
    const running = (serverState.diag || []).find(d => d.mysql && d.mysql.running);
    serverState.current = (running || (serverState.diag || [])[0] || {}).id || null;
  }
  renderServer();
  loadServerLog();
}

async function loadServerLog() {
  if (!serverState.current) return;
  try { serverState.log = await api.serverLog(serverState.current, serverState.logTab); } catch { serverState.log = { text: '' }; }
  const box = $('#srv-log');
  if (box) { box.innerHTML = highlightLog(serverState.log.text); box.scrollTop = box.scrollHeight; }
}

function highlightLog(text) {
  const lines = String(text || '').split(/\r?\n/).slice(-400);
  if (!lines.join('').trim()) return '<span class="faint">Journal vide ou introuvable.</span>';
  return lines.map(l => /\[ERROR\]|\[error\]|:error\]|\bFatal\b|corrupt|Aborting/i.test(l) ? `<span class="err">${esc(l)}</span>`
    : /\[Warning\]|:warn\]|Unclean shutdown|crash recovery/i.test(l) ? `<span class="warn-line">${esc(l)}</span>` : esc(l)).join('\n');
}

function serviceCard(d, key) {
  const s = d[key];
  if (!s) return '';
  const label = key === 'mysql' ? 'MySQL / MariaDB' : 'Apache';
  const ports = key === 'mysql' ? String(s.port) : s.ports.map(p => p.port).join(', ');
  const fixButtons = i => {
    const b = [];
    if (i.fix === 'aria') b.push(`<button class="btn sm primary" data-repair="aria">${icon('wrench')} Réinitialiser les journaux Aria</button>`);
    if (i.fix === 'restore-system' && s.canRestore) b.push(`<button class="btn sm primary" data-repair="restore-system">${icon('wrench')} Réparer MySQL (méthode XAMPP)</button>`);
    if (i.fix === 'restore-system' && !s.canRestore) b.push(`<span class="faint small">Réparation automatique disponible uniquement pour XAMPP : restaure tes bases depuis une sauvegarde.</span>`);
    if (i.fix === 'kill-port' && i.pid) b.push(`<button class="btn sm danger-outline" data-kill="${i.port || ports.split(',')[0]}" data-name="${esc(i.title)}">${icon('stop')} Arrêter ce programme</button>`);
    if (i.fix === 'kill-mysqld') b.push(`<button class="btn sm danger-outline" data-svc-stop="mysql" data-force="1">${icon('stop')} Forcer l'arrêt de MySQL</button>`);
    if (i.fix === 'stop-other') b.push(`<button class="btn sm primary" data-stop-other="${esc(i.other)}" data-service="${i.service}">Arrêter l'autre serveur et démarrer celui-ci</button>`);
    if ((i.fix === 'apache-port' || (key === 'apache' && i.id === 'port')) && s.editablePorts) b.push(`<button class="btn sm" data-apache-port>${icon('edit')} Changer le port d'Apache</button>`);
    if (i.fix === 'orphan') {
      return `<div style="display:flex;flex-direction:column;gap:6px;margin-top:8px">${i.databases.map(x => `
        <div class="act" style="border:0;padding:2px 0"><div style="min-width:0"><span class="mono"><b>${esc(x.name)}</b></span> <span class="faint small">${x.count} table${x.count > 1 ? 's' : ''} inaccessible${x.count > 1 ? 's' : ''}${x.projects.length ? ` · utilisée par ${x.projects.map(p => esc(p.name)).join(', ')}` : ''}</span></div>
          <div style="display:flex;gap:6px">${x.projects.map(p => `<button class="btn sm" data-remigrate="${esc(p.path)}" title="Recrée toutes les tables du projet (migrate:fresh --seed)">Recréer (${esc(p.name)})</button>`).join('')}
          ${(serverState.backups && serverState.backups.list.some(bk => bk.type === 'dump' && bk.databases.some(z => z.name === x.name && !(z.skipped || []).length))) ? `<button class="btn sm" data-restore-db="${esc(x.name)}">Restaurer…</button>` : ''}</div></div>`).join('')}</div>`;
    }
    if (i.fix === 'open-config') b.push(`<button class="btn sm" data-open-file="${key === 'mysql' ? 'my.ini' : 'httpd.conf'}">${icon('code')} Ouvrir ${key === 'mysql' ? 'my.ini' : 'httpd.conf'}</button>`);
    return b.length ? `<div class="btns">${b.join('')}</div>` : '';
  };
  const body = [];
  for (const i of s.issues) body.push(`<div class="alert ${s.running ? 'warn' : 'error'}">${icon('alert')}<div class="grow"><b>${esc(i.title)}</b><div>${esc(i.detail)}</div>${fixButtons(i)}</div></div>`);
  for (const w of s.warnings) body.push(`<div class="alert warn">${icon('info')}<div class="grow">${esc(w)}</div></div>`);
  if (key === 'mysql' && s.running && (s.warnings.length || s.issues.length)) body.push(`<div><button class="btn sm primary" data-backup-now>${icon('archive')} Sauvegarder mes bases maintenant</button></div>`);
  if (!s.issues.length && !s.warnings.length && s.running) body.push(`<div class="alert ok">${icon('check')}<div class="grow">Aucun problème détecté.</div></div>`);
  if (!s.issues.length && !s.running) body.push(`<div class="alert info">${icon('info')}<div class="grow">${label} est arrêté. Démarre-le : en cas d'échec, DevLauncher analyse la cause.</div></div>`);
  return `
  <section class="card">
    <div class="card-head">
      <h3>${icon('server')} ${label} <span class="pill ${SVC_PILL[s.status]}">${SVC_LABEL[s.status]}</span></h3>
      <div style="display:flex;gap:6px">
        ${s.running ? `<button class="btn sm" data-svc-stop="${key}">${icon('stop')} Arrêter</button><button class="btn sm" data-svc-restart="${key}">${icon('restart')} Redémarrer</button>`
          : `<button class="btn sm primary" data-svc-start="${key}">${icon('play')} Démarrer</button>`}
      </div>
    </div>
    <div class="card-body">
      <div class="kv"><span class="k">Port${key === 'apache' && s.ports.length > 1 ? 's' : ''}</span><span class="v mono">${esc(ports)}</span><span></span></div>
      ${key === 'mysql' ? `<div class="kv"><span class="k">Données</span><span class="v mono" title="${esc(s.datadir)}">${esc(s.datadir)}</span><span></span></div>` : ''}
      <div class="kv"><span class="k">Journal</span><span class="v mono" title="${esc(s.log || '')}">${esc(s.log || 'introuvable')}</span>
        ${s.log ? `<button class="btn ghost sm btn-icon" data-open-file="${key}-log" title="Ouvrir le journal">${icon('code')}</button>` : '<span></span>'}</div>
      <div style="display:flex;flex-direction:column;gap:8px;padding:10px 0">${body.join('')}</div>
      <details class="trace" style="padding-bottom:10px"><summary>${icon('wrench')} Réparation avancée</summary>
        <div style="display:flex;flex-direction:column;gap:6px;margin-top:8px">
          ${key === 'mysql' && s.canRestore ? `<div class="act"><div style="min-width:0"><div class="t">Réparer MySQL (méthode XAMPP)</div><div class="s">Remplace les tables système par celles de mysql\\backup en gardant tes bases. Pour « MySQL shutdown unexpectedly ».</div></div><button class="btn sm" data-repair="restore-system">Lancer…</button></div>` : ''}
          ${key === 'mysql' && s.mariadb ? `<div class="act"><div style="min-width:0"><div class="t">Réinitialiser les journaux Aria</div><div class="s">Met de côté aria_log_control et aria_log.* (recréés au démarrage).</div></div><button class="btn sm" data-repair="aria">Lancer…</button></div>` : ''}
          ${key === 'mysql' ? `<div class="act"><div style="min-width:0"><div class="t">Forcer l'arrêt de MySQL</div><div class="s">Quand MySQL ne répond plus. Préfère l'arrêt normal quand c'est possible.</div></div><button class="btn sm danger-outline" data-svc-stop="mysql" data-force="1">Forcer</button></div>` : ''}
          ${key === 'apache' && s.editablePorts ? `<div class="act"><div style="min-width:0"><div class="t">Changer le port d'Apache</div><div class="s">Quand le port 80 ou 443 est pris par Windows ou un autre logiciel.</div></div><button class="btn sm" data-apache-port>Modifier…</button></div>` : ''}
          ${key === 'apache' && s.configTest ? `<div class="act"><div style="min-width:0"><div class="t">Test de la configuration</div><div class="s">${s.configTest.ok ? 'httpd -t : Syntax OK' : esc(s.configTest.output)}</div></div><button class="btn sm" data-open-file="httpd.conf">Ouvrir…</button></div>` : ''}
        </div>
      </details>
    </div>
  </section>`;
}

function renderServer() {
  const el = $('#view-server');
  if (!el || view !== 'server') return;
  const diag = serverState.diag || [];
  const d = diag.find(x => x.id === serverState.current);
  const b = serverState.backups;
  const st = state.settings || {};
  el.innerHTML = `<div class="detail" style="overflow-y:auto">
    <div class="d-header">
      <div><div class="d-title"><h1>Serveur local</h1></div>
        <div class="d-meta">Diagnostic, réparation et sauvegarde de MySQL et d'Apache${serverState.at ? ` · analysé à ${new Date(serverState.at).toLocaleTimeString('fr-FR')}` : ''}</div></div>
      <div class="d-actions">
        ${diag.length > 1 ? `<div class="seg">${diag.map(x => `<button class="${x.id === serverState.current ? 'on' : ''}" data-srv="${esc(x.id)}" title="${esc(x.base)}">${esc(x.type)}</button>`).join('')}</div>` : ''}
        <button class="btn" id="srv-refresh" ${serverState.loading ? 'disabled' : ''}>${serverState.loading ? '<span class="spinner"></span> Analyse...' : `${icon('refresh')} Diagnostiquer`}</button>
      </div>
    </div>
    <div class="panel-body">
      ${!d ? (serverState.loading ? skeleton('panel', 'Analyse de MySQL et d\'Apache...') : '<div class="empty"><div><h2>Aucun serveur local détecté</h2><div>Installe XAMPP, Laragon ou WAMP.</div></div></div>') : `
      <div class="grid">${serviceCard(d, 'mysql')}${serviceCard(d, 'apache')}</div>
      <section class="card">
        <div class="card-head"><h3>${icon('file')} Journal d'erreurs</h3>
          <div style="display:flex;gap:6px;align-items:center">
            <div class="seg">${d.mysql ? `<button class="${serverState.logTab === 'mysql' ? 'on' : ''}" data-logtab="mysql">MySQL</button>` : ''}${d.apache ? `<button class="${serverState.logTab === 'apache' ? 'on' : ''}" data-logtab="apache">Apache</button>` : ''}</div>
            <button class="btn ghost sm btn-icon" id="srv-log-refresh" title="Relire">${icon('refresh')}</button>
          </div></div>
        <pre class="console" id="srv-log" style="height:260px;flex:none;border-radius:0 0 8px 8px"><span class="faint">Chargement...</span></pre>
      </section>`}
      <section class="card">
        <div class="card-head"><h3>${icon('archive')} Sauvegardes</h3>
          <div style="display:flex;gap:6px">
            <button class="btn sm primary" id="bk-new" ${!d || !d.mysql ? 'disabled' : ''}>${icon('archive')} Sauvegarder maintenant</button>
            <button class="btn sm" id="bk-open">${icon('folder')} Ouvrir le dossier</button>
          </div></div>
        <div class="card-body">
          <div class="kv"><span class="k">Dossier</span><span class="v mono" title="${esc(b ? b.dir : '')}">${esc(b ? b.dir : '...')}</span><button class="btn sm" id="bk-dir">Changer…</button></div>
          <div class="kv"><span class="k">Automatique</span><span class="v muted">Une sauvegarde SQL par jour de toutes les bases (${st.autoBackupKeep || 7} dernières gardées)</span>
            <label class="toggle"><input type="checkbox" id="bk-auto" ${st.autoBackup ? 'checked' : ''}><span class="track"></span></label></div>
        </div>
        ${b && b.list.length ? `<div style="overflow-x:auto"><table class="headers-table" style="border-top:1px solid var(--border)">
          <tr>${['Date', 'Serveur', 'Type', 'Contenu', 'Taille', ''].map(h => `<td style="font-weight:600;color:var(--text-2);font-family:inherit;width:auto">${h}</td>`).join('')}</tr>
          ${b.list.map(x => `<tr>
            <td style="font-family:inherit;color:inherit;width:auto">${esc(new Date(x.date).toLocaleString('fr-FR'))}${x.label ? ` <span class="pill">${esc({ auto: 'automatique', 'avant-restauration': 'avant restauration', 'avant-reparation': 'avant réparation' }[x.label] || x.label)}</span>` : ''}</td>
            <td>${esc(x.server.type)}</td>
            <td>${x.type === 'raw' ? 'Copie du dossier data' : 'Export SQL'}</td>
            <td title="${esc(x.databases.map(z => z.name).join(', '))}">${x.databases.length} base${x.databases.length > 1 ? 's' : ''}${x.files && x.files.length ? ' + configuration' : ''}</td>
            <td>${fmtSize(x.size || 0)}</td>
            <td style="text-align:right;white-space:nowrap">${x.type === 'dump' ? `<button class="btn sm" data-bk-restore="${esc(x.name)}">Restaurer…</button>` : ''} <button class="btn sm btn-icon danger-outline" data-bk-del="${esc(x.name)}" title="Supprimer">${icon('trash')}</button></td>
          </tr>`).join('')}</table></div>`
          : `<div class="faint" style="padding:12px 14px">Aucune sauvegarde pour l'instant.</div>`}
      </section>
    </div></div>`;

  const on = (sel, fn) => $$(sel, el).forEach(x => { x.onclick = () => fn(x); });
  on('#srv-refresh', () => loadServer(true));
  on('[data-srv]', x => { serverState.current = x.dataset.srv; renderServer(); loadServerLog(); });
  on('[data-logtab]', x => { serverState.logTab = x.dataset.logtab; renderServer(); loadServerLog(); });
  on('#srv-log-refresh', () => loadServerLog());
  on('[data-open-file]', x => api.openServerFile(serverState.current, x.dataset.openFile).catch(err => toast({ kind: 'error', title: 'Ouverture impossible', text: esc(err.message) })));
  on('[data-svc-start]', x => serviceAction(d, x.dataset.svcStart, 'start'));
  on('[data-svc-stop]', x => serviceAction(d, x.dataset.svcStop, 'stop', !!x.dataset.force));
  on('[data-svc-restart]', x => serviceAction(d, x.dataset.svcRestart, 'restart'));
  on('[data-repair]', x => repairDialog(d, x.dataset.repair));
  on('[data-kill]', x => killPortDialog(Number(x.dataset.kill), x.dataset.name));
  on('[data-stop-other]', x => stopOtherDialog(d, x.dataset.stopOther, x.dataset.service));
  on('[data-apache-port]', () => apachePortDialog(d));
  on('#bk-new', () => backupDialog(d));
  on('[data-backup-now]', () => backupDialog(d));
  on('[data-remigrate]', x => {
    const p = project(x.dataset.remigrate);
    if (!p) return;
    select(p.path, 'database');
    actionDialog(p, p.actions.find(a => a.id === 'fresh'));
  });
  on('[data-restore-db]', x => {
    const bk = b.list.find(z => z.type === 'dump' && z.databases.some(y => y.name === x.dataset.restoreDb && !(y.skipped || []).length));
    restoreDialog(d, bk, x.dataset.restoreDb);
  });
  on('#bk-open', () => api.openBackupFolder());
  on('#bk-dir', async () => { await api.pickBackupFolder(); serverState.backups = await api.backupInfo(); renderServer(); loadServerLog(); });
  on('[data-bk-restore]', x => restoreDialog(d, b.list.find(z => z.name === x.dataset.bkRestore)));
  on('[data-bk-del]', async x => {
    const ok = await confirmDialog({ title: 'Supprimer la sauvegarde', message: `Supprimer définitivement la sauvegarde <span class="mono">${esc(x.dataset.bkDel)}</span> ?`, confirmLabel: 'Supprimer', danger: true });
    if (!ok) return;
    await api.backupDelete(x.dataset.bkDel);
    serverState.backups = await api.backupInfo();
    renderServer(); loadServerLog();
  });
  const auto = $('#bk-auto', el);
  if (auto) auto.onchange = async () => { apply(await api.setSettings({ autoBackup: auto.checked })); toast({ kind: 'success', title: auto.checked ? 'Sauvegarde automatique activée' : 'Sauvegarde automatique désactivée', text: auto.checked ? 'Une sauvegarde SQL de toutes les bases sera faite chaque jour.' : '', timeout: 3500 }); };
}

// Fenêtre de progression commune (démarrage, arrêt, réparation) avec résultat et extrait du journal.
function progressModal(title, text) {
  const m = openModal({ title, body: `<div class="run-state" data-state><span class="spinner"></span> ${esc(text)}</div><div data-result></div>`, foot: '<button class="btn" data-close>Fermer</button>' });
  return {
    m,
    done(r) {
      const ok = r && r.ok;
      $('[data-state]', m.el).className = `run-state ${ok ? 'ok' : 'err'}`;
      $('[data-state]', m.el).innerHTML = `${icon(ok ? 'check' : 'alert')} ${esc(r ? r.message : 'Échec')}`;
      $('[data-result]', m.el).innerHTML = `
        ${r && r.steps ? `<ul style="margin:4px 0 0;padding-left:20px">${r.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ul>` : ''}
        ${r && r.issues && r.issues.length ? r.issues.map(i => `<div class="alert error" style="margin-top:8px">${icon('alert')}<div class="grow"><b>${esc(i.title)}</b><div>${esc(i.detail)}</div></div></div>`).join('') : ''}
        ${r && r.log ? `<div class="field" style="margin-top:8px"><label>Extrait du journal</label><pre class="console" style="height:200px">${highlightLog(r.log)}</pre></div>` : ''}`;
      if (!ok && r && r.log) $('.modal', m.el).classList.add('wide');
    }
  };
}

async function serviceAction(d, key, action, force = false) {
  const label = key === 'mysql' ? 'MySQL' : 'Apache';
  if (action === 'stop' && force) {
    const ok = await confirmDialog({ title: `Forcer l'arrêt de ${label}`, message: `${label} sera arrêté immédiatement, sans attendre la fin des requêtes en cours.`, detail: '<div class="faint">À utiliser quand l\'arrêt normal ne fonctionne pas.</div>', confirmLabel: 'Forcer l\'arrêt', danger: true });
    if (!ok) return;
  }
  const verb = { start: 'Démarrage', stop: 'Arrêt', restart: 'Redémarrage' }[action];
  const pm = progressModal(`${verb} de ${label}`, `${verb} de ${label} en cours...`);
  try {
    let r;
    if (action !== 'start') {
      r = await api.serverStop(d.id, key, { force, ...serverState.creds });
      if (r.needForce) {
        pm.m.close();
        return stopNeedsForce(d, key, action);
      }
    }
    if (action !== 'stop') r = await api.startService(key, d.id);
    pm.done(r && (r.ok !== undefined ? r : { ok: r.running, message: r.running ? `${label} démarré.` : `${label} n'a pas démarré.` }));
  } catch (err) { pm.done({ ok: false, message: err.message }); }
  loadServer(true);
}

// Arrêt propre refusé (mot de passe root) : on propose le mot de passe ou l'arrêt forcé.
function stopNeedsForce(d, key, action) {
  const m = openModal({
    title: 'Arrêt propre impossible',
    body: `<div>MySQL refuse l'arrêt avec le compte <b>${esc(serverState.creds.user)}</b> sans mot de passe, ou ne répond plus.</div>
      <div class="field"><label for="sf-pass">Mot de passe de ${esc(serverState.creds.user)} (arrêt propre, recommandé)</label><input id="sf-pass" type="password" data-autofocus></div>`,
    foot: `<button class="btn danger-outline" data-force>Forcer l'arrêt</button><span class="grow"></span><button class="btn" data-close>Annuler</button><button class="btn primary" data-retry>Réessayer</button>`
  });
  $('[data-retry]', m.el).onclick = () => { serverState.creds.password = $('#sf-pass', m.el).value; m.close(); serviceAction(d, key, action); };
  $('[data-force]', m.el).onclick = () => { m.close(); serviceAction(d, key, action, true); };
}

async function killPortDialog(port, title) {
  const ok = await confirmDialog({ title: 'Arrêter le programme', message: esc(title), detail: `<div class="faint">Le programme qui écoute sur le port ${port} sera fermé de force. Enregistre ton travail s'il s'agit d'une application que tu utilises.</div>`, confirmLabel: 'Arrêter le programme', danger: true });
  if (!ok) return;
  try { const r = await api.killPortOwner(port); toast({ kind: r.ok ? 'success' : 'error', title: r.ok ? 'Programme arrêté' : 'Arrêt impossible', text: esc(r.message) }); }
  catch (err) { toast({ kind: 'error', title: 'Arrêt impossible', text: esc(err.message) }); }
  loadServer(true);
}

async function stopOtherDialog(d, otherId, service) {
  const other = (serverState.diag || []).find(x => x.id === otherId);
  const label = service === 'mysql' ? 'MySQL' : 'Apache';
  const ok = await confirmDialog({ title: `Utiliser le ${label} de ${d.type}`, message: `Le ${label} de <b>${esc(other ? other.type : otherId)}</b> sera arrêté proprement, puis celui de <b>${esc(d.type)}</b> sera démarré.`, detail: '<div class="faint">Tes projets utiliseront alors les bases et la configuration de ce serveur.</div>', confirmLabel: 'Basculer' });
  if (!ok) return;
  const pm = progressModal(`Bascule vers ${d.type}`, `Arrêt du ${label} de ${other ? other.type : ''}...`);
  try {
    const s = await api.serverStop(otherId, service, serverState.creds);
    if (s.needForce) { pm.done({ ok: false, message: 'L\'autre MySQL refuse l\'arrêt propre (mot de passe root). Arrête-le depuis son serveur, ou force l\'arrêt depuis son onglet.' }); return loadServer(true); }
    const r = await api.startService(service, d.id);
    pm.done(r.ok !== undefined ? r : { ok: r.running, message: r.running ? 'Démarré.' : 'Échec du démarrage.' });
  } catch (err) { pm.done({ ok: false, message: err.message }); }
  loadServer(true);
}

function repairDialog(d, kind) {
  const my = d.mysql;
  const info = {
    'restore-system': {
      title: 'Réparer MySQL (méthode XAMPP)',
      steps: ['Arrêt de MySQL', 'Le dossier data actuel est renommé en data_old_<date> et conservé intact', 'Les tables système saines de mysql\\backup sont copiées dans un nouveau dossier data', 'Tes bases et le fichier ibdata1 sont recopiés depuis data_old', 'Redémarrage de MySQL'],
      warn: 'Les comptes MySQL reviennent à ceux d\'origine de XAMPP (root sans mot de passe) : les utilisateurs créés à la main sont à recréer. Tes bases et leurs données sont conservées.'
    },
    aria: {
      title: 'Réinitialiser les journaux Aria',
      steps: ['Arrêt de MySQL', 'aria_log_control, aria_log.* et les fichiers .pid sont déplacés dans un dossier devlauncher-reparation-<date>', 'Redémarrage : MariaDB recrée des journaux neufs'],
      warn: 'Tes bases ne sont pas modifiées.'
    }
  }[kind];
  const canDump = my && my.running && my.canDump;
  const m = openModal({
    title: info.title,
    body: `<div>Étapes :</div><ol style="margin:0;padding-left:20px">${info.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol>
      <div class="alert warn">${icon('info')}<div class="grow">${esc(info.warn)}</div></div>
      ${canDump ? `<label class="check"><input type="checkbox" id="rp-backup" checked> <span>Faire d'abord une <b>sauvegarde SQL de toutes les bases</b> (recommandé)</span></label>`
        : `<div class="faint small">MySQL ne tourne pas : pas d'export SQL possible avant la réparation. Le dossier data d'origine est conservé.</div>`}`,
    foot: `<button class="btn" data-close>Annuler</button><button class="btn primary" data-go>${icon('wrench')} Réparer</button>`
  });
  $('[data-go]', m.el).onclick = async () => {
    const doBackup = canDump && $('#rp-backup', m.el).checked;
    m.close();
    const pm = progressModal(info.title, doBackup ? 'Sauvegarde des bases avant réparation...' : 'Réparation en cours...');
    try {
      if (doBackup) await api.backupCreate(d.id, { type: 'dump', label: 'avant-reparation', creds: serverState.creds });
      $('[data-state]', pm.m.el).innerHTML = '<span class="spinner"></span> Réparation en cours...';
      const r = await api.serverRepair(d.id, kind);
      if (doBackup) r.steps = ['Sauvegarde SQL des bases faite avant la réparation', ...(r.steps || [])];
      pm.done(r);
    } catch (err) { pm.done({ ok: false, message: err.message }); }
    loadServer(true);
  };
}

function apachePortDialog(d) {
  const m = openModal({
    title: 'Changer le port d\'Apache',
    body: `<div class="muted">Modifie httpd.conf et httpd-ssl.conf de ${esc(d.type)} (copie .devlauncher.bak gardée).</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="field"><label for="ap-http">Port HTTP</label><input id="ap-http" type="number" value="8080" data-autofocus></div>
        <div class="field"><label for="ap-https">Port HTTPS</label><input id="ap-https" type="number" value="4433"></div>
      </div>
      <div class="faint small">Les sites et phpMyAdmin seront alors accessibles sur http://localhost:<port>/.</div>`,
    foot: `<button class="btn" data-close>Annuler</button><button class="btn primary" data-save>Appliquer et redémarrer Apache</button>`
  });
  $('[data-save]', m.el).onclick = async () => {
    const http = Number($('#ap-http', m.el).value), https = Number($('#ap-https', m.el).value);
    m.close();
    const pm = progressModal('Changement de port', 'Modification de la configuration...');
    try {
      const r = await api.setApachePorts(d.id, http, https);
      await api.serverStop(d.id, 'apache');
      const s = await api.startService('apache', d.id);
      pm.done({ ok: s.ok, message: `${r.message} ${s.ok ? 'Apache a redémarré.' : 'Apache n\'a pas redémarré.'}`, log: s.log, issues: s.issues });
    } catch (err) { pm.done({ ok: false, message: err.message }); }
    loadServer(true);
  };
}

async function backupDialog(d) {
  const running = d.mysql && d.mysql.running;
  const m = openModal({
    title: `Sauvegarder ${d.type}`,
    wide: true,
    body: `
      <div class="seg" style="align-self:flex-start"><button class="on" data-type="dump">Export SQL des bases</button><button data-type="raw">Copie du dossier data</button></div>
      <div data-pane="dump">
        ${running ? `<div class="field"><label>Bases à sauvegarder</label><div id="bk-dbs" class="faint"><span class="spinner" style="display:inline-block;vertical-align:middle"></span> Lecture des bases...</div></div>`
          : `<div class="alert error">${icon('alert')}<div class="grow">MySQL est arrêté : l'export SQL a besoin de MySQL en marche. Démarre-le, ou utilise la copie du dossier data.</div></div>`}
      </div>
      <div data-pane="raw" hidden><div class="alert info">${icon('info')}<div class="grow">Copie brute du dossier <span class="mono">${esc(d.mysql ? d.mysql.datadir : '')}</span>. Utile quand MySQL ne démarre plus. <b>MySQL doit être arrêté</b> pour une copie cohérente.</div></div></div>
      <label class="check"><input type="checkbox" id="bk-config" checked> <span>Inclure les fichiers de configuration (my.ini, httpd.conf, php.ini)</span></label>
      <div class="field"><label for="bk-label">Nom (facultatif)</label><input id="bk-label" placeholder="ex. avant-mise-a-jour"></div>
      <details class="trace"><summary>Compte MySQL : <b>${esc(serverState.creds.user)}</b></summary>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
          <div class="field"><label for="bk-u">Utilisateur</label><input id="bk-u" value="${esc(serverState.creds.user)}"></div>
          <div class="field"><label for="bk-p">Mot de passe</label><input id="bk-p" type="password" value="${esc(serverState.creds.password)}"></div>
        </div></details>`,
    foot: `<span class="grow" data-hint></span><button class="btn" data-close>Annuler</button><button class="btn primary" data-go ${running ? '' : 'disabled'}>${icon('archive')} Sauvegarder</button>`
  });
  let type = 'dump';
  $$('[data-type]', m.el).forEach(x => { x.onclick = () => {
    type = x.dataset.type;
    $$('[data-type]', m.el).forEach(y => y.classList.toggle('on', y === x));
    $$('[data-pane]', m.el).forEach(p => { p.hidden = p.dataset.pane !== type; });
    $('[data-go]', m.el).disabled = type === 'dump' ? !running : running;
    $('[data-hint]', m.el).textContent = type === 'raw' && running ? 'Arrête MySQL pour faire une copie brute.' : '';
  }; });
  const creds = () => ({ user: $('#bk-u', m.el).value.trim() || 'root', password: $('#bk-p', m.el).value });
  if (running) {
    try {
      const dbs = await api.backupDatabases(d.id, creds());
      $('#bk-dbs', m.el).className = '';
      $('#bk-dbs', m.el).innerHTML = `<label class="check" style="margin-bottom:6px"><input type="checkbox" id="bk-all" checked> <b>Toutes (${dbs.length})</b></label>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:4px 16px;max-height:240px;overflow:auto">${dbs.map(x => `<label class="check" style="align-items:center;white-space:nowrap"><input type="checkbox" data-db="${esc(x.name)}" checked> <span class="mono">${esc(x.name)}</span> <span class="faint small">${x.tables} tables · ${fmtSize(x.size)}</span>${x.broken ? ` <span class="small" style="color:var(--danger)" title="Tables inaccessibles (doesn't exist in engine) : elles seront ignorées">${x.broken} illisibles</span>` : ''}</label>`).join('')}</div>
        ${dbs.some(x => x.broken) ? `<div class="faint small" style="margin-top:6px">Les tables illisibles sont ignorées : le reste de chaque base est sauvegardé.</div>` : ''}`;
      $('#bk-all', m.el).onchange = e => $$('[data-db]', m.el).forEach(c => { c.checked = e.target.checked; });
    } catch (err) { $('#bk-dbs', m.el).innerHTML = `<span style="color:var(--danger)">${esc(err.message)}</span>`; }
  }
  $('[data-go]', m.el).onclick = async () => {
    const dbs = $$('[data-db]', m.el).filter(c => c.checked).map(c => c.dataset.db);
    if (type === 'dump' && !dbs.length) return toast({ kind: 'warn', title: 'Aucune base sélectionnée', text: '' });
    const all = type === 'dump' && $('#bk-all', m.el) && $('#bk-all', m.el).checked;
    const label = $('#bk-label', m.el).value.trim();
    const config = $('#bk-config', m.el).checked;
    serverState.creds = creds();
    m.body.innerHTML = `<div class="run-state" data-state><span class="spinner"></span> Préparation...</div><div class="faint small">Les tables ne sont pas bloquées pendant l'export : tu peux continuer à travailler.</div>`;
    m.foot.innerHTML = '<button class="btn" data-close>Fermer</button>';
    backupProgress = st => { const s = $('[data-state]', m.el); if (s) s.innerHTML = `<span class="spinner"></span> ${esc(st)}`; };
    try {
      const r = await api.backupCreate(d.id, { type, databases: all ? null : dbs, config, label, creds: serverState.creds });
      backupProgress = null;
      $('[data-state]', m.el).className = 'run-state ok';
      const skipped = r.databases.reduce((n, x) => n + ((x.skipped || []).length), 0);
      $('[data-state]', m.el).innerHTML = `${icon('check')} Sauvegarde terminée : ${r.databases.length} base${r.databases.length > 1 ? 's' : ''}, ${fmtSize(r.size)}`;
      if (skipped) m.body.insertAdjacentHTML('beforeend', `<div class="alert warn">${icon('alert')}<div class="grow">${skipped} table${skipped > 1 ? 's' : ''} illisible${skipped > 1 ? 's' : ''} ignorée${skipped > 1 ? 's' : ''} (${esc(r.databases.filter(x => (x.skipped || []).length).map(x => x.name).join(', '))}).</div></div>`);
      m.foot.innerHTML = `<button class="btn" id="bk-show">${icon('folder')} Ouvrir le dossier</button><button class="btn primary" data-close>Fermer</button>`;
      $('#bk-show', m.el).onclick = () => api.openBackupFolder();
    } catch (err) {
      backupProgress = null;
      $('[data-state]', m.el).className = 'run-state err';
      $('[data-state]', m.el).innerHTML = `${icon('alert')} ${esc(err.message)}`;
    }
    serverState.backups = await api.backupInfo();
    renderServer(); loadServerLog();
  };
}
let backupProgress = null;

function restoreDialog(d, b, preselect) {
  if (!b) return;
  if (preselect) b = { ...b, databases: [...b.databases].sort((x, y) => (x.name === preselect ? -1 : y.name === preselect ? 1 : 0)) };
  const m = openModal({
    title: 'Restaurer une base',
    body: `
      <div class="muted">Sauvegarde du ${esc(new Date(b.date).toLocaleString('fr-FR'))} · ${esc(b.server.type)}</div>
      ${b.server.base !== d.id ? `<div class="alert info">${icon('info')}<div class="grow">Cette sauvegarde vient de ${esc(b.server.type)} : elle sera restaurée dans le MySQL de <b>${esc(d.type)}</b>.</div></div>` : ''}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="field"><label for="rs-db">Base de la sauvegarde</label><select id="rs-db">${b.databases.map(x => `<option>${esc(x.name)}</option>`).join('')}</select></div>
        <div class="field"><label for="rs-target">Restaurer dans la base</label><input id="rs-target" class="mono" value="${esc(b.databases[0] ? b.databases[0].name : '')}"></div>
      </div>
      <div class="alert warn">${icon('info')}<div class="grow">Si la base cible existe, son contenu est remplacé. <b>Elle est d'abord sauvegardée automatiquement</b> (sauvegarde « avant restauration »). Pour comparer sans risque, choisis un autre nom (ex. <span class="mono">ma_base_restauree</span>).</div></div>`,
    foot: `<button class="btn" data-close>Annuler</button><button class="btn primary" data-go>Restaurer</button>`
  });
  $('#rs-db', m.el).onchange = e => { $('#rs-target', m.el).value = e.target.value; };
  $('[data-go]', m.el).onclick = async () => {
    const db = $('#rs-db', m.el).value, target = $('#rs-target', m.el).value.trim();
    m.body.innerHTML = `<div class="run-state" data-state><span class="spinner"></span> Restauration de « ${esc(target)} »...</div>`;
    m.foot.innerHTML = '<button class="btn" data-close>Fermer</button>';
    backupProgress = st => { const s = $('[data-state]', m.el); if (s) s.innerHTML = `<span class="spinner"></span> ${esc(st)}`; };
    try {
      const r = await api.backupRestore(d.id, b.name, db, target, serverState.creds);
      $('[data-state]', m.el).className = 'run-state ok';
      $('[data-state]', m.el).innerHTML = `${icon('check')} ${esc(r.message)}`;
      if (r.safety) m.body.insertAdjacentHTML('beforeend', `<div class="faint small">L'ancienne version de la base est gardée dans la sauvegarde « ${esc(r.safety)} ».</div>`);
    } catch (err) {
      $('[data-state]', m.el).className = 'run-state err';
      $('[data-state]', m.el).innerHTML = `${icon('alert')} ${esc(err.message)}`;
    }
    backupProgress = null;
    serverState.backups = await api.backupInfo();
    renderServer(); loadServerLog();
  };
}

api.on('backup', p => {
  const text = { dump: `Export de « ${p.db} » (${p.i}/${p.n})...`, raw: 'Copie du dossier data...', zip: 'Compression de la sauvegarde...', safety: `Sauvegarde de sécurité de « ${p.db} »...`, extract: 'Lecture de la sauvegarde...', import: `Import dans « ${p.db} »...` }[p.step];
  if (backupProgress && text) return backupProgress(text);
  if (p.step === 'done' && p.label === 'auto') toast({ kind: 'success', title: 'Sauvegarde automatique faite', text: `${esc(p.server)} · ${esc(p.name)}`, onClick: () => setView('server') });
  if (p.step === 'error' && !backupProgress) toast({ kind: 'error', title: 'Sauvegarde échouée', text: esc(p.message), onClick: () => setView('server'), timeout: 12000 });
});

// ---------- Évènements du serveur ----------
let errTimer = null;
api.on('log', ({ path, text, kind }) => {
  // Sortie des seeders en cours dans leur fenêtre
  if (seedModal && seedModal.path === path && kind === 'action') { seedModal.out.textContent += text; seedModal.out.scrollTop = seedModal.out.scrollHeight; }
  let t = (logs.get(path) || '') + text;
  if (t.length > MAX_LOG) t = t.slice(-MAX_LOG);
  logs.set(path, t);
  if (actionModal && actionModal.path === path && kind === 'action') {
    const o = actionModal.out;
    const atBottom = o.scrollHeight - o.scrollTop - o.clientHeight < 40;
    o.textContent += text;
    if (atBottom) o.scrollTop = o.scrollHeight;
  }
  if (path === selected && view === 'projects') {
    const c = $('#console');
    if (c) { c.textContent = t; if (follow) c.scrollTop = c.scrollHeight; }
    // Nouvelle erreur dans la console : on relance l'analyse (regroupée).
    if (/error|exception|fatal|failed|ERR!|SQLSTATE|⨯/i.test(text)) {
      clearTimeout(errTimer);
      errTimer = setTimeout(() => loadErrors(path), 1500);
    }
  }
});

api.on('status', ({ path, status, message, external }) => {
  const p = project(path);
  if (!p) return;
  const before = p.status;
  p.status = status;
  if (external) p.external = external;
  if (status === 'stopped') p.external = null;
  if (message) messages.set(path, message);
  if (status === 'running' && before !== 'running') {
    toast({ kind: 'success', title: `${p.name} est en ligne`, text: `<span class="mono">http://localhost:${p.config.port}</span>`, onClick: () => api.openUrl(`http://localhost:${p.config.port}`) });
  }
  if (status === 'error' && message && path !== selected) toast({ kind: 'error', title: `${p.name} n'a pas démarré`, text: esc(message), onClick: () => select(path), timeout: 10000 });
  renderList();
  if (view === 'projects' && path === selected) renderDetail();
});

api.on('action', ({ path, running, id, code, blocked, target }) => {
  if (running) runningAction.set(path, id); else runningAction.delete(path);
  if (blocked) {
    if (actionModal && actionModal.path === path && actionModal.id === id) finishBlockedModal(target);
    else toast({ kind: 'error', title: 'Action bloquée', text: `Le MySQL qui répond n'est pas celui de ${esc(target && target.projectServer ? target.projectServer.type : 'ce projet')}. Ouvre l'action depuis le projet pour basculer.`, onClick: () => select(path) });
    return;
  }
  if (!running) {
    if (actionModal && actionModal.path === path && actionModal.id === id) finishActionModal(code);
    else {
      const p = project(path);
      const a = p && p.actions.find(x => x.id === id);
      toast(code === 0
        ? { kind: 'success', title: `${a ? a.label : id} : terminé`, text: esc(p ? p.name : path) }
        : { kind: 'error', title: `${a ? a.label : id} : échec (code ${code})`, text: 'Voir l\'onglet Erreurs du projet.', onClick: () => select(path, 'errors') });
    }
    loadErrors(path);
    dbCache.delete(path);
    api.snapshot().then(apply);
  } else if (path === selected && view === 'projects' && (tabOf.get(path) || 'overview') === 'overview') renderDetail();
});

// .env d'un projet lancé modifié : DevLauncher l'a appliqué (relecture immédiate ou redémarrage)
api.on('env-changed', e => {
  toast({ kind: 'info', title: `.env de ${e.name} modifié`, timeout: 9000,
    text: `<span class="mono">${esc(e.keys.slice(0, 6).join(', '))}${e.keys.length > 6 ? ' …' : ''}</span><br>${esc(e.action.charAt(0).toUpperCase() + e.action.slice(1))}.`, onClick: () => select(e.path, 'console') });
});

// Projet en cours d'exécution trouvé hors des dossiers des serveurs : ajouté à la liste automatiquement.
api.on('discovered', list => {
  api.snapshot().then(apply);
  for (const d of list) toast({ kind: 'info', title: 'Projet détecté hors des serveurs', timeout: 12000,
    text: `<b>${esc(d.name)}</b> tourne depuis <span class="mono">${esc(d.path)}</span> : il est ajouté à la liste (groupe « Détectés hors des serveurs »).`, onClick: () => select(d.path) });
});

api.on('external-found', found => {
  for (const f of found) {
    toast({ kind: 'warn', title: 'Projet déjà lancé', timeout: 10000, text: `<b>${esc(f.name)}</b> tourne sur le port ${f.ports.join(', ')}, lancé en dehors de DevLauncher.`, onClick: () => select(f.path) });
  }
});

api.on('mail', m => {
  state.mail.unread = (state.mail.unread || 0) + 1;
  renderNav();
  toast({ kind: 'info', title: 'Nouveau mail capturé', text: `<b>${esc(m.subject)}</b><br>${m.projectName ? esc(m.projectName) + ' · ' : ''}à ${esc(m.to.join(', '))}`, onClick: () => { setView('mail'); setTimeout(() => openMail(m.id), 150); } });
  if (view === 'mail') { mailState.list.unshift(m); renderMail(); }
});

api.on('services', s => { services = s; renderStatusbar(); });

// ---------- Aide : guide d'utilisation intégré ----------
// Le guide (même page que celle livrée avec l'installateur) s'affiche dans l'application, ouvert sur la section utile.
const HELP_TOPICS = [
  ['depannage', 'Un projet ne démarre pas'],
  ['ports', 'Port déjà utilisé'],
  ['serveur', 'MySQL ou Apache en panne'],
  ['database', 'Connexion à la base'],
  ['creer', 'Créer un projet'],
  ['mails', 'Voir les e-mails envoyés'],
  ['file', 'E-mails en file d\'attente'],
  ['uml', 'Diagrammes UML']
];
// Section du guide correspondant à l'écran affiché (bouton « ? » et touche F1)
const TAB_HELP = { seeders: 'database', overview: 'lancer', console: 'lancer', errors: 'erreurs', logs: 'logs', database: 'database', queue: 'file', uml: 'uml' };
const guideState = { anchor: null, q: '' };

function helpAnchorForScreen() {
  if (view === 'mail') return 'mails';
  if (view === 'server') return 'serveur';
  if (view === 'projects' && selected) return TAB_HELP[tabOf.get(selected) || 'overview'] || 'lancer';
  return null;
}

function openGuide(anchor) {
  guideState.anchor = anchor || null;
  setView('guide');
}

function renderGuide() {
  const el = $('#view-guide');
  if (!$('#guide-frame', el)) {
    el.innerHTML = `
      <div class="guide-bar">
        <div class="guide-title">${icon('book')}<div><b>Guide d'utilisation</b><span>Bloqué ? Choisis ta situation ou cherche un mot.</span></div></div>
        <div class="search guide-search">
          <span class="search-icon">${icon('search')}</span>
          <input id="guide-q" type="search" placeholder="Rechercher dans le guide" autocomplete="off">
        </div>
        <button class="btn" id="guide-ext" title="Ouvrir le guide dans le navigateur">${icon('external')} Navigateur</button>
      </div>
      <div class="guide-topics">${HELP_TOPICS.map(([a, l]) => `<button class="chip" data-topic="${a}">${esc(l)}</button>`).join('')}</div>
      <div class="guide-wrap">
        <div class="guide-loading" id="guide-loading">${skeleton('doc')}</div>
        <iframe id="guide-frame" title="Guide d'utilisation" src="/guide"></iframe>
      </div>`;
    const frame = $('#guide-frame', el);
    frame.addEventListener('load', () => {
      $('#guide-loading', el).classList.add('gone');
      syncGuideTheme();
      if (guideState.anchor) goGuideAnchor(guideState.anchor);
    });
    $$('[data-topic]', el).forEach(b => { b.onclick = () => goGuideAnchor(b.dataset.topic); });
    $('#guide-ext', el).onclick = () => api.openUrl(`${location.origin}/guide${guideState.anchor ? '#' + guideState.anchor : ''}`);
    const q = $('#guide-q', el);
    q.onkeydown = e => { if (e.key === 'Enter') findInGuide(q.value, e.shiftKey); };
    q.oninput = () => { if (!q.value) clearGuideFind(); };
  } else if (guideState.anchor) goGuideAnchor(guideState.anchor);
}

function guideDoc() { const f = $('#guide-frame'); try { return f && f.contentDocument; } catch { return null; } }
function syncGuideTheme() { const d = guideDoc(); if (d) d.documentElement.dataset.theme = document.documentElement.dataset.theme; }

function goGuideAnchor(anchor) {
  guideState.anchor = anchor;
  $$('[data-topic]').forEach(b => b.classList.toggle('on', b.dataset.topic === anchor));
  const d = guideDoc();
  const target = d && d.getElementById(anchor);
  if (!target) return;
  target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  // Repère visuel bref sur la section ouverte
  target.classList.remove('dl-flash'); void target.offsetWidth; target.classList.add('dl-flash');
  if (!d.getElementById('dl-flash-style')) {
    const st = d.createElement('style'); st.id = 'dl-flash-style';
    st.textContent = '@keyframes dlFlash{0%{box-shadow:0 0 0 3px rgba(3,115,187,.45)}100%{box-shadow:0 0 0 3px rgba(3,115,187,0)}}.dl-flash{animation:dlFlash 1.6s ease-out;border-radius:8px}mark.dl-hit{background:#ffe08a;color:inherit;border-radius:2px}mark.dl-hit.cur{background:#f7941d;color:#fff}';
    d.head.appendChild(st);
  }
}

// Recherche : surligne toutes les occurrences, Entrée passe à la suivante (Maj+Entrée : précédente).
let guideHits = [], guideHit = -1, guideHitQ = '';
function clearGuideFind() {
  const d = guideDoc(); if (!d) return;
  d.querySelectorAll('mark.dl-hit').forEach(m => m.replaceWith(d.createTextNode(m.textContent)));
  d.body.normalize();
  guideHits = []; guideHit = -1; guideHitQ = '';
}
function findInGuide(q, back) {
  const d = guideDoc(); q = q.trim();
  if (!d || !q) return;
  if (q !== guideHitQ) {
    clearGuideFind();
    guideHitQ = q;
    const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    const walker = d.createTreeWalker(d.querySelector('main') || d.body, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.parentElement.closest('script,style,nav') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
    const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const n of nodes) {
      const text = n.nodeValue; re.lastIndex = 0;
      if (!re.test(text)) continue;
      const frag = d.createDocumentFragment(); let last = 0; re.lastIndex = 0; let m;
      while ((m = re.exec(text))) {
        frag.appendChild(d.createTextNode(text.slice(last, m.index)));
        const mk = d.createElement('mark'); mk.className = 'dl-hit'; mk.textContent = m[0]; frag.appendChild(mk); guideHits.push(mk);
        last = m.index + m[0].length;
      }
      frag.appendChild(d.createTextNode(text.slice(last)));
      n.replaceWith(frag);
    }
  }
  if (!guideHits.length) return toast({ kind: 'warn', title: 'Aucun résultat', text: `« ${esc(q)} » n'apparaît pas dans le guide.`, timeout: 3000 });
  if (guideHits[guideHit]) guideHits[guideHit].classList.remove('cur');
  guideHit = (guideHit + (back ? -1 : 1) + guideHits.length) % guideHits.length;
  guideHits[guideHit].classList.add('cur');
  guideHits[guideHit].scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Boutons « ? » contextuels : n'importe quel élément [data-help="section"] ouvre le guide sur cette section.
document.addEventListener('click', e => {
  const h = e.target.closest('[data-help]');
  if (!h) return;
  e.preventDefault();
  // Depuis une fenêtre : on la ferme proprement avant d'ouvrir le guide.
  const ov = h.closest('.overlay'); const close = ov && ov.querySelector('[data-close]'); if (close) close.click();
  openGuide(h.dataset.help);
});
document.addEventListener('keydown', e => { if (e.key === 'F1') { e.preventDefault(); openGuide(helpAnchorForScreen()); } });
const helpBtn = (anchor, label = 'Aide') => `<button class="btn ghost sm help-btn" data-help="${anchor}" title="Ouvrir le guide sur ce sujet (F1)">${icon('help')} ${esc(label)}</button>`;

// ---------- Nouveau projet ----------
// Assistant en trois étapes : type, paramètres (nom, emplacement, version, options), vérification.
// DevLauncher exécute ensuite lui-même les commandes de création.
const NP_GROUPS = [['app', 'Applications complètes'], ['ui', 'Interfaces et sites'], ['base', 'API et site simple']];
const NP_STEPS = ['Type de projet', 'Paramètres', 'Vérification'];
let createModal = null;

// Logo officiel du framework sur une pastille teintée de sa couleur ; initiales si le logo manque.
const npLogo = (t, size = '') => `<span class="np-logo ${size}" style="--c:${t.color}">${window.logoSvg(t.id) || `<b>${esc(t.mark)}</b>`}</span>`;

async function newProjectDialog() {
  const info = await api.createInfo();
  if (info.state && info.state.running) return createProgress(info.state, (await api.createState()).log);
  const first = info.types.find(t => t.available) || info.types[0];
  const form = { type: first.id, version: null, parent: (info.destinations[0] || {}).path || '', name: '', opts: {}, step: 0 };
  const destinations = [...info.destinations];
  const m = openModal({ title: 'Nouveau projet', wide: true, body: '', foot: ' ' });
  $('.modal', m.el).classList.add('np-modal');
  const type = () => info.types.find(t => t.id === form.type);
  const lowerOnly = () => !['laravel', 'php'].includes(form.type);

  // Valeurs par défaut des options et de la version à chaque changement de type
  const resetType = () => {
    const t = type();
    form.version = (t.versions.find(v => v.available) || t.versions[0]).id;
    form.opts = Object.fromEntries(t.options.map(o => [o.key, o.choices ? o.choices[0][0] : o.value]));
    form.name = normalizeName(form.name);
  };
  const normalizeName = v => { v = String(v || '').replace(/\s+/g, '-'); return lowerOnly() ? v.toLowerCase() : v; };

  let lastStep = 0;
  const stepper = () => `<ol class="np-stepper">${NP_STEPS.map((s, i) => `<li class="${i === form.step ? 'on' : i < form.step ? 'done' : ''}"><span>${i < form.step ? icon('check') : i + 1}</span>${s}</li>`).join('')}</ol>`;
  const render = () => {
    m.body.innerHTML = stepper() + `<div class="np-page ${form.step !== lastStep ? (form.step > lastStep ? 'step-fwd' : 'step-back') : ''}">${[pageType, pageParams, pageReview][form.step]()}</div>`;
    lastStep = form.step;
    m.foot.innerHTML = foot();
    bind();
  };

  // --- Étape 1 : type
  const pageType = () => NP_GROUPS.map(([g, label]) => `
    <section class="np-group"><h3>${label}</h3><div class="np-types">${info.types.filter(t => t.group === g).map(t => `
      <button class="np-type ${t.id === form.type ? 'on' : ''}" data-type="${t.id}" ${t.available ? '' : 'disabled'}>
        ${npLogo(t)}
        <span class="np-type-text"><b>${esc(t.label)}</b><span>${esc(t.available ? t.desc : t.missing.join(' '))}</span>
          ${t.available && t.versions.length > 1 ? `<em>${esc(t.versions.filter(v => v.available).map(v => (v.id === 'latest' ? 'Dernière' : v.label.replace(/^\D+/, ''))).join(' · '))}</em>` : ''}</span>
        <span class="np-radio"></span>
      </button>`).join('')}</div></section>`).join('');

  // --- Étape 2 : paramètres
  const pageParams = () => {
    const t = type();
    const ver = t.versions.find(v => v.id === form.version);
    return `<div class="np-params">
      <aside class="np-side">
        ${npLogo(t, 'lg')}
        <b>${esc(t.label)}</b>
        <p>${esc(t.desc)}</p>
        <button class="btn sm ghost" data-back>Changer de type</button>
      </aside>
      <div class="np-form">
        <div class="np-field">
          <label for="np-name">Nom du projet</label>
          <input id="np-name" value="${esc(form.name)}" placeholder="${lowerOnly() ? 'mon-projet' : 'MonProjet'}" autocomplete="off" spellcheck="false" data-autofocus>
          <div class="hint-line" data-namehint></div>
        </div>
        <div class="np-field">
          <label for="np-parent">Emplacement</label>
          <div class="np-row">
            <select id="np-parent">${destinations.map(d => `<option value="${esc(d.path)}" ${d.path === form.parent ? 'selected' : ''}>${esc(d.label)}</option>`).join('')}</select>
            <button class="btn" data-pick>${icon('folder')} Parcourir</button>
          </div>
          <div class="np-path">${icon('folder')}<span class="mono" data-where></span></div>
        </div>
        <div class="np-field">
          <label>Version</label>
          <div class="np-versions">${t.versions.map(v => `
            <button class="np-version ${v.id === form.version ? 'on' : ''}" data-ver="${esc(v.id)}" ${v.available ? '' : 'disabled'} title="${esc(v.detail || '')}">
              ${esc(v.label)}${v.tag ? `<span class="np-tag">${esc(v.tag)}</span>` : ''}${v.eol ? '<span class="np-tag warn">Fin de support</span>' : ''}
            </button>`).join('')}</div>
          ${ver && ver.detail ? `<div class="faint small">${ver.available ? 'Exécuté avec' : ''} ${esc(ver.detail)}</div>` : ''}
          ${ver && ver.eol ? `<div class="hint-line warn">${icon('alert')} Cette version ne reçoit plus de correctifs de sécurité. À réserver à la maintenance d'un projet existant.</div>` : ''}
        </div>
        ${t.options.length ? `<div class="np-field"><label>Options</label><div class="np-options">${t.options.map(o => o.choices ? `
          <div class="np-choice" data-choice="${o.key}"><span class="np-opt-title">${esc(o.label)}</span><div class="np-choice-list">${o.choices.map(([v, l, d]) => `
            <button class="${form.opts[o.key] === v ? 'on' : ''}" data-v="${v}"><b>${esc(l)}</b><span>${esc(d)}</span></button>`).join('')}</div></div>` : `
          <label class="np-switch"><span><b>${esc(o.label)}</b><span>${esc(o.desc || '')}</span></span>
            <span class="toggle"><input type="checkbox" data-opt="${o.key}" ${form.opts[o.key] ? 'checked' : ''}><span class="track"></span></span></label>`).join('')}</div></div>` : ''}
      </div>
    </div>`;
  };

  // --- Étape 3 : vérification
  let preview = null, previewErr = '';
  const pageReview = () => {
    const t = type();
    if (previewErr) return `<div class="alert error">${icon('alert')}<div class="grow">${esc(previewErr)}</div></div>`;
    if (!preview) return '<div class="run-state"><span class="spinner"></span> Préparation...</div>';
    const opts = t.options.map(o => o.choices ? (o.choices.find(c => c[0] === form.opts[o.key]) || [])[1] : form.opts[o.key] ? o.label : null).filter(Boolean);
    return `<div class="np-review">
      <div class="np-summary">
        <div class="np-summary-head">${npLogo(t, 'lg')}<div><b>${esc(form.name)}</b><span>${esc(t.label)} · ${esc(preview.version)}</span></div></div>
        <dl>
          <dt>Dossier</dt><dd class="mono">${esc(preview.dir)}</dd>
          <dt>Adresse</dt><dd class="mono">http://localhost:${preview.port}</dd>
          ${preview.php ? `<dt>PHP</dt><dd>${esc(preview.php.version)}${preview.php.tested ? '' : ' <span class="np-tag warn">plus récent que prévu</span>'}</dd>` : ''}
          ${opts.length ? `<dt>Options</dt><dd>${opts.map(o => `<span class="np-chip">${esc(o)}</span>`).join('')}</dd>` : ''}
        </dl>
      </div>
      ${preview.eol ? `<div class="alert warn np-eol">${icon('alert')}<div class="grow"><b>${esc(preview.version)} n'est plus maintenue.</b> Elle peut contenir des failles de sécurité connues : DevLauncher l'installe parce que tu l'as choisie, mais évite de la mettre en ligne.</div></div>` : ''}
      <div class="np-plan"><h3>Ce que DevLauncher va faire</h3><ol>${preview.steps.map(s => `<li>${esc(s)}</li>`).join('')}<li>Ajouter le projet à la liste, prêt à lancer</li></ol>
        <p class="faint small">Les téléchargements peuvent prendre quelques minutes. Rien n'est à saisir pendant la création.</p></div>
    </div>`;
  };

  const foot = () => {
    if (form.step === 0) return `${helpBtn('creer', 'Besoin d\'aide ?')}<span class="grow"></span><button class="btn" data-close>Annuler</button><button class="btn primary" data-next ${type().available ? '' : 'disabled'}>Continuer</button>`;
    if (form.step === 1) return `<button class="btn" data-back>Retour</button><span class="grow"></span><button class="btn" data-close>Annuler</button><button class="btn primary" data-next disabled>Continuer</button>`;
    return `<button class="btn" data-back>Retour</button><span class="grow"></span><button class="btn" data-close>Annuler</button><button class="btn primary" data-go ${preview ? '' : 'disabled'}>${icon('plus')} Créer le projet</button>`;
  };

  const go = step => { form.step = step; render(); if (step === 2) loadPreview(); };
  const loadPreview = async () => {
    preview = null; previewErr = '';
    try { preview = await api.createPreview({ type: form.type, parent: form.parent, name: form.name, version: form.version, ...form.opts }); }
    catch (err) { previewErr = err.message; }
    if (form.step === 2) render();
  };

  let checkSeq = 0;
  const validate = async () => {
    const name = form.name.trim();
    const where = $('[data-where]', m.el), hint = $('[data-namehint]', m.el), next = $('[data-next]', m.el);
    if (!hint) return;
    where.textContent = form.parent ? `${form.parent.replace(/[\\/]+$/, '')}\\${name || '…'}` : 'Choisis un emplacement';
    const re = lowerOnly() ? /^[a-z0-9][a-z0-9._-]{0,63}$/ : /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
    let msg = '', ok = false;
    if (!name) msg = '';
    else if (!re.test(name)) msg = lowerOnly() ? 'Minuscules, chiffres, point, tiret et _ uniquement.' : 'Lettres, chiffres, point, tiret et _ uniquement.';
    else if (!form.parent) msg = 'Choisis un emplacement.';
    else {
      const seq = ++checkSeq;
      const exists = await api.createExists(form.parent, name);
      if (seq !== checkSeq) return;
      if (exists) msg = 'Un dossier porte déjà ce nom à cet emplacement.'; else ok = true;
    }
    hint.className = `hint-line ${msg ? 'err' : ok ? 'ok' : ''}`;
    hint.innerHTML = msg ? `${icon('alert')} ${esc(msg)}` : ok ? `${icon('check')} Nom disponible` : `<span class="faint">${lowerOnly() ? 'Les espaces deviennent des tirets, en minuscules.' : 'Les espaces deviennent des tirets.'}</span>`;
    next.disabled = !ok;
  };

  const bind = () => {
    $$('[data-type]', m.el).forEach(b => {
      b.onclick = () => { form.type = b.dataset.type; resetType(); $$('[data-type]', m.el).forEach(x => x.classList.toggle('on', x === b)); $('[data-next]', m.el).disabled = false; };
      b.ondblclick = () => go(1);
    });
    $$('[data-back]', m.el).forEach(b => { b.onclick = () => go(form.step - 1); });
    const next = $('[data-next]', m.el); if (next) next.onclick = () => go(form.step + 1);
    const nameEl = $('#np-name', m.el);
    if (nameEl) {
      nameEl.oninput = () => { const v = normalizeName(nameEl.value); if (v !== nameEl.value) nameEl.value = v; form.name = v; validate(); };
      nameEl.onkeydown = e => { if (e.key === 'Enter' && !$('[data-next]', m.el).disabled) go(2); };
      nameEl.focus();
      validate();
    }
    const sel = $('#np-parent', m.el); if (sel) sel.onchange = () => { form.parent = sel.value; validate(); };
    const pick = $('[data-pick]', m.el); if (pick) pick.onclick = async () => {
      const dir = await api.createPickFolder();
      if (!dir) return;
      if (!destinations.some(d => d.path === dir)) destinations.unshift({ path: dir, label: dir });
      form.parent = dir; render();
    };
    $$('[data-ver]', m.el).forEach(b => { b.onclick = () => { form.version = b.dataset.ver; render(); }; });
    $$('[data-opt]', m.el).forEach(c => { c.onchange = () => { form.opts[c.dataset.opt] = c.checked; }; });
    $$('[data-choice]', m.el).forEach(s => $$('button', s).forEach(b => { b.onclick = () => {
      $$('button', s).forEach(x => x.classList.toggle('on', x === b)); form.opts[s.dataset.choice] = b.dataset.v;
    }; }));
    const create = $('[data-go]', m.el); if (create) create.onclick = async () => {
      create.disabled = true; create.innerHTML = '<span class="spinner"></span> Démarrage...';
      try {
        const s = await api.createProject({ type: form.type, parent: form.parent, name: form.name, version: form.version, ...form.opts });
        m.close();
        createProgress(s, '');
      } catch (err) { previewErr = err.message; render(); }
    };
  };

  resetType();
  render();
}

function createProgress(s, log) {
  const m = openModal({
    title: `Création de « ${s.name} »`,
    wide: true,
    body: `<div class="run-state" data-state></div><ol class="create-steps" data-steps></ol><pre class="console create-console" data-out></pre>`,
    foot: ' ',
    onClose: () => { clearInterval(timer); if (createModal && createModal.m === m) createModal = null; }
  });
  // Durée de l'étape en cours, mise à jour chaque seconde : un téléchargement lent reste visiblement actif.
  const timer = setInterval(() => {
    const st = createModal && createModal.m === m && createModal.state.steps.find(x => x.state === 'run');
    const el = $('[data-steps] .st-run .st-time', m.el);
    if (st && el) el.textContent = fmtDuration(Date.now() - st.startedAt);
    const slow = $('[data-slow]', m.el);
    if (st && slow) slow.hidden = Date.now() - st.startedAt < 90000;
  }, 1000);
  createModal = { m, out: $('[data-out]', m.el), state: s };
  createModal.out.textContent = log || '';
  renderCreate(s);
  // Les premières lignes ont pu partir avant l'ouverture de la fenêtre : on recharge le journal complet.
  const cm = createModal;
  api.createState().then(r => { if (createModal === cm && r.log) { cm.out.textContent = r.log; cm.out.scrollTop = cm.out.scrollHeight; } });
}

const fmtDuration = ms => { const t = Math.max(0, Math.round(ms / 1000)); return t < 60 ? `${t} s` : `${Math.floor(t / 60)} min ${String(t % 60).padStart(2, '0')} s`; };

function renderCreate(s, done) {
  const cm = createModal;
  if (!cm) return;
  cm.state = s;
  const ICON = { todo: '', run: '<span class="spinner"></span>', done: icon('check'), error: icon('alert'), skip: '' };
  const time = st => (st.state === 'run' ? fmtDuration(Date.now() - st.startedAt) : st.endedAt && st.startedAt ? fmtDuration(st.endedAt - st.startedAt) : '');
  $('[data-steps]', cm.m.el).innerHTML = s.steps.map(st => `<li class="st-${st.state}"><span class="st-i">${ICON[st.state]}</span>${esc(st.label)}${st.state === 'skip' ? ' <span class="faint">(non faite)</span>' : ''}<span class="st-time">${time(st)}</span></li>`).join('');
  const stateEl = $('[data-state]', cm.m.el);
  if (s.running) {
    stateEl.className = 'run-state';
    stateEl.innerHTML = '<span class="spinner"></span> Création en cours. Le téléchargement peut prendre plusieurs minutes.'
      + '<span class="create-slow" data-slow hidden>La connexion semble lente : l\'étape continue même si rien ne s\'affiche.</span>';
    cm.m.foot.innerHTML = '<span class="grow faint small">Tu peux fermer cette fenêtre : la création continue (bouton « Nouveau projet » pour la revoir).</span><button class="btn danger-outline" data-cancel>Annuler la création</button><button class="btn" data-close>Fermer</button>';
    $('[data-cancel]', cm.m.el).onclick = async e => { e.target.disabled = true; await api.createCancel(); };
    return;
  }
  stateEl.className = `run-state ${s.ok ? 'ok' : 'err'}`;
  stateEl.innerHTML = s.ok ? `${icon('check')} Projet prêt, port ${s.port}.`
    : s.cancelled ? `${icon('alert')} Création annulée.${s.created ? ' Le dossier partiellement créé est conservé.' : ''}`
    : `${icon('alert')} Une étape a échoué : lis la sortie ci-dessous.${s.created ? ' Le dossier est conservé : tu peux relancer l\'étape depuis les actions du projet.' : ''}`;
  cm.m.foot.innerHTML = `${!s.ok && !s.cancelled ? helpBtn('depannage', 'Que faire ?') + '<span class="grow"></span>' : ''}${s.created ? `<button class="btn" data-folder>${icon('folder')} Ouvrir le dossier</button>` : ''}
    ${s.found ? `<button class="btn primary" data-open>${icon('external')} Voir le projet</button>` : ''}<button class="btn ${s.found ? '' : 'primary'}" data-close>Fermer</button>`;
  const f = $('[data-folder]', cm.m.el); if (f) f.onclick = () => api.openFolder(s.dir);
  const o = $('[data-open]', cm.m.el); if (o) o.onclick = () => { cm.m.close(); setView('projects'); select(s.dir); };
  if (done) {
    api.snapshot().then(apply);
    if (!document.hasFocus() || !cm.m.el.isConnected) toast({ kind: s.ok ? 'success' : 'error', title: s.ok ? 'Projet créé' : 'Création interrompue', text: esc(s.name) });
  }
}

api.on('create', ev => {
  if (ev.log && createModal) {
    const out = createModal.out;
    const atEnd = out.scrollTop + out.clientHeight >= out.scrollHeight - 30;
    out.textContent += ev.log;
    if (out.textContent.length > MAX_LOG) out.textContent = out.textContent.slice(-MAX_LOG);
    if (atEnd) out.scrollTop = out.scrollHeight;
  }
  if (ev.state) {
    if (createModal) renderCreate(ev.state, ev.done);
    else if (ev.done) { api.snapshot().then(apply); toast({ kind: ev.state.ok ? 'success' : 'error', title: ev.state.ok ? 'Projet créé' : 'Création interrompue', text: esc(ev.state.name), onClick: () => ev.state.found && select(ev.state.dir) }); }
  }
});

// ---------- Ajouter des projets : dossier choisi ou recherche sur tout le PC ----------
function addDialog() {
  const m = openModal({
    title: 'Ajouter des projets',
    body: `<div class="add-choices">
      <button class="add-choice" data-c="search">${icon('search')}<b>Rechercher sur ce PC</b><span>DevLauncher parcourt ton dossier personnel (Bureau, Documents, Téléchargements, OneDrive…) et tes autres disques, puis te propose les projets trouvés.</span></button>
      <button class="add-choice" data-c="folder">${icon('folder')}<b>Choisir un dossier</b><span>Un projet précis, ou un dossier qui contient plusieurs projets (ils sont tous ajoutés).</span></button>
    </div>`,
    foot: '<button class="btn" data-close>Annuler</button>'
  });
  $('[data-c="search"]', m.el).onclick = () => { m.close(); searchPcDialog(); };
  $('[data-c="folder"]', m.el).onclick = async () => { m.close(); apply(await api.addRoot()); };
}

let pcSearchUi = null;
function searchPcDialog() {
  const found = [];
  const m = openModal({
    title: 'Rechercher des projets sur ce PC',
    wide: true,
    body: `<div class="run-state" data-state><span class="spinner"></span> Recherche en cours…</div>
      <div class="faint small mono pc-current" data-current>&nbsp;</div>
      <div class="pc-results" data-results><div class="faint small" data-empty>Les projets apparaissent ici au fur et à mesure.</div></div>`,
    foot: `<button class="btn" data-toggle hidden>Tout décocher</button><span class="grow"></span><button class="btn" data-stop>Arrêter la recherche</button><button class="btn primary" data-add disabled>${icon('plus')} Ajouter</button>`,
    onClose: () => { if (pcSearchUi && pcSearchUi.m === m) { if (pcSearchUi.running) api.cancelSearchPC(); pcSearchUi = null; } }
  });
  pcSearchUi = { m, running: true, found };
  const list = $('[data-results]', m.el), addBtn = $('[data-add]', m.el), toggle = $('[data-toggle]', m.el);
  const refreshAdd = () => {
    const n = $$('[data-pick]:checked', m.el).length;
    addBtn.disabled = !n;
    addBtn.innerHTML = `${icon('plus')} Ajouter ${n ? n + ' projet' + (n > 1 ? 's' : '') : ''}`;
    toggle.hidden = !found.length;
    toggle.textContent = n === found.length ? 'Tout décocher' : 'Tout cocher';
  };
  pcSearchUi.add = p => {
    found.push(p);
    const empty = $('[data-empty]', list); if (empty) empty.remove();
    const parent = p.path.replace(/\\[^\\]+$/, '');
    list.insertAdjacentHTML('beforeend', `<label class="pc-item">
      <input type="checkbox" data-pick="${esc(p.path)}" checked>
      <span class="pc-logo">${projectLogo(p) || icon('code')}</span>
      <span class="pc-text"><b>${esc(p.name)}</b><span>${esc(p.label)} · <span class="mono">${esc(parent)}</span></span></span>
    </label>`);
    const box = list.lastElementChild;
    $('input', box).onchange = refreshAdd;
    animateIn(box, 'panel-enter');
    refreshAdd();
  };
  pcSearchUi.progress = pr => { const el = $('[data-current]', m.el); if (el) el.textContent = `${pr.visited.toLocaleString('fr-FR')} dossiers parcourus · ${pr.dir}`; };
  pcSearchUi.done = r => {
    pcSearchUi.running = false;
    const st = $('[data-state]', m.el);
    st.className = 'run-state ' + (r.error ? 'err' : 'ok');
    st.innerHTML = r.error ? `${icon('alert')} Recherche interrompue : ${esc(r.error)}`
      : `${icon('check')} ${r.cancelled ? 'Recherche arrêtée' : 'Recherche terminée'} : ${found.length} nouveau${found.length > 1 ? 'x' : ''} projet${found.length > 1 ? 's' : ''} trouvé${found.length > 1 ? 's' : ''} (${(r.visited || 0).toLocaleString('fr-FR')} dossiers, ${Math.round((r.ms || 0) / 1000)} s).`
        + (r.truncated ? ' La recherche a atteint sa limite de durée : les dossiers très profonds peuvent être ajoutés avec « Choisir un dossier ».' : '');
    $('[data-current]', m.el).textContent = '';
    if (!found.length) list.innerHTML = '<div class="faint small">Aucun nouveau projet : ceux de ce PC sont déjà dans DevLauncher.</div>';
    $('[data-stop]', m.el).hidden = true;
  };
  $('[data-stop]', m.el).onclick = e => { e.target.disabled = true; api.cancelSearchPC(); };
  toggle.onclick = () => { const all = $$('[data-pick]', m.el), on = all.some(c => !c.checked); all.forEach(c => { c.checked = on; }); refreshAdd(); };
  addBtn.onclick = async () => {
    const paths = $$('[data-pick]:checked', m.el).map(c => c.dataset.pick);
    const restore = busyButton(addBtn, 'Ajout…');
    try {
      const r = await api.addProjects(paths);
      apply(r);
      m.close();
      toast({ kind: 'success', title: `${r.added} projet${r.added > 1 ? 's' : ''} ajouté${r.added > 1 ? 's' : ''}`, text: 'Groupe « Ajoutés manuellement » de la liste : tu peux les lancer dès maintenant.' });
    } catch (err) { restore(); toast({ kind: 'error', title: 'Ajout impossible', text: esc(err.message) }); }
  };
  api.searchPC();
}

api.on('pc-search', e => {
  if (!pcSearchUi) return;
  if (e.kind === 'found') pcSearchUi.add(e.project);
  else if (e.kind === 'progress') pcSearchUi.progress(e);
  else if (e.kind === 'done') pcSearchUi.done(e);
});

// ---------- Démarrage ----------
$('#btn-new').innerHTML = `${icon('plus')} Nouveau projet`;
$('#btn-new').onclick = newProjectDialog;
$('#btn-add').innerHTML = `${icon('folder')} Ajouter des projets`;
$('#btn-scan').innerHTML = `${icon('refresh')} Actualiser`;
$('#btn-settings').innerHTML = icon('settings');
$('#search-icon').innerHTML = icon('search');
setTheme(storedTheme() === 'dark' ? 'dark' : 'light');
$('#btn-theme').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
$('#btn-settings').onclick = settingsDialog;
$('#brand').onclick = aboutDialog;

// Écran d'ouverture : les étapes défilent pendant la première détection, puis il s'efface (au moins 1,2 s affiché).
const splashStart = performance.now();
const splashSteps = ['Recherche de tes serveurs locaux…', 'Détection de tes projets…', 'Repérage des projets déjà lancés…', 'Presque prêt…'];
let splashStep = 0;
const splashTimer = setInterval(() => {
  const el = $('#splash-step');
  if (!el || splashStep >= splashSteps.length - 1) return;
  el.textContent = splashSteps[++splashStep];
  el.classList.remove('swap'); void el.offsetWidth; el.classList.add('swap');
}, 900);
function hideSplash() {
  const sp = $('#splash');
  if (!sp || sp.classList.contains('out')) return;
  setTimeout(() => {
    clearInterval(splashTimer);
    sp.classList.add('out');
    setTimeout(() => sp.remove(), 500);
  }, Math.max(0, 1200 - (performance.now() - splashStart)));
}
setTimeout(hideSplash, 12000); // sécurité : jamais bloqué sur l'écran d'ouverture

async function rescan() {
  const b = $('#btn-scan');
  b.disabled = true;
  b.innerHTML = `<span class="spinner"></span> Détection...`;
  let snap;
  try { snap = await api.scan(); } finally { hideSplash(); }
  scanned = true;
  apply(snap);
  b.disabled = false;
  b.innerHTML = `${icon('refresh')} Actualiser`;
  refreshServices();
  if (selected) loadErrors(selected);
}
$('#btn-scan').onclick = rescan;
$('#btn-add').onclick = addDialog;

renderNav();
renderStatusbar();
renderList();
renderDetail();
rescan();
setInterval(refreshServices, 6000);
