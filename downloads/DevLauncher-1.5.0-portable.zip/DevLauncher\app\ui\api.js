// Client de l'API locale de DevLauncher.
(() => {
  // Barre d'activité : visible quand une requête dure plus de 350 ms (hors interrogations périodiques).
  const QUIET = new Set(['services', 'snapshot', 'createState', 'createExists', 'portInfo']);
  let pending = 0, showTimer = null;
  const activity = delta => {
    pending += delta;
    const bar = document.getElementById('activity');
    if (!bar) return;
    if (pending > 0 && !showTimer && !bar.classList.contains('on')) showTimer = setTimeout(() => { showTimer = null; if (pending > 0) bar.classList.add('on'); }, 350);
    if (pending <= 0) { clearTimeout(showTimer); showTimer = null; bar.classList.remove('on'); }
  };
  const call = name => async (...args) => {
    const tracked = !QUIET.has(name);
    if (tracked) activity(1);
    try {
      const res = await fetch(`/api/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ args })
      });
      const data = await res.json();
      if (!res.ok) throw new Error((data && data.error) || `Erreur ${res.status}`);
      return data;
    } finally { if (tracked) activity(-1); }
  };
  const names = [
    'scan', 'snapshot', 'start', 'stop', 'restart', 'action', 'killExternal', 'setConfig',
    'forgetProject', 'allowDiscovery', 'searchPC', 'cancelSearchPC', 'addProjects', 'openUrl', 'openFolder', 'openTerminal', 'openEditor', 'openFile', 'addRoot', 'removeRoot',
    'services', 'startService', 'setSettings', 'portInfo', 'suggestPort',
    'logFiles', 'readLog', 'clearLog', 'errors', 'clearConsole',
    'mails', 'mail', 'deleteMail', 'clearMails', 'sendSampleMail', 'quitApp',
    'dbInfo', 'dbTest', 'dbSaveEnv', 'dbCreate', 'openPhpMyAdmin', 'dbTarget', 'switchMysqlFor',
    'queueInfo', 'queueRun', 'queueWorker',
    'seedersList', 'seederRead', 'seedRun',
    'createInfo', 'createProject', 'createPreview', 'createState', 'createCancel', 'createPickFolder', 'createExists',
    'umlList', 'umlRead', 'umlSave', 'umlDelete', 'umlSources', 'umlRoutes', 'umlFiles', 'umlFunctions', 'umlGenerate', 'umlActions', 'umlGenerateBatch', 'umlExport', 'umlOpenFolder', 'umlOpenFile',
    'serverDiagnose', 'serverStop', 'serverRepair', 'killPortOwner', 'setApachePorts', 'serverLog', 'openServerFile',
    'backupInfo', 'backupDatabases', 'backupCreate', 'backupRestore', 'backupDelete', 'openBackupFolder', 'pickBackupFolder'
  ];
  const api = Object.fromEntries(names.map(n => [n, call(n)]));

  const events = new EventSource('/api/events');
  api.on = (channel, cb) => events.addEventListener(channel, e => cb(JSON.parse(e.data)));
  window.api = api;
})();
