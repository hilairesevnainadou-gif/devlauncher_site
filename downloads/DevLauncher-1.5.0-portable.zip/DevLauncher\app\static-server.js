// Petit serveur pour les sites HTML simples (lancé par DevLauncher avec son propre Node) :
//   node static-server.js <port> [dossier]
// Sert les fichiers du dossier, index.html par défaut, et recharge la page du navigateur dès qu'un fichier change.
const http = require('http');
const fs = require('fs');
const path = require('path');

const port = Number(process.argv[2]) || 5500;
const root = path.resolve(process.argv[3] || process.cwd());

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.htm': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.avif': 'image/avif', '.ico': 'image/x-icon', '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8', '.map': 'application/json; charset=utf-8', '.wasm': 'application/wasm'
};

// Rechargement automatique : chaque page HTML écoute ce canal, qui annonce les modifications de fichiers.
const RELOAD_PATH = '/__devlauncher_reload';
const RELOAD_SCRIPT = `<script>(()=>{const s=new EventSource('${RELOAD_PATH}');s.onmessage=()=>location.reload();})();</script>`;
const clients = new Set();
let timer = null;
try {
  fs.watch(root, { recursive: true }, (event, name) => {
    if (name && /(^|[\\/])(\.git|node_modules)([\\/]|$)/.test(name)) return;
    clearTimeout(timer);
    timer = setTimeout(() => { for (const res of clients) res.write('data: reload\n\n'); }, 150);
  });
} catch { /* surveillance indisponible : pas de rechargement automatique */ }

function send(res, status, body, type = 'text/html; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(body);
}

http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url, 'http://localhost'); } catch { return send(res, 400, 'Requête invalide'); }
  if (url.pathname === RELOAD_PATH) {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
    res.write(': ok\n\n');
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch { return send(res, 400, 'Adresse invalide'); }
  let file = path.join(root, rel);
  // Jamais en dehors du dossier du site
  if (file !== root && !file.startsWith(root + path.sep)) return send(res, 403, 'Accès refusé');
  try { if (fs.statSync(file).isDirectory()) file = path.join(file, 'index.html'); } catch { /* traité ci-dessous */ }
  fs.readFile(file, (err, data) => {
    if (err) {
      const notFound = path.join(root, '404.html');
      return fs.readFile(notFound, (e2, page) => send(res, 404, e2 ? `<h1>404</h1><p>${rel.replace(/[<>&]/g, '')} est introuvable.</p>` : page));
    }
    const type = TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream';
    if (type.startsWith('text/html')) {
      const html = data.toString('utf8');
      const out = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, RELOAD_SCRIPT + '</body>') : html + RELOAD_SCRIPT;
      return send(res, 200, out, type);
    }
    send(res, 200, data, type);
  });
}).listen(port, '127.0.0.1', () => {
  console.log(`Site HTML servi sur http://localhost:${port}/ (dossier : ${root})`);
  console.log('Rechargement automatique du navigateur à chaque modification de fichier.');
});
