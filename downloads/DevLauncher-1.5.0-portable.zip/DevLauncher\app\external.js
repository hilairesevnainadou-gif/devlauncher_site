// Repère les serveurs lancés en dehors de DevLauncher (php artisan serve, npm run dev... dans un terminal).
const { exec } = require('child_process');

function sh(cmd) {
  return new Promise(resolve => {
    exec(cmd, { windowsHide: true, maxBuffer: 16 * 1024 * 1024 }, (err, stdout) => resolve(err ? '' : stdout));
  });
}

// Ports TCP en écoute -> PID.
async function listeningPorts() {
  const out = await sh('netstat -ano -p tcp') + await sh('netstat -ano -p tcpv6');
  const ports = new Map();
  for (const line of out.split(/\r?\n/)) {
    const cols = line.trim().split(/\s+/);
    if (cols.length < 5 || cols[0] !== 'TCP' || cols[3] !== 'LISTENING') continue;
    const port = Number(cols[1].slice(cols[1].lastIndexOf(':') + 1));
    const pid = Number(cols[4]);
    if (port && pid && !ports.has(port)) ports.set(port, pid);
  }
  return ports;
}

// Infos (nom, parent, ligne de commande) pour une liste de PID et leurs parents, en un seul appel PowerShell.
// Les workers de Next/Nuxt ont parfois une ligne de commande générique : le parent permet de retrouver le projet.
async function processInfo(pids) {
  const ids = [...new Set(pids)].filter(p => p > 4);
  if (!ids.length) return new Map();
  const filter = ids.map(p => `ProcessId=${p}`).join(' or ');
  const ps = [
    `$a = @(Get-CimInstance Win32_Process -Filter '${filter}')`,
    '$pp = @($a | ForEach-Object { $_.ParentProcessId } | Sort-Object -Unique)',
    '$b = @()',
    "if ($pp.Count) { $b = @(Get-CimInstance Win32_Process -Filter (($pp | ForEach-Object { 'ProcessId=' + $_ }) -join ' or ')) }",
    '@($a + $b) | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress'
  ].join('; ');
  const encoded = Buffer.from(ps, 'utf16le').toString('base64');
  const out = await sh(`powershell -NoProfile -NonInteractive -EncodedCommand ${encoded}`);
  const map = new Map();
  try {
    let rows = JSON.parse(out);
    if (!Array.isArray(rows)) rows = [rows];
    for (const r of rows) map.set(r.ProcessId, { pid: r.ProcessId, ppid: r.ParentProcessId, name: r.Name, cmd: r.CommandLine || '' });
  } catch { /* sortie vide */ }
  return map;
}

// Chemins absolus cités dans une ligne de commande, ramenés au dossier du projet probable :
// « D:\shop\node_modules\next\dist\server\lib\start-server.js » -> « D:\shop »,
// « C:\api\vendor\laravel\framework\...\server.php » -> « C:\api ».
function pathsInCmd(cmd) {
  const out = [];
  for (const m of String(cmd || '').matchAll(/"([^"]+)"|(\S+)/g)) {
    let t = (m[1] || m[2] || '').replace(/\//g, '\\').replace(/^--?[\w-]+=/, '');
    if (!/^[a-z]:\\/i.test(t)) continue;
    const l = t.toLowerCase();
    for (const mark of ['\\node_modules\\', '\\vendor\\']) {
      const i = l.indexOf(mark);
      if (i > 2) { t = t.slice(0, i); break; }
    }
    out.push(t);
  }
  return out;
}

// Dossier de travail des processus (lu dans le bloc d'environnement du processus, PEB, processus 64 bits du même utilisateur).
// Nécessaire quand le serveur a été lancé avec un chemin relatif : « node index.js », « php artisan serve ».
const cwdCache = new Map(); // pid -> dossier ('' si illisible)
const CWD_CS = `
using System; using System.Runtime.InteropServices; using System.Text;
public static class DlCwd {
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(int a, bool i, int pid);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll")] static extern bool ReadProcessMemory(IntPtr h, IntPtr a, byte[] b, int n, out IntPtr r);
  [DllImport("kernel32.dll")] static extern bool IsWow64Process(IntPtr h, out bool w);
  [DllImport("ntdll.dll")] static extern int NtQueryInformationProcess(IntPtr h, int c, byte[] i, int n, out int r);
  static long Ptr(IntPtr h, long at) { var b = new byte[8]; IntPtr r; return ReadProcessMemory(h, new IntPtr(at), b, 8, out r) ? BitConverter.ToInt64(b, 0) : 0; }
  public static string Get(int pid) {
    IntPtr h = OpenProcess(0x0410, false, pid);
    if (h == IntPtr.Zero) return "";
    try {
      bool wow; if (IntPtr.Size != 8 || (IsWow64Process(h, out wow) && wow)) return "";
      var pbi = new byte[48]; int len;
      if (NtQueryInformationProcess(h, 0, pbi, pbi.Length, out len) != 0) return "";
      long peb = BitConverter.ToInt64(pbi, 8), pars = Ptr(h, peb + 0x20);
      if (pars == 0) return "";
      var us = new byte[16]; IntPtr r;
      if (!ReadProcessMemory(h, new IntPtr(pars + 0x38), us, 16, out r)) return "";
      int n = BitConverter.ToUInt16(us, 0); long buf = BitConverter.ToInt64(us, 8);
      if (n <= 0 || n > 2048 || buf == 0) return "";
      var s = new byte[n];
      return ReadProcessMemory(h, new IntPtr(buf), s, n, out r) ? Encoding.Unicode.GetString(s) : "";
    } finally { CloseHandle(h); }
  }
}`;

async function processCwd(pids) {
  const todo = [...new Set(pids)].filter(p => p > 4 && !cwdCache.has(p));
  if (todo.length) {
    const ps = `Add-Type -TypeDefinition @'\n${CWD_CS}\n'@; ${todo.map(p => `"${p}=" + [DlCwd]::Get(${p})`).join('; ')}`;
    const out = await sh(`powershell -NoProfile -NonInteractive -EncodedCommand ${Buffer.from(ps, 'utf16le').toString('base64')}`);
    for (const p of todo) cwdCache.set(p, '');
    for (const line of out.split(/\r?\n/)) {
      const m = line.match(/^(\d+)=(.*)$/);
      if (m) cwdCache.set(Number(m[1]), m[2].trim().replace(/\\$/, ''));
    }
  }
  return new Map(pids.map(p => [p, cwdCache.get(p) || '']));
}

// Processus qui peuvent être un serveur de développement (les autres programmes en écoute sont ignorés).
const DEV_PROCESS = /^(node|php|php-cgi|bun|deno|python|py|ruby)\.exe$/i;

/**
 * Analyse les ports en écoute et les rattache aux projets connus.
 * @param projects liste des projets ({ path, ... })
 * @param ignorePorts ports gérés par DevLauncher lui-même
 * @param locate (dossier ou fichier) -> dossier du projet qui le contient, ou null. Sert aux serveurs dont la ligne
 *        de commande ne cite aucun projet connu : projets situés hors des dossiers des serveurs, chemins relatifs.
 * @returns { byProject: Map<path, {port, pid, name, cmd}[]>, byPort: Map<port, {pid, name, cmd, project}>,
 *            outside: {port, pid, name, cmd, dir}[] (projets trouvés en dehors de la liste) }
 */
async function scanExternal(projects, ignorePorts = new Set(), { locate } = {}) {
  const ports = await listeningPorts();
  const candidates = [...ports].filter(([port]) => !ignorePorts.has(port) && port >= 1024);
  const procs = await processInfo(candidates.map(([, pid]) => pid));
  // Un numéro de processus peut être réutilisé par Windows : le cache ne garde que les processus encore présents.
  for (const p of cwdCache.keys()) if (!procs.has(p)) cwdCache.delete(p);

  const roots = projects
    .map(p => ({ path: p.path, key: p.path.toLowerCase().replace(/\//g, '\\') + '\\' }))
    .sort((a, b) => b.key.length - a.key.length); // le chemin le plus long d'abord (projets imbriqués)

  const matchProject = cmd => {
    const c = cmd.toLowerCase().replace(/\//g, '\\');
    const hit = roots.find(r => c.includes(r.key) || c.includes(r.key.slice(0, -1) + '"'));
    return hit ? hit.path : null;
  };

  const byProject = new Map();
  const byPort = new Map();
  const unresolved = [];
  for (const [port, pid] of candidates) {
    const info = procs.get(pid) || { pid, name: '?', cmd: '' };
    const parent = procs.get(info.ppid);
    const project = matchProject(info.cmd) || (parent && matchProject(parent.cmd)) || null;
    const entry = { port, pid, name: info.name, cmd: info.cmd, project };
    byPort.set(port, entry);
    if (!project && locate && DEV_PROCESS.test(info.name || '')) unresolved.push({ entry, info, parent });
  }

  // Serveurs non rattachés : chemins cités dans la commande (le processus puis son parent), sinon dossier de travail.
  const outside = [];
  if (unresolved.length) {
    const known = new Map(projects.map(p => [p.path.toLowerCase(), p.path]));
    const resolve = cand => { const dir = cand && locate(cand); return dir ? (known.get(dir.toLowerCase()) || dir) : null; };
    const fromCmd = u => [u.info.cmd, u.parent && u.parent.cmd].flatMap(pathsInCmd).map(resolve).find(Boolean) || null;
    const pending = [];
    for (const u of unresolved) { u.dir = fromCmd(u); if (!u.dir) pending.push(u); }
    if (pending.length) {
      const cwd = await processCwd(pending.flatMap(u => [u.entry.pid, u.info.ppid].filter(Boolean)));
      for (const u of pending) u.dir = resolve(cwd.get(u.entry.pid)) || resolve(cwd.get(u.info.ppid));
    }
    for (const u of unresolved) {
      if (!u.dir) continue;
      if (known.has(u.dir.toLowerCase())) u.entry.project = u.dir; // projet connu, lancé avec un chemin relatif
      else outside.push({ ...u.entry, dir: u.dir });
    }
  }
  for (const entry of byPort.values()) {
    if (!entry.project) continue;
    if (!byProject.has(entry.project)) byProject.set(entry.project, []);
    byProject.get(entry.project).push(entry);
  }
  return { byProject, byPort, outside };
}

module.exports = { scanExternal, listeningPorts, sh, pathsInCmd, processCwd };
