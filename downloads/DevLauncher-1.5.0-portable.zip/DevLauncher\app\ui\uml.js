// Rendu des diagrammes UML (sous-ensemble de PlantUML) en SVG autonome : classes, séquence, activité.
(() => {
  const FONT = '"Segoe UI", Arial, sans-serif';
  const MONO = 'Consolas, "Cascadia Mono", monospace';
  const C = { stroke: '#3b4a5a', line: '#4a5866', fill: '#ffffff', head: '#e8f1f9', text: '#1d2125', muted: '#5b6670', accent: '#0373BB', frag: '#f5f7fa', note: '#fff8e1', noteStroke: '#d9b54a' };
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ctx = document.createElement('canvas').getContext('2d');
  const tw = (s, size = 12, weight = 400, font = FONT) => { ctx.font = `${weight} ${size}px ${font}`; return ctx.measureText(String(s)).width; };

  // Découpe un texte en lignes (\n explicites, puis largeur maximale).
  function wrap(text, max, size = 12) {
    const out = [];
    for (const para of String(text).split(/\\n|\n/)) {
      let line = '';
      for (const word of para.split(' ')) {
        const t = line ? line + ' ' + word : word;
        if (tw(t, size) > max && line) { out.push(line); line = word; } else line = t;
      }
      out.push(line);
    }
    return out;
  }
  const text = (x, y, s, o = {}) => `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" font-family='${o.mono ? MONO : FONT}' font-size="${o.size || 12}"${o.weight ? ` font-weight="${o.weight}"` : ''}${o.anchor ? ` text-anchor="${o.anchor}"` : ''} fill="${o.color || C.text}"${o.italic ? ' font-style="italic"' : ''}${o.underline ? ' text-decoration="underline"' : ''}>${esc(s)}</text>`;

  function clean(src) {
    return String(src).split(/\r?\n/).map(l => l.replace(/^\s+|\s+$/g, ''))
      .filter(l => l && !/^'/.test(l) && !/^@(start|end)uml/.test(l) && !/^(skinparam|hide|show|left to right|top to bottom|scale|autonumber|!)/i.test(l));
  }
  const titleOf = lines => { const t = lines.find(l => /^title\s+/i.test(l)); return t ? t.replace(/^title\s+/i, '') : ''; };

  function detect(src) {
    const m = String(src).match(/^'\s*type\s*:\s*(class|sequence|activity)/m);
    if (m) return m[1];
    if (/^\s*(start|stop)\s*$/m.test(src) || /^\s*:[^;]*;?\s*$/m.test(src)) return 'activity';
    if (/^\s*(actor|participant|database|entity|boundary|control)\s/m.test(src) || /^\s*\S+\s*-+>>?\s*\S+\s*:/m.test(src)) return 'sequence';
    return 'class';
  }

  function frame(title, w, h, body) {
    const th = title ? 34 : 0;
    const W = Math.ceil(w + 40), H = Math.ceil(h + th + 40);
    return {
      width: W, height: H,
      svg: `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" font-family='${FONT}'>
<defs>
  <marker id="m-arrow" viewBox="0 0 10 10" refX="9.5" refY="5" markerWidth="9" markerHeight="9" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10" fill="none" stroke="${C.line}" stroke-width="1.4"/></marker>
  <marker id="m-fill" viewBox="0 0 10 10" refX="9.5" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="${C.line}"/></marker>
  <marker id="m-tri" viewBox="0 0 12 12" refX="11.5" refY="6" markerWidth="13" markerHeight="13" orient="auto-start-reverse"><path d="M0,0 L12,6 L0,12 z" fill="#fff" stroke="${C.line}" stroke-width="1.2"/></marker>
  <marker id="m-diam" viewBox="0 0 16 10" refX="15.5" refY="5" markerWidth="15" markerHeight="10" orient="auto-start-reverse"><path d="M0,5 L8,0 L16,5 L8,10 z" fill="#fff" stroke="${C.line}" stroke-width="1.2"/></marker>
  <marker id="m-diamf" viewBox="0 0 16 10" refX="15.5" refY="5" markerWidth="15" markerHeight="10" orient="auto-start-reverse"><path d="M0,5 L8,0 L16,5 L8,10 z" fill="${C.line}"/></marker>
</defs>
<rect width="100%" height="100%" fill="#ffffff"/>
${title ? text(20, 30, title, { size: 16, weight: 600 }) : ''}
<g transform="translate(20 ${20 + th})">${body}</g>
</svg>`
    };
  }

  // =============== Diagramme de classes ===============
  function parseClass(src) {
    const lines = clean(src);
    const nodes = new Map(), edges = [], errors = [];
    const node = (name, kind = 'class') => {
      if (!nodes.has(name)) nodes.set(name, { name, kind, stereo: null, attrs: [], methods: [], order: nodes.size });
      return nodes.get(name);
    };
    let cur = null;
    lines.forEach((l, i) => {
      if (/^title\s/i.test(l)) return;
      if (cur) {
        if (l === '}') { cur = null; return; }
        if (/^(--|\.\.|==|__)/.test(l)) return;
        (l.includes('(') ? cur.methods : cur.attrs).push(l);
        return;
      }
      // class "Libellé libre" as Alias : le libellé est affiché, l'alias sert aux relations.
      let m = l.match(/^(abstract\s+class|abstract|class|interface|enum|entity|annotation)\s+(?:"([^"]+)"|([\w.$-]+))(?:\s+as\s+(\w+))?\s*(?:<<\s*([^>]+?)\s*>>)?\s*(?:extends\s+([\w.]+))?\s*(?:implements\s+([\w.,\s]+?))?\s*(\{)?\s*$/i);
      if (m) {
        const label = m[2] || m[3];
        m = [m[0], m[1], label, m[4], m[5], m[6], m[7], m[8]];
        const n = node(m[3] || m[2], /^abstract/i.test(m[1]) ? 'abstract' : m[1].toLowerCase());
        if (m[3] && label !== m[3]) n.label = label;
        n.kind = /^abstract/i.test(m[1]) ? 'abstract' : m[1].toLowerCase();
        if (m[4]) n.stereo = m[4];
        if (m[5]) { node(m[5]); edges.push({ from: m[5], to: n.name, kind: 'extends' }); }
        if (m[6]) for (const it of m[6].split(',').map(s => s.trim()).filter(Boolean)) { node(it, 'interface'); edges.push({ from: it, to: n.name, kind: 'implements' }); }
        if (m[7]) cur = n;
        return;
      }
      m = l.match(/^"?([\w.$]+)"?\s*(?:"([^"]*)")?\s*([<*o#x+]?\|?)(-{1,2}|\.{1,2})(?:\[[^\]]*\])?(\|?[>*o#x+]?)\s*(?:"([^"]*)")?\s*"?([\w.$]+)"?\s*(?::\s*(.*))?$/);
      if (m) {
        const [, a, ma, lh, ln, rh, mb, b, label] = m;
        node(a); node(b);
        const dashed = ln.startsWith('.');
        let e;
        if (lh === '<|') e = { from: a, to: b, kind: dashed ? 'implements' : 'extends' };
        else if (rh === '|>') e = { from: b, to: a, kind: dashed ? 'implements' : 'extends' };
        else if (lh === '*' || lh === 'o') e = { from: a, to: b, kind: lh === '*' ? 'composition' : 'aggregation', ma, mb, label };
        else if (rh === '*' || rh === 'o') e = { from: b, to: a, kind: rh === '*' ? 'composition' : 'aggregation', ma: mb, mb: ma, label };
        else if (lh === '<' && !rh) e = { from: b, to: a, kind: dashed ? 'dependency' : 'association', directed: true, ma: mb, mb: ma, label };
        else e = { from: a, to: b, kind: dashed ? 'dependency' : 'association', directed: rh === '>', ma, mb, label };
        edges.push(e);
        return;
      }
      if (/^note\b/i.test(l)) return;
      errors.push(`Ligne ${i + 1} non reconnue : ${l}`);
    });
    return { type: 'class', title: titleOf(lines), nodes: [...nodes.values()], edges, errors };
  }

  function renderClass(model) {
    const { nodes, edges } = model;
    if (!nodes.length) return frame(model.title, 300, 60, text(0, 30, 'Aucune classe : ajoute « class Nom { … } ».', { color: C.muted }));
    // Dimensions des boîtes
    for (const n of nodes) {
      const label = n.label || n.name;
      const st = n.kind === 'interface' ? 'interface' : n.kind === 'enum' ? 'enumeration' : n.kind === 'abstract' ? 'abstract' : n.stereo;
      n.stLabel = st && st !== 'class' ? `«${st}»` : null;
      const memberW = s => tw(s.replace(/^\{(static|abstract)\}\s*/, ''), 11.5, 400, MONO);
      n.w = Math.max(130, tw(label, 13, 600) + 28, n.stLabel ? tw(n.stLabel, 11) + 28 : 0, ...n.attrs.map(a => memberW(a) + 22), ...n.methods.map(a => memberW(a) + 22));
      n.w = Math.min(n.w, 360);
      n.headH = n.stLabel ? 40 : 28;
      const sec = arr => (arr.length ? arr.length * 17 + 10 : 10);
      n.h = n.headH + sec(n.attrs) + (n.kind === 'enum' && !n.methods.length ? 0 : sec(n.methods));
    }
    // Niveaux : parent au-dessus de l'enfant, « 1 » au-dessus de « * », sinon source au-dessus de la cible.
    const up = new Map(nodes.map(n => [n.name, new Set()]));
    for (const e of edges) {
      if (e.from === e.to) continue;
      let top = e.from, bottom = e.to;
      if (e.kind === 'association' && e.ma === '*' && e.mb === '1') [top, bottom] = [e.to, e.from];
      up.get(bottom).add(top);
    }
    const rank = new Map();
    const visiting = new Set();
    const r = n => {
      if (rank.has(n)) return rank.get(n);
      if (visiting.has(n)) return 0; // cycle : coupé
      visiting.add(n);
      let v = 0;
      for (const p of up.get(n)) v = Math.max(v, r(p) + 1);
      visiting.delete(n);
      rank.set(n, v);
      return v;
    };
    const connected = new Set(edges.flatMap(e => [e.from, e.to]));
    nodes.forEach(n => r(n.name));
    const rows = [];
    for (const n of nodes.filter(x => connected.has(x.name)).sort((a, b) => a.order - b.order)) (rows[rank.get(n.name)] = rows[rank.get(n.name)] || []).push(n);
    // Ordre dans chaque niveau : barycentre des voisins (réduit les croisements)
    const neighbors = n => edges.filter(e => e.from === n.name || e.to === n.name).map(e => (e.from === n.name ? e.to : e.from));
    for (let pass = 0; pass < 4; pass++) {
      const pos = new Map();
      rows.forEach(row => row && row.forEach((n, i) => pos.set(n.name, i / Math.max(1, row.length - 1))));
      rows.forEach(row => row && row.sort((a, b) => {
        const ba = neighbors(a).map(x => pos.get(x)).filter(x => x !== undefined), bb = neighbors(b).map(x => pos.get(x)).filter(x => x !== undefined);
        const va = ba.length ? ba.reduce((s, x) => s + x, 0) / ba.length : pos.get(a.name), vb = bb.length ? bb.reduce((s, x) => s + x, 0) / bb.length : pos.get(b.name);
        return va - vb;
      }));
    }
    // Les classes sans relation sont rangées en grille à la fin ; les niveaux trop larges passent à la ligne.
    const isolated = nodes.filter(x => !connected.has(x.name));
    const MAXW = Math.max(1300, Math.sqrt(nodes.length) * 420);
    const lines = [];
    const pushWrapped = list => {
      let line = [], w = 0;
      for (const n of list) { if (line.length && w + n.w > MAXW) { lines.push(line); line = []; w = 0; } line.push(n); w += n.w + 50; }
      if (line.length) lines.push(line);
    };
    rows.filter(Boolean).forEach(pushWrapped);
    if (isolated.length) pushWrapped(isolated);
    const GAPX = 50, GAPY = 80;
    const widths = lines.map(l => l.reduce((s, n) => s + n.w, 0) + GAPX * (l.length - 1));
    const W = Math.max(...widths);
    let y = 0;
    lines.forEach((l, i) => {
      let x = (W - widths[i]) / 2;
      const h = Math.max(...l.map(n => n.h));
      for (const n of l) { n.x = x; n.y = y; x += n.w + GAPX; }
      y += h + GAPY;
    });
    const H = y - GAPY;
    // Point de sortie sur le bord d'une boîte, vers (tx, ty)
    const border = (n, tx, ty) => {
      const cx = n.x + n.w / 2, cy = n.y + n.h / 2, dx = tx - cx, dy = ty - cy;
      if (!dx && !dy) return [cx, cy];
      const s = Math.min(Math.abs((n.w / 2) / (dx || 1e-9)), Math.abs((n.h / 2) / (dy || 1e-9)));
      return [cx + dx * s, cy + dy * s];
    };
    const byName = new Map(nodes.map(n => [n.name, n]));
    const pairCount = new Map();
    let svgEdges = '', svgLabels = '';
    for (const e of edges) {
      const a = byName.get(e.from), b = byName.get(e.to);
      const key = [e.from, e.to].sort().join('|');
      const k = pairCount.get(key) || 0;
      pairCount.set(key, k + 1);
      if (a === b) { // relation réflexive : boucle à droite
        const x = a.x + a.w, y0 = a.y + 14 + k * 10;
        svgEdges += `<path d="M${x},${y0} h28 v26 h-28" fill="none" stroke="${C.line}" stroke-width="1.2" marker-end="url(#m-arrow)"/>`;
        if (e.label) svgLabels += text(x + 32, y0 + 17, e.label, { size: 11, color: C.muted });
        continue;
      }
      const off = (k - 0) * 14 - (k ? 7 : 0);
      const acx = a.x + a.w / 2 + off, acy = a.y + a.h / 2, bcx = b.x + b.w / 2 + off, bcy = b.y + b.h / 2;
      const [x1, y1] = border(a, bcx, bcy), [x2, y2] = border(b, acx, acy);
      const dash = e.kind === 'implements' || e.kind === 'dependency' ? ' stroke-dasharray="6 4"' : '';
      let mStart = '', mEnd = '';
      if (e.kind === 'extends' || e.kind === 'implements') mStart = 'url(#m-tri)';
      else if (e.kind === 'composition') mStart = 'url(#m-diamf)';
      else if (e.kind === 'aggregation') mStart = 'url(#m-diam)';
      else if (e.kind === 'dependency' || e.directed) mEnd = 'url(#m-arrow)';
      svgEdges += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${C.line}" stroke-width="1.2"${dash}${mStart ? ` marker-start="${mStart}"` : ''}${mEnd ? ` marker-end="${mEnd}"` : ''}/>`;
      const len = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / len, uy = (y2 - y1) / len, nx = -uy, ny = ux;
      const mult = (s, x, y, dir) => { if (s) svgLabels += text(x + ux * 16 * dir + nx * 10, y + uy * 16 * dir + ny * 10 + 4, s, { size: 11, color: C.muted, anchor: 'middle' }); };
      mult(e.ma, x1, y1, 1);
      mult(e.mb, x2, y2, -1);
      if (e.label) {
        const mx = (x1 + x2) / 2, my = (y1 + y2) / 2, lw = tw(e.label, 11) + 8;
        svgLabels += `<rect x="${(mx - lw / 2).toFixed(1)}" y="${(my - 9).toFixed(1)}" width="${lw.toFixed(1)}" height="16" rx="3" fill="#fff" opacity="0.92"/>` + text(mx, my + 3, e.label, { size: 11, color: C.muted, anchor: 'middle' });
      }
    }
    let svgNodes = '';
    for (const n of nodes) {
      const { x, y, w, h } = n;
      svgNodes += `<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="3" fill="${C.fill}" stroke="${C.stroke}" stroke-width="1.2"/>`;
      svgNodes += `<path d="M${x + 3},${y} h${w - 6} a3,3 0 0 1 3,3 v${n.headH - 3} h-${w} v-${n.headH - 3} a3,3 0 0 1 3,-3 z" fill="${C.head}" stroke="none"/>`;
      if (n.stLabel) svgNodes += text(x + w / 2, y + 15, n.stLabel, { size: 11, color: C.muted, anchor: 'middle' });
      svgNodes += text(x + w / 2, y + (n.stLabel ? 32 : 19), n.label || n.name, { size: 13, weight: 600, anchor: 'middle', italic: n.kind === 'abstract' });
      let yy = y + n.headH;
      svgNodes += `<line x1="${x}" y1="${yy}" x2="${x + w}" y2="${yy}" stroke="${C.stroke}" stroke-width="1"/>`;
      const member = (s, top) => {
        const st = /^\{static\}/.test(s), ab = /^\{abstract\}/.test(s);
        const t = s.replace(/^\{(static|abstract)\}\s*/, '');
        const clip = t.length > 46 ? t.slice(0, 44) + '…' : t;
        return text(x + 10, top, clip, { size: 11.5, mono: true, underline: st, italic: ab, color: /^…/.test(t) ? C.muted : C.text });
      };
      n.attrs.forEach((a, i) => { svgNodes += member(a, yy + 17 + i * 17); });
      yy += n.attrs.length ? n.attrs.length * 17 + 10 : 10;
      if (!(n.kind === 'enum' && !n.methods.length)) {
        svgNodes += `<line x1="${x}" y1="${yy}" x2="${x + w}" y2="${yy}" stroke="${C.stroke}" stroke-width="1"/>`;
        n.methods.forEach((a, i) => { svgNodes += member(a, yy + 17 + i * 17); });
      }
      svgNodes += '</g>';
    }
    return frame(model.title, W, H, svgEdges + svgNodes + svgLabels);
  }

  // =============== Diagramme de séquence ===============
  function parseSequence(src) {
    const lines = clean(src);
    const parts = [], events = [], errors = [];
    const byAlias = new Map();
    const part = (name, kind = 'participant', label) => {
      const key = name.replace(/^"|"$/g, '');
      if (!byAlias.has(key)) { const p = { id: key, label: (label || key).replace(/^"|"$/g, ''), kind, index: parts.length }; parts.push(p); byAlias.set(key, p); }
      return byAlias.get(key);
    };
    lines.forEach((l, i) => {
      if (/^title\s/i.test(l)) return;
      let m = l.match(/^(actor|participant|database|entity|boundary|control|collections|queue)\s+(?:"([^"]+)"|(\S+))(?:\s+as\s+(\S+))?/i);
      if (m) { const label = m[2] || m[3]; const p = part(m[4] || label, m[1].toLowerCase(), label); p.kind = m[1].toLowerCase(); p.label = label; return; }
      m = l.match(/^(alt|opt|loop|par|group|critical|break)\b\s*(.*)$/i);
      if (m) { events.push({ t: 'frag', kind: m[1].toLowerCase(), label: m[2] }); return; }
      m = l.match(/^else\b\s*(.*)$/i);
      if (m) { events.push({ t: 'else', label: m[1] }); return; }
      if (/^end$/i.test(l)) { events.push({ t: 'end' }); return; }
      m = l.match(/^note\s+(over|left of|right of)\s+([^:]+?)\s*:\s*(.*)$/i);
      if (m) { events.push({ t: 'note', pos: m[1].toLowerCase(), on: m[2].split(',').map(s => part(s.trim()).id), text: m[3] }); return; }
      m = l.match(/^==\s*(.*?)\s*==$/);
      if (m) { events.push({ t: 'divider', label: m[1] }); return; }
      if (/^(activate|deactivate|destroy|autoactivate|\.\.\.|\|\|\|)/i.test(l)) return;
      m = l.match(/^("[^"]+"|[^\s<>-]+)\s*(<<?-{1,2}|-{1,2}>>?|-{1,2}x)\s*("[^"]+"|[^\s:]+)\s*(?::\s*(.*))?$/);
      if (m) {
        let [, a, arrow, b, label] = m;
        if (arrow.startsWith('<')) { [a, b] = [b, a]; arrow = arrow.replace(/^<+/, '') + '>'; }
        events.push({ t: 'msg', from: part(a).id, to: part(b).id, dashed: arrow.startsWith('--'), async: />>/.test(arrow), lost: /x$/.test(arrow), label: label || '' });
        return;
      }
      errors.push(`Ligne ${i + 1} non reconnue : ${l}`);
    });
    return { type: 'sequence', title: titleOf(lines), parts, events, errors };
  }

  function renderSequence(model) {
    const { parts, events } = model;
    if (!parts.length) return frame(model.title, 300, 60, text(0, 30, 'Aucun participant : ajoute « A -> B : message ».', { color: C.muted }));
    for (const p of parts) p.w = Math.max(96, tw(p.label, 12.5, 600) + 26);
    // Espacement des colonnes : assez pour les libellés des messages entre deux participants
    const gaps = parts.map((p, i) => (i ? Math.max(40 + (parts[i - 1].w + p.w) / 2, 140) : 0));
    for (const e of events.filter(x => x.t === 'msg')) {
      const a = parts.find(p => p.id === e.from).index, b = parts.find(p => p.id === e.to).index;
      if (a === b) { if (a + 1 < parts.length) gaps[a + 1] = Math.max(gaps[a + 1], tw(e.label, 11.5) + 70); continue; }
      const lo = Math.min(a, b), hi = Math.max(a, b);
      const need = tw(e.label, 11.5) + 36;
      let have = 0;
      for (let i = lo + 1; i <= hi; i++) have += gaps[i];
      if (have < need) { const add = (need - have) / (hi - lo); for (let i = lo + 1; i <= hi; i++) gaps[i] += add; }
    }
    let acc = parts[0].w / 2 + 10;
    parts.forEach((p, i) => { acc += gaps[i]; p.cx = acc; });
    const W = parts[parts.length - 1].cx + parts[parts.length - 1].w / 2 + 10;
    const topH = parts.some(p => p.kind === 'actor') ? 62 : 38;
    let y = topH + 24;
    let body = '';
    const frags = [];
    const touch = (...idx) => frags.forEach(f => idx.forEach(i => { f.min = Math.min(f.min, i); f.max = Math.max(f.max, i); }));
    for (const e of events) {
      if (e.t === 'msg') {
        const a = parts.find(p => p.id === e.from), b = parts.find(p => p.id === e.to);
        touch(a.index, b.index);
        const style = `stroke="${C.line}" stroke-width="1.2"${e.dashed ? ' stroke-dasharray="6 4"' : ''}`;
        const marker = e.async || e.dashed ? 'url(#m-arrow)' : 'url(#m-fill)';
        const labelLines = wrap(e.label, 320, 11.5);
        if (a === b) {
          labelLines.forEach((l, k) => { body += text(a.cx + 8, y + k * 14, l, { size: 11.5 }); });
          const y0 = y + labelLines.length * 14 - 6;
          body += `<path d="M${a.cx},${y0} h34 v22 h-32" fill="none" ${style} marker-end="${marker}"/>`;
          y += labelLines.length * 14 + 34;
        } else {
          const dir = b.cx > a.cx ? 1 : -1;
          const mid = (a.cx + b.cx) / 2;
          labelLines.forEach((l, k) => { body += text(mid, y + k * 14, l, { size: 11.5, anchor: 'middle', color: e.dashed ? C.muted : C.text }); });
          const ly = y + (labelLines.length - 1) * 14 + 7;
          body += `<line x1="${a.cx}" y1="${ly}" x2="${b.cx - dir * 1}" y2="${ly}" ${style} marker-end="${marker}"/>`;
          y += labelLines.length * 14 + 22;
        }
      } else if (e.t === 'frag') {
        frags.push({ kind: e.kind, label: e.label, y, min: Infinity, max: -Infinity, elses: [], depth: frags.length });
        y += 30;
      } else if (e.t === 'else') {
        const f = frags[frags.length - 1];
        if (f) { f.elses.push({ y: y - 6, label: e.label }); y += 26; }
      } else if (e.t === 'end') {
        const f = frags.pop();
        if (!f) continue;
        f.end = y - 4;
        if (!isFinite(f.min)) { f.min = 0; f.max = parts.length - 1; }
        const pad = 22 + (frags.length) * 0;
        const x1 = parts[f.min].cx - Math.max(pad, 60) + f.depth * 6, x2 = parts[f.max].cx + Math.max(pad, 60) - f.depth * 6;
        const lab = f.kind;
        const lw = tw(lab, 11, 700) + 16;
        let s = `<rect x="${x1}" y="${f.y - 4}" width="${x2 - x1}" height="${f.end - f.y + 4}" fill="none" stroke="${C.stroke}" stroke-width="1"/>`;
        s += `<path d="M${x1},${f.y - 4} h${lw} v12 l-6,6 h-${lw - 6} z" fill="${C.frag}" stroke="${C.stroke}" stroke-width="1"/>` + text(x1 + 6, f.y + 9, lab, { size: 11, weight: 700 });
        if (f.label) s += text(x1 + lw + 8, f.y + 9, `[${f.label}]`, { size: 11, color: C.muted });
        for (const el of f.elses) s += `<line x1="${x1}" y1="${el.y}" x2="${x2}" y2="${el.y}" stroke="${C.stroke}" stroke-width="1" stroke-dasharray="5 4"/>` + (el.label ? text(x1 + 8, el.y + 14, `[${el.label}]`, { size: 11, color: C.muted }) : '');
        body = s + body;
        touch(f.min, f.max);
        y += 14;
      } else if (e.t === 'note') {
        const idx = e.on.map(id => parts.find(p => p.id === id).index);
        const lo = Math.min(...idx), hi = Math.max(...idx);
        const lines = wrap(e.text, 220, 11.5);
        const w = Math.max(...lines.map(l => tw(l, 11.5))) + 20, h = lines.length * 15 + 12;
        let x = e.pos === 'left of' ? parts[lo].cx - w - 12 : e.pos === 'right of' ? parts[hi].cx + 12 : (parts[lo].cx + parts[hi].cx) / 2 - w / 2;
        body += `<path d="M${x},${y} h${w - 10} l10,10 v${h - 10} h-${w} z" fill="${C.note}" stroke="${C.noteStroke}" stroke-width="1"/>`;
        lines.forEach((l, k) => { body += text(x + 10, y + 17 + k * 15, l, { size: 11.5 }); });
        y += h + 16;
      } else if (e.t === 'divider') {
        body += `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${C.stroke}" stroke-dasharray="3 3"/>`;
        const lw = tw(e.label, 11.5, 600) + 20;
        body += `<rect x="${W / 2 - lw / 2}" y="${y - 11}" width="${lw}" height="22" fill="#fff" stroke="${C.stroke}"/>` + text(W / 2, y + 4, e.label, { size: 11.5, weight: 600, anchor: 'middle' });
        y += 30;
      }
    }
    const H = y + 10;
    let heads = '';
    for (const p of parts) {
      heads = `<line x1="${p.cx}" y1="${topH}" x2="${p.cx}" y2="${H}" stroke="#9aa5b1" stroke-width="1" stroke-dasharray="5 4"/>` + heads;
      if (p.kind === 'actor') {
        const cx = p.cx;
        heads += `<g fill="none" stroke="${C.stroke}" stroke-width="1.4"><circle cx="${cx}" cy="9" r="7" fill="#fff"/><path d="M${cx},16 v16 M${cx - 12},22 h24 M${cx},32 l-10,13 M${cx},32 l10,13"/></g>` + text(cx, 58, p.label, { size: 12.5, weight: 600, anchor: 'middle' });
      } else {
        const x = p.cx - p.w / 2;
        heads += `<rect x="${x}" y="0" width="${p.w}" height="${topH - 4}" rx="3" fill="${C.head}" stroke="${C.stroke}" stroke-width="1.2"/>`;
        const icon = { database: '«database»', entity: '«entity»', control: '«control»', boundary: '«boundary»', queue: '«queue»', collections: '«collections»' }[p.kind];
        if (icon && topH > 40) heads += text(p.cx, 16, icon, { size: 10.5, color: C.muted, anchor: 'middle' });
        heads += text(p.cx, icon && topH > 40 ? 36 : topH / 2 + 3, p.label, { size: 12.5, weight: 600, anchor: 'middle' });
        if (icon && topH <= 40) heads += text(x + 6, 11, icon.slice(1, 2).toUpperCase(), { size: 9, color: C.muted });
      }
    }
    return frame(model.title, W, H, heads + body);
  }

  // =============== Diagramme d'activité ===============
  function parseActivity(src) {
    const raw = clean(src);
    const errors = [];
    // Les actions « :texte; » peuvent tenir sur plusieurs lignes
    const lines = [];
    for (let i = 0; i < raw.length; i++) {
      let l = raw[i];
      if (/^:/.test(l) && !/;\s*$|[\]|<>/}]\s*$/.test(l)) { while (i + 1 < raw.length && !/;\s*$/.test(l)) l += '\\n' + raw[++i]; }
      lines.push(l);
    }
    let pos = 0;
    const block = stopAt => {
      const items = [];
      while (pos < lines.length) {
        const l = lines[pos];
        if (stopAt.test(l)) return items;
        pos++;
        let m;
        if (/^title\s/i.test(l) || /^note\b/i.test(l) || /^end note$/i.test(l) || /^(partition|group|end group|\})/i.test(l)) continue;
        if (/^start$/i.test(l)) { items.push({ t: 'start' }); continue; }
        if (/^(stop|end|kill|detach)$/i.test(l)) { items.push({ t: 'stop', end: /^end$/i.test(l) }); continue; }
        if ((m = l.match(/^:(.*?);?\s*$/s))) { items.push({ t: 'action', text: m[1] }); continue; }
        // « then » obligatoire d'abord : sinon la condition avalerait « ) then (oui ».
        if ((m = l.match(/^if\s*\((.*)\)\s*then(?:\s*\((.*?)\))?\s*$/i) || l.match(/^if\s*\((.*)\)\s*$/i))) {
          const node = { t: 'if', branches: [{ cond: m[1], label: m[2] || 'oui', body: block(/^(elseif|else|endif|end if)\b/i) }], else: null };
          while (pos < lines.length) {
            const c = lines[pos];
            if ((m = c.match(/^elseif\s*\((.*)\)\s*then(?:\s*\((.*?)\))?\s*$/i) || c.match(/^elseif\s*\((.*)\)\s*$/i))) { pos++; node.branches.push({ cond: m[1], label: m[2] || 'oui', body: block(/^(elseif|else|endif|end if)\b/i) }); continue; }
            if ((m = c.match(/^else\s*(?:\((.*?)\))?/i))) { pos++; node.elseLabel = m[1] || 'non'; node.else = block(/^(endif|end if)\b/i); continue; }
            if (/^(endif|end if)\b/i.test(c)) { pos++; break; }
            break;
          }
          items.push(node); continue;
        }
        if ((m = l.match(/^while\s*\((.*)\)\s*is\s*\((.*?)\)\s*$/i) || l.match(/^while\s*\((.*)\)\s*$/i))) {
          const node = { t: 'while', cond: m[1], label: m[2] || '', body: block(/^(endwhile|end while)\b/i) };
          const e = lines[pos] && lines[pos].match(/^(?:endwhile|end while)\s*(?:\((.*?)\))?/i);
          if (e) { node.exitLabel = e[1] || ''; pos++; }
          items.push(node); continue;
        }
        if (/^repeat$/i.test(l)) {
          const node = { t: 'repeat', body: block(/^repeat\s*while\b/i) };
          const e = lines[pos] && lines[pos].match(/^repeat\s*while\s*\((.*?)\)\s*(?:is\s*\((.*?)\))?/i);
          if (e) { node.cond = e[1]; node.label = e[2] || ''; pos++; }
          items.push(node); continue;
        }
        if (/^fork$/i.test(l)) {
          const node = { t: 'fork', branches: [block(/^(fork again|end fork|end merge)\b/i)] };
          while (pos < lines.length && /^fork again/i.test(lines[pos])) { pos++; node.branches.push(block(/^(fork again|end fork|end merge)\b/i)); }
          if (pos < lines.length) pos++;
          items.push(node); continue;
        }
        errors.push(`Ligne non reconnue : ${l}`);
      }
      return items;
    };
    const items = block(/^\0$/);
    return { type: 'activity', title: titleOf(raw), items, errors };
  }

  // Chaque bloc renvoie { w, h, cx (axe central depuis la gauche), term (se termine par un stop), draw(x, y) }
  function layoutActivity(items) {
    const V = 26; // flèche entre deux éléments
    const arrow = (x1, y1, x2, y2) => `<path d="M${x1},${y1} L${x2},${y2}" fill="none" stroke="${C.line}" stroke-width="1.2" marker-end="url(#m-fill)"/>`;
    const poly = (pts, end = true) => `<path d="M${pts.map(p => p.join(',')).join(' L')}" fill="none" stroke="${C.line}" stroke-width="1.2"${end ? ' marker-end="url(#m-fill)"' : ''}/>`;
    const lab = (x, y, s, anchor = 'start') => (s ? text(x, y, s, { size: 11, color: C.muted, anchor }) : '');

    const leaf = n => {
      if (n.t === 'start') return { w: 20, h: 20, cx: 10, draw: (x, y) => `<circle cx="${x + 10}" cy="${y + 10}" r="9" fill="${C.text}"/>` };
      if (n.t === 'stop') return { w: 22, h: 22, cx: 11, term: true, draw: (x, y) => n.end ? `<circle cx="${x + 11}" cy="${y + 11}" r="10" fill="#fff" stroke="${C.text}" stroke-width="1.4"/><path d="M${x + 5},${y + 5} L${x + 17},${y + 17} M${x + 17},${y + 5} L${x + 5},${y + 17}" stroke="${C.text}" stroke-width="1.4"/>` : `<circle cx="${x + 11}" cy="${y + 11}" r="10" fill="#fff" stroke="${C.text}" stroke-width="1.4"/><circle cx="${x + 11}" cy="${y + 11}" r="6" fill="${C.text}"/>` };
      const lines = wrap(n.text, 240, 12);
      const w = Math.max(80, Math.max(...lines.map(l => tw(l, 12))) + 28), h = lines.length * 16 + 16;
      return { w, h, cx: w / 2, draw: (x, y) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" fill="${C.head}" stroke="${C.stroke}" stroke-width="1.2"/>` + lines.map((l, k) => text(x + w / 2, y + 20 + k * 16, l, { size: 12, anchor: 'middle' })).join('') };
    };

    const diamond = (cond, minW = 0) => {
      const lines = cond ? wrap(cond, 200, 11.5) : [];
      const w = Math.max(minW, lines.length ? Math.max(...lines.map(l => tw(l, 11.5))) + 34 : 26), h = lines.length ? lines.length * 14 + 20 : 26;
      return { w, h, draw: (x, y) => `<path d="M${x},${y + h / 2} L${x + 12},${y} H${x + w - 12} L${x + w},${y + h / 2} L${x + w - 12},${y + h} H${x + 12} Z" fill="#fff" stroke="${C.stroke}" stroke-width="1.2"/>` + lines.map((l, k) => text(x + w / 2, y + h / 2 + 4 - (lines.length - 1) * 7 + k * 14, l, { size: 11.5, anchor: 'middle' })).join('') };
    };

    const seq = list => {
      const blocks = list.map(node);
      if (!blocks.length) return { w: 10, h: 0, cx: 5, empty: true, draw: () => '' };
      const L = Math.max(...blocks.map(b => b.cx)), R = Math.max(...blocks.map(b => b.w - b.cx));
      let h = 0;
      blocks.forEach((b, i) => { h += b.h + (i < blocks.length - 1 && !b.term ? V : i < blocks.length - 1 ? V : 0); });
      return {
        w: L + R, h, cx: L, term: blocks[blocks.length - 1].term,
        draw: (x, y) => {
          let s = '', yy = y;
          blocks.forEach((b, i) => {
            s += b.draw(x + L - b.cx, yy);
            yy += b.h;
            if (i < blocks.length - 1) { if (!b.term) s += arrow(x + L, yy, x + L, yy + V - 1); yy += V; }
          });
          return s;
        }
      };
    };

    const node = n => {
      if (n.t === 'start' || n.t === 'stop' || n.t === 'action') return leaf(n);
      if (n.t === 'if') {
        const branches = n.branches.map(b => ({ label: b.label, cond: b.cond, body: seq(b.body) }));
        // elseif : décisions en cascade, gérées comme des branches supplémentaires avec leur propre condition
        const cols = [...branches, { label: n.elseLabel || 'non', body: n.else ? seq(n.else) : seq([]), isElse: true }];
        const d = diamond(n.branches[0].cond);
        const GAP = 34;
        const colW = cols.map(c => Math.max(c.body.w, tw(c.label, 11) + 16, 40));
        const total = colW.reduce((s, w) => s + w, 0) + GAP * (cols.length - 1);
        const centers = []; let acc = 0;
        // Le contenu de chaque branche est centré dans sa colonne
        cols.forEach((c, i) => { centers.push(acc + (colW[i] - c.body.w) / 2 + c.body.cx); acc += colW[i] + GAP; });
        const w = Math.max(total, d.w);
        const offset = (w - total) / 2;
        const cx = Math.min(w - d.w / 2, Math.max(d.w / 2, (centers[0] + centers[centers.length - 1]) / 2 + offset));
        const top = d.h + 34;
        const bodyH = Math.max(...cols.map(c => c.body.h));
        const allTerm = cols.every(c => c.body.term);
        const h = top + bodyH + (allTerm ? 0 : 40);
        return {
          w, h, cx, term: allTerm,
          draw: (x, y) => {
            let s = d.draw(x + cx - d.w / 2, y);
            const busY = y + d.h + 14;
            cols.forEach((c, i) => {
              const bx = x + offset + centers[i];
              s += poly([[x + cx, y + d.h], [x + cx, busY], [bx, busY], [bx, y + top - 1]]);
              const condTxt = i > 0 && !c.isElse ? `${c.label} [${c.cond}]` : c.label;
              s += lab(bx + 5, busY + 13, condTxt);
              s += c.body.draw(bx - c.body.cx, y + top);
              if (!c.body.term) s += poly([[bx, y + top + c.body.h], [bx, y + top + bodyH + 20], [x + cx, y + top + bodyH + 20]], false);
            });
            if (!allTerm) s += `<path d="M${x + cx - 8},${y + top + bodyH + 20} L${x + cx},${y + top + bodyH + 12} L${x + cx + 8},${y + top + bodyH + 20} L${x + cx},${y + top + bodyH + 28} Z" fill="#fff" stroke="${C.stroke}" stroke-width="1.2"/>` + poly([[x + cx, y + top + bodyH + 28], [x + cx, y + h]], false);
            return s;
          }
        };
      }
      if (n.t === 'while') {
        const body = seq(n.body);
        const d = diamond(n.cond);
        const left = Math.max(d.w / 2, body.cx) + 30, right = Math.max(d.w / 2, body.w - body.cx) + 30;
        const top = d.h + 26;
        const h = top + body.h + 30;
        return {
          w: left + right, h, cx: left,
          draw: (x, y) => {
            const cx = x + left;
            let s = d.draw(cx - d.w / 2, y);
            s += arrow(cx, y + d.h, cx, y + top - 1) + lab(cx + 5, y + d.h + 15, n.label);
            s += body.draw(cx - body.cx, y + top);
            // retour vers la condition (à gauche)
            if (!body.term) s += poly([[cx, y + top + body.h], [cx, y + top + body.h + 14], [x + 8, y + top + body.h + 14], [x + 8, y + d.h / 2], [cx - d.w / 2 - 1, y + d.h / 2]]);
            // sortie de boucle (à droite) puis retour sur l'axe
            s += poly([[cx + d.w / 2, y + d.h / 2], [x + left + right - 8, y + d.h / 2], [x + left + right - 8, y + h - 6], [cx, y + h - 6], [cx, y + h]], false);
            s += lab(cx + d.w / 2 + 6, y + d.h / 2 - 5, n.exitLabel);
            return s;
          }
        };
      }
      if (n.t === 'repeat') {
        const body = seq(n.body);
        const d = diamond(n.cond || '');
        const left = Math.max(d.w / 2, body.cx) + 30, right = Math.max(d.w / 2, body.w - body.cx) + 14;
        const h = 14 + body.h + 24 + d.h;
        return {
          w: left + right, h, cx: left,
          draw: (x, y) => {
            const cx = x + left;
            let s = poly([[cx, y], [cx, y + 13]]) + body.draw(cx - body.cx, y + 14);
            s += arrow(cx, y + 14 + body.h, cx, y + 14 + body.h + 23);
            const dy = y + 14 + body.h + 24;
            s += d.draw(cx - d.w / 2, dy);
            s += poly([[cx - d.w / 2, dy + d.h / 2], [x + 8, dy + d.h / 2], [x + 8, y + 7], [cx - 1, y + 7]]) + lab(x + 12, dy + d.h / 2 - 5, n.label);
            return s;
          }
        };
      }
      if (n.t === 'fork') {
        const cols = n.branches.map(seq);
        const GAP = 30;
        const total = cols.reduce((s, c) => s + c.w, 0) + GAP * (cols.length - 1);
        const h = 6 + 24 + Math.max(...cols.map(c => c.h)) + 24 + 6;
        return {
          w: total, h, cx: total / 2,
          draw: (x, y) => {
            let s = `<rect x="${x}" y="${y}" width="${total}" height="6" fill="${C.text}"/>`;
            let acc = x;
            const bh = Math.max(...cols.map(c => c.h));
            for (const c of cols) {
              s += arrow(acc + c.cx, y + 6, acc + c.cx, y + 29) + c.draw(acc, y + 30);
              if (!c.term) s += poly([[acc + c.cx, y + 30 + c.h], [acc + c.cx, y + 30 + bh + 23]]);
              acc += c.w + GAP;
            }
            s += `<rect x="${x}" y="${y + 30 + bh + 24}" width="${total}" height="6" fill="${C.text}"/>`;
            return s;
          }
        };
      }
      return leaf({ t: 'action', text: '?' });
    };
    return seq(items);
  }

  function renderActivity(model) {
    if (!model.items.length) return frame(model.title, 300, 60, text(0, 30, 'Diagramme vide : commence par « start ».', { color: C.muted }));
    const b = layoutActivity(model.items);
    return frame(model.title, b.w, b.h, b.draw(0, 0));
  }

  function render(src) {
    const type = detect(src);
    const model = type === 'sequence' ? parseSequence(src) : type === 'activity' ? parseActivity(src) : parseClass(src);
    const out = type === 'sequence' ? renderSequence(model) : type === 'activity' ? renderActivity(model) : renderClass(model);
    return { ...out, type, errors: model.errors, title: model.title };
  }

  // PNG : le SVG est dessiné dans un canvas (échelle 2 pour un rendu net).
  function toPng(svg, width, height, scale = 2) {
    return new Promise((resolve, reject) => {
      // Un grand diagramme doublé dépasserait la taille maximale d'une image du navigateur (image vide) :
      // la netteté est réduite juste ce qu'il faut (au plus 16 000 px de côté et 100 millions de pixels).
      const w = Math.max(1, Number(width) || 800), h = Math.max(1, Number(height) || 600);
      scale = Math.max(0.25, Math.min(scale, 16000 / Math.max(w, h), Math.sqrt(1e8 / (w * h))));
      const img = new Image();
      img.onload = () => {
        try {
          const c = document.createElement('canvas');
          c.width = Math.ceil(w * scale); c.height = Math.ceil(h * scale);
          const g = c.getContext('2d');
          if (!g) throw new Error('Diagramme trop grand pour être converti en image.');
          g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
          g.scale(scale, scale); g.drawImage(img, 0, 0);
          const url = c.toDataURL('image/png');
          if (!url || url.length < 200) throw new Error('Diagramme trop grand pour être converti en image : exporte-le en PDF.');
          resolve(url);
        } catch (err) { reject(err); }
      };
      img.onerror = () => reject(new Error('Rendu PNG impossible : le diagramme contient une erreur ou un caractère non pris en charge.'));
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
  }

  const TEMPLATES = {
    class: `@startuml\n' type: class\ntitle Diagramme de classes\n\nclass Utilisateur {\n  +id: int\n  +nom: string\n  +email: string\n  +commandes(): HasMany\n}\n\nclass Commande {\n  +id: int\n  +total: decimal\n  +statut: string\n  +valider(): void\n}\n\nUtilisateur "1" --> "*" Commande : passe\n@enduml\n`,
    sequence: `@startuml\n' type: sequence\ntitle Diagramme de séquence\n\nactor Client\nparticipant Application\ndatabase "Base de données" as BD\n\nClient -> Application : envoie le formulaire\nApplication -> BD : enregistre la commande\nBD --> Application : commande créée\nalt paiement accepté\n  Application --> Client : confirmation\nelse refusé\n  Application --> Client : message d'erreur\nend\n@enduml\n`,
    activity: `@startuml\n' type: activity\ntitle Diagramme d'activité\n\nstart\n:Recevoir la commande;\nif (Stock disponible ?) then (oui)\n  :Préparer le colis;\n  :Expédier;\nelse (non)\n  :Prévenir le client;\n  stop\nendif\n:Envoyer la facture;\nstop\n@enduml\n`
  };

  window.UML = { render, toPng, detect, TEMPLATES };
})();
