// Base de données d'un projet : lecture/écriture de la connexion dans le .env, test, création (MySQL / MariaDB, SQLite).
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const DB_KEYS = ['DB_CONNECTION', 'DB_HOST', 'DB_PORT', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'];

// ---------- Fichier .env ----------
function parseEnv(text) {
  const out = {};
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!m) continue;
    let v = m[2].trim();
    if (/^"(.*)"$/.test(v)) v = v.slice(1, -1).replace(/\\"/g, '"');
    else if (/^'(.*)'$/.test(v)) v = v.slice(1, -1);
    else v = v.replace(/\s+#.*$/, '');
    out[m[1]] = v;
  }
  return out;
}

function readEnv(project) {
  const file = path.join(project.path, '.env');
  if (!fs.existsSync(file)) return { file, exists: false, values: {} };
  return { file, exists: true, values: parseEnv(fs.readFileSync(file, 'utf8')) };
}

function quoteEnv(v) {
  v = String(v ?? '');
  return v === '' || /^[\w.\-/:@]+$/.test(v) ? v : `"${v.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}

// Remplace (ou ajoute) uniquement les clés données ; le reste du fichier est conservé tel quel.
// Une copie de sécurité .env.devlauncher.bak est faite avant chaque écriture.
function writeEnv(project, patch) {
  const file = path.join(project.path, '.env');
  let text = '';
  if (fs.existsSync(file)) {
    text = fs.readFileSync(file, 'utf8');
    fs.writeFileSync(path.join(project.path, '.env.devlauncher.bak'), text);
  } else if (fs.existsSync(path.join(project.path, '.env.example'))) {
    text = fs.readFileSync(path.join(project.path, '.env.example'), 'utf8');
  }
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  const lines = text.length ? text.split(/\r?\n/) : [];
  for (const [k, v] of Object.entries(patch)) {
    const line = `${k}=${quoteEnv(v)}`;
    // Une ligne commentée (# DB_HOST=...) est réactivée à sa place, comme le fait Laravel 11+.
    const i = lines.findIndex(l => new RegExp(`^\\s*(#\\s*)?${k}\\s*=`).test(l));
    if (i >= 0) lines[i] = line;
    else {
      const last = lines.map((l, j) => (/^\s*#?\s*DB_/.test(l) ? j : -1)).filter(j => j >= 0).pop();
      if (last !== undefined) lines.splice(last + 1, 0, line); else lines.push(line);
    }
  }
  fs.writeFileSync(file, lines.join(eol));
  return true;
}

// ---------- Port du projet dans l'environnement ----------
// Quand le port d'un projet change, les adresses locales du .env suivent :
// APP_URL (même sans port), toute valeur contenant localhost:<ancien>, 127.0.0.1:<ancien>, et la clé PORT.
// Les adresses non locales (ex. http://monapp.test) ne sont jamais modifiées.
const LOCAL = '(localhost|127\\.0\\.0\\.1|0\\.0\\.0\\.0|\\[::1\\])';
function syncPortInEnv(project, oldPort, newPort) {
  const changes = [];
  if (!newPort || Number(oldPort) === Number(newPort)) return changes;
  for (const name of ['.env', '.env.local', '.env.development', '.env.development.local']) {
    const file = path.join(project.path, name);
    if (!fs.existsSync(file)) continue;
    const text = fs.readFileSync(file, 'utf8');
    const eol = text.includes('\r\n') ? '\r\n' : '\n';
    let touched = false;
    const lines = text.split(/\r?\n/).map(line => {
      const m = line.match(/^(\s*(?:export\s+)?)([A-Za-z_][A-Za-z0-9_]*)(\s*=\s*)(.*)$/);
      if (!m || line.trim().startsWith('#')) return line;
      const [, pre, key, eq, value] = m;
      let v = value;
      if (key === 'PORT' && v.replace(/["']/g, '').trim() === String(oldPort)) v = String(newPort);
      else {
        if (oldPort) v = v.replace(new RegExp(`${LOCAL}:${oldPort}(?!\\d)`, 'g'), `$1:${newPort}`);
        // APP_URL local sans port (Laravel met http://localhost par défaut)
        if (key === 'APP_URL' && v === value) v = v.replace(new RegExp(`^(["']?https?://${LOCAL})(?::\\d+)?(/?["']?)$`), `$1:${newPort}$3`);
      }
      if (v === value) return line;
      touched = true;
      changes.push({ file: name, key, from: value, to: v });
      return `${pre}${key}${eq}${v}`;
    });
    if (touched) {
      fs.writeFileSync(path.join(project.path, name + '.devlauncher.bak'), text);
      fs.writeFileSync(file, lines.join(eol));
    }
  }
  return changes;
}

// ---------- Client MySQL ----------
function mysqlClient(servers) {
  const s = servers.find(x => x.mysqlClient);
  return s ? s.mysqlClient : null;
}

// Exécute une requête ; le mot de passe passe par MYSQL_PWD (jamais en clair sur la ligne de commande).
function query(client, conn, sql, database) {
  return new Promise((resolve, reject) => {
    const args = ['--protocol=TCP', '-h', conn.host || '127.0.0.1', '-P', String(conn.port || 3306), '-u', conn.username || 'root',
      '--batch', '--skip-column-names', '--connect-timeout=4', '--default-character-set=utf8mb4'];
    if (database) args.push(database);
    args.push('-e', sql);
    execFile(client, args, { windowsHide: true, timeout: 15000, env: { ...process.env, MYSQL_PWD: conn.password || '' } }, (err, stdout, stderr) => {
      if (err) return reject(new Error(cleanError(stderr || err.message)));
      resolve(stdout.split(/\r?\n/).filter(Boolean).map(l => l.split('\t')));
    });
  });
}

function cleanError(msg) {
  const m = String(msg).replace(/^mysql: \[Warning\].*$/gm, '').trim();
  if (/ERROR 2003|Can't connect|10061/i.test(m)) return 'Le serveur MySQL ne répond pas à cette adresse : est-il démarré ? (hôte et port à vérifier)';
  if (/ERROR 1045/i.test(m)) return 'Utilisateur ou mot de passe refusé par MySQL.';
  if (/ERROR 1044/i.test(m)) return 'Cet utilisateur n\'a pas le droit d\'accéder ou de créer cette base. Utilise un compte administrateur (root).';
  if (/ERROR 1049/i.test(m)) return 'Cette base de données n\'existe pas.';
  if (/ERROR 1007/i.test(m)) return 'Une base porte déjà ce nom.';
  return m.replace(/^ERROR \d+ \([\w]+\)(?: at line \d+)?: /, '') || 'Erreur MySQL inconnue.';
}

const ident = name => '`' + String(name).replace(/`/g, '``') + '`';
const str = v => "'" + String(v).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";
const validName = n => /^[A-Za-z0-9_$-]{1,64}$/.test(n || '');
const validUser = n => /^[A-Za-z0-9_.-]{1,32}$/.test(n || '');

// Connexion décrite par le .env (valeurs Laravel par défaut si absentes).
function connFromEnv(values) {
  return {
    connection: values.DB_CONNECTION || 'mysql',
    host: values.DB_HOST || '127.0.0.1',
    port: values.DB_PORT || '3306',
    database: values.DB_DATABASE || '',
    username: values.DB_USERNAME || 'root',
    password: values.DB_PASSWORD || ''
  };
}

const isMysql = c => ['mysql', 'mariadb'].includes(String(c).toLowerCase());

function sqlitePath(project, database) {
  if (!database) return path.join(project.path, 'database', 'database.sqlite');
  return path.isAbsolute(database) ? database : path.join(project.path, database);
}

// État complet pour l'onglet « Base de données ».
async function info(project, servers) {
  const env = readEnv(project);
  const conn = connFromEnv(env.values);
  const client = mysqlClient(servers);
  const result = { envExists: env.exists, conn: { ...conn, password: undefined, hasPassword: !!conn.password }, client: !!client };
  if (conn.connection === 'sqlite') {
    const file = sqlitePath(project, env.values.DB_DATABASE);
    result.sqlite = { file, exists: fs.existsSync(file), size: fs.existsSync(file) ? fs.statSync(file).size : 0 };
    return result;
  }
  if (!isMysql(conn.connection)) { result.unsupported = true; return result; }
  if (!client) { result.error = 'Client mysql.exe introuvable (XAMPP, Laragon ou WAMP requis).'; return result; }
  try {
    const dbs = (await query(client, conn, 'SHOW DATABASES')).map(r => r[0])
      .filter(d => !['information_schema', 'performance_schema', 'mysql', 'sys', 'phpmyadmin'].includes(d.toLowerCase()));
    result.connected = true;
    result.databases = dbs;
    result.exists = !!conn.database && dbs.some(d => d.toLowerCase() === conn.database.toLowerCase());
    if (result.exists) {
      const r = await query(client, conn, `SELECT COUNT(*), COALESCE(SUM(data_length + index_length), 0) FROM information_schema.tables WHERE table_schema = ${str(conn.database)}`);
      result.tables = Number(r[0][0]);
      result.size = Number(r[0][1]);
      try {
        const m = await query(client, conn, `SELECT COUNT(*) FROM ${ident(conn.database)}.migrations`);
        result.migrations = Number(m[0][0]);
      } catch { result.migrations = null; } // table migrations absente : base jamais migrée
    }
    const v = await query(client, conn, 'SELECT VERSION()');
    result.serverVersion = v[0][0];
  } catch (err) {
    result.connected = false;
    result.error = err.message;
  }
  return result;
}

// Teste une connexion avant de l'enregistrer.
async function test(project, servers, values) {
  const conn = { ...connFromEnv(readEnv(project).values), ...values };
  if (values.password === undefined) conn.password = connFromEnv(readEnv(project).values).password;
  if (conn.connection === 'sqlite') return { ok: true, message: 'SQLite : aucun serveur à joindre.' };
  const client = mysqlClient(servers);
  if (!client) throw new Error('Client mysql.exe introuvable.');
  await query(client, conn, 'SELECT 1');
  let message = 'Connexion réussie.';
  if (conn.database) {
    const r = await query(client, conn, `SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = ${str(conn.database)}`);
    message += Number(r[0][0]) ? ` La base « ${conn.database} » existe.` : ` La base « ${conn.database} » n'existe pas encore : tu peux la créer.`;
  }
  return { ok: true, message };
}

// Crée la base (et éventuellement un utilisateur dédié) avec un compte administrateur.
async function create(project, servers, opts) {
  const { name, charset = 'utf8mb4', collation = 'utf8mb4_unicode_ci', admin = {}, user = null } = opts;
  if (!validName(name)) throw new Error('Nom de base invalide : lettres, chiffres, _ et - uniquement (64 caractères max).');
  if (!/^\w+$/.test(charset) || !/^\w+$/.test(collation)) throw new Error('Jeu de caractères invalide.');
  const envConn = connFromEnv(readEnv(project).values);
  if (envConn.connection === 'sqlite') {
    const file = sqlitePath(project, readEnv(project).values.DB_DATABASE);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    if (!fs.existsSync(file)) fs.writeFileSync(file, '');
    return { ok: true, message: `Fichier SQLite créé : ${path.relative(project.path, file)}` };
  }
  const client = mysqlClient(servers);
  if (!client) throw new Error('Client mysql.exe introuvable.');
  const conn = { ...envConn, username: admin.username || envConn.username, password: admin.password !== undefined ? admin.password : envConn.password };
  const sql = [`CREATE DATABASE IF NOT EXISTS ${ident(name)} CHARACTER SET ${charset} COLLATE ${collation}`];
  if (user) {
    if (!validUser(user.username)) throw new Error('Nom d\'utilisateur invalide : lettres, chiffres, _ . - (32 caractères max).');
    for (const host of ['localhost', '127.0.0.1']) {
      sql.push(`CREATE USER IF NOT EXISTS ${str(user.username)}@${str(host)} IDENTIFIED BY ${str(user.password || '')}`);
      sql.push(`GRANT ALL PRIVILEGES ON ${ident(name)}.* TO ${str(user.username)}@${str(host)}`);
    }
    sql.push('FLUSH PRIVILEGES');
  }
  await query(client, conn, sql.join('; '));
  return { ok: true, message: `Base « ${name} » prête${user ? `, accessible par l'utilisateur « ${user.username} »` : ''}.` };
}

module.exports = { DB_KEYS, readEnv, writeEnv, info, test, create, connFromEnv, syncPortInEnv };
