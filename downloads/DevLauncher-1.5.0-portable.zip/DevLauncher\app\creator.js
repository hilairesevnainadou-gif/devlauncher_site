// Création d'un nouveau projet dans le dossier choisi, sans commande à taper.
// Chaque type décrit sa famille, ses versions, ses options et ses étapes (commandes officielles de création, ou fichiers générés).
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

// Composer a besoin de l'extension zip pour décompresser les paquets. Si le PHP choisi la possède sans la charger
// (cas de Laragon), elle est activée pour la seule durée de la création, via un fichier ini supplémentaire :
// le php.ini du serveur n'est pas modifié.
function zipEnv(phpExe) {
  let modules = '';
  try { modules = execFileSync(phpExe, ['-m'], { encoding: 'utf8', windowsHide: true, timeout: 15000 }); } catch { return {}; }
  if (/^zip$/im.test(modules)) return {};
  let extDir = '';
  try { extDir = execFileSync(phpExe, ['-r', 'echo ini_get("extension_dir");'], { encoding: 'utf8', windowsHide: true, timeout: 15000 }).trim(); } catch { /* dossier par défaut */ }
  if (!path.isAbsolute(extDir)) extDir = path.join(path.dirname(phpExe), extDir || 'ext');
  if (!fs.existsSync(path.join(extDir, 'php_zip.dll'))) return {};
  const dir = path.join(os.tmpdir(), 'devlauncher-php-ini');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'devlauncher-zip.ini'), 'extension=zip\n');
  return { PHP_INI_SCAN_DIR: dir };
}

// versions : la première est proposée par défaut. php : [minimum, maximum testé] pour Laravel.
const TS = { key: 'typescript', label: 'TypeScript', desc: 'Code typé : les erreurs sont repérées pendant l\'écriture.', value: true };
const TYPES = {
  laravel: {
    label: 'Laravel', group: 'app', color: '#ff2d20', mark: 'L', desc: 'Application PHP complète : pages, comptes, base de données, e-mails.', needs: ['composer'], defaultPort: 8000,
    versions: [
      { id: '12', label: 'Laravel 12', tag: 'Dernière', php: ['8.2', null] },
      { id: '11', label: 'Laravel 11', php: ['8.2', null], eol: true },
      { id: '10', label: 'Laravel 10', php: ['8.1', '8.3'], eol: true },
      { id: '9', label: 'Laravel 9', php: ['8.0', '8.2'], eol: true }
    ],
    options: [
      { key: 'database', label: 'Base de données', choices: [['sqlite', 'SQLite', 'Un simple fichier, rien à installer'], ['mysql', 'MySQL', 'Base créée sur le serveur local']] },
      { key: 'npm', label: 'Dépendances de l\'interface', desc: 'Installe aussi les paquets npm (Vite, CSS, JavaScript).', value: true }
    ]
  },
  next: {
    label: 'Next.js', group: 'app', color: '#111111', mark: 'N', desc: 'Site ou application React avec pages côté serveur.', needs: ['node'], defaultPort: 3000,
    versions: [{ id: 'latest', label: 'Dernière version' }, { id: '15', label: 'Next.js 15' }, { id: '14', label: 'Next.js 14', eol: true }],
    options: [TS, { key: 'tailwind', label: 'Tailwind CSS', desc: 'Mise en forme rapide avec des classes prêtes à l\'emploi.', value: true },
      { key: 'eslint', label: 'ESLint', desc: 'Vérifie la qualité du code.', value: true }]
  },
  nuxt: { label: 'Nuxt', group: 'app', color: '#00dc82', mark: 'Nu', desc: 'Site ou application Vue avec pages côté serveur.', needs: ['node'], defaultPort: 3000, versions: [{ id: 'latest', label: 'Dernière version' }] },
  angular: {
    label: 'Angular', group: 'app', color: '#dd0031', mark: 'A', desc: 'Application Angular complète, structurée pour les grands projets.', needs: ['node'], defaultPort: 4200,
    versions: [{ id: 'latest', label: 'Dernière version' }, { id: '19', label: 'Angular 19' }, { id: '18', label: 'Angular 18', eol: true }, { id: '17', label: 'Angular 17', eol: true }]
  },
  react: {
    label: 'React', group: 'ui', color: '#149eca', mark: 'R', desc: 'Interface React (Vite), rapide à démarrer.', needs: ['node'], defaultPort: 5173,
    versions: [{ id: '19', label: 'React 19', tag: 'Dernière' }, { id: '18', label: 'React 18' }], options: [TS]
  },
  vue: { label: 'Vue', group: 'ui', color: '#42b883', mark: 'V', desc: 'Interface Vue 3 (Vite).', needs: ['node'], defaultPort: 5173, versions: [{ id: '3', label: 'Vue 3', tag: 'Dernière' }], options: [TS] },
  svelte: { label: 'Svelte', group: 'ui', color: '#ff3e00', mark: 'S', desc: 'Interface Svelte 5 (Vite), légère et rapide.', needs: ['node'], defaultPort: 5173, versions: [{ id: '5', label: 'Svelte 5', tag: 'Dernière' }], options: [TS] },
  astro: { label: 'Astro', group: 'ui', color: '#bc52ee', mark: 'As', desc: 'Site vitrine ou blog très rapide.', needs: ['node'], defaultPort: 4321, versions: [{ id: 'latest', label: 'Dernière version' }] },
  express: {
    label: 'API Express', group: 'base', color: '#3c4148', mark: 'Ex', desc: 'API Node.js minimale, prête à recevoir des routes.', needs: ['node'], defaultPort: 3000,
    versions: [{ id: '5', label: 'Express 5', tag: 'Dernière' }, { id: '4', label: 'Express 4' }]
  },
  php: { label: 'Site PHP', group: 'base', color: '#777bb4', mark: 'P', desc: 'Site PHP simple, sans framework.', needs: ['php'], defaultPort: 8000, versions: [{ id: 'any', label: 'PHP du serveur' }] }
};

const validName = (type, name) => (['laravel', 'php'].includes(type) ? /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/ : /^[a-z0-9][a-z0-9._-]{0,63}$/).test(name || '');
const slugDb = s => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 48) || 'app';

function cmpVersion(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
}
const minor = v => String(v).split('.').slice(0, 2).join('.');

// PHP le plus récent compatible avec une version de Laravel ; à défaut, un PHP plus récent que le maximum testé (signalé).
function phpFor(phps, [min, max]) {
  const ok = (phps || []).filter(p => cmpVersion(p.version, min) >= 0).sort((a, b) => cmpVersion(b.version, a.version));
  const inRange = ok.find(p => !max || cmpVersion(minor(p.version), max) <= 0);
  if (inRange) return { ...inRange, tested: true };
  return ok[0] ? { ...ok[0], tested: false } : null;
}

// Prérequis des outils sur le poste
function requirements(tools) {
  return {
    php: tools.php ? { ok: true, detail: `PHP ${(tools.phps || [])[0] ? tools.phps[0].version : ''}` } : { ok: false, detail: 'PHP introuvable (XAMPP, Laragon ou WAMP).' },
    composer: tools.composer ? { ok: true, detail: 'Composer' } : { ok: false, detail: 'Composer introuvable (getcomposer.org).' },
    node: tools.node && tools.npm ? { ok: true, detail: 'Node.js et npm' } : { ok: false, detail: 'Node.js introuvable (nodejs.org).' }
  };
}

// Description des types pour l'interface : disponibilité de chaque version sur ce poste.
function catalog(tools) {
  const req = requirements(tools);
  return Object.entries(TYPES).map(([id, t]) => {
    const missing = t.needs.filter(n => !req[n].ok).map(n => req[n].detail);
    const versions = t.versions.map(v => {
      if (!v.php) return { id: v.id, label: v.label, tag: v.tag || null, eol: !!v.eol, available: true };
      const php = phpFor(tools.phps, v.php);
      return {
        id: v.id, label: v.label, tag: v.tag || null, eol: !!v.eol, available: !!php,
        detail: php ? `PHP ${php.version}${php.tested ? '' : ' (plus récent que prévu pour cette version)'}` : `Demande PHP ${v.php[0]} ou plus récent`
      };
    });
    const available = !missing.length && versions.some(v => v.available);
    if (!missing.length && !available) missing.push(versions[versions.length - 1].detail);
    return { id, label: t.label, group: t.group, color: t.color, mark: t.mark, desc: t.desc, available, missing, versions, options: t.options || [] };
  });
}

// Étapes de création. Une étape : { label, cmd, cwd } (commande) ou { label, run: async helpers => {} } (code).
function plan(type, opts, ctx) {
  const t = TYPES[type];
  if (!t) throw new Error('Type de projet inconnu.');
  const v = t.versions.find(x => x.id === String(opts.version)) || t.versions[0];
  const { name, parent } = opts;
  const dir = path.join(parent, name);
  const q = s => `"${s}"`;
  const steps = [];
  const npmInstall = { label: 'Installer les dépendances', cmd: 'npm install --no-audit --no-fund', cwd: dir };
  const ts = opts.typescript !== false;
  let php = null;
  switch (type) {
    case 'laravel': {
      php = phpFor(ctx.phps, v.php);
      if (!php) throw new Error(`${v.label} demande PHP ${v.php[0]} ou plus récent.`);
      // Ce PHP passe en tête du PATH : Composer et artisan l'utilisent.
      const phpDir = path.dirname(php.exe);
      const major = Number(v.id);
      const env = { ...(ctx.preview ? {} : zipEnv(php.exe)), ...(v.eol ? { COMPOSER_NO_SECURITY_BLOCKING: '1' } : {}) };
      // retry : si un téléchargement échoue (fichier verrouillé par l'antivirus, coupure réseau) une fois le squelette
      // en place, l'installation des dépendances est relancée puis la clé de l'application générée.
      steps.push({
        label: `Télécharger ${v.label} et ses dépendances`, cmd: `${q(ctx.composer)} create-project laravel/laravel ${q(name)} "^${v.id}.0" --prefer-dist --no-interaction`, cwd: parent, phpDir, env,
        // Nouvelle tentative avec un seul téléchargement à la fois : sur une connexion lente, les téléchargements
        // parallèles qui expirent laissent des fichiers temporaires verrouillés (« Permission denied »).
        retry: { when: path.join(dir, 'composer.json'), times: 2, env: { ...env, COMPOSER_MAX_PARALLEL_HTTP: '1', COMPOSER_PROCESS_TIMEOUT: '1200' }, cmd: `${q(ctx.composer)} install --prefer-dist --no-interaction && ${q(php.exe)} -r "file_exists('.env') || copy('.env.example', '.env');" && ${q(php.exe)} artisan key:generate --force`, cwd: dir }
      });
      steps.push({ label: 'Configurer le projet (nom, adresse, base de données)', run: h => h.configureLaravel(dir, { sqlite: opts.database !== 'mysql', legacy: major < 11 }) });
      if (opts.database === 'mysql') steps.push({ label: 'Créer la base de données MySQL', run: h => h.createDatabase(dir) });
      // Toujours exécutée : sans effet si Laravel a déjà créé ses tables pendant le téléchargement.
      steps.push({ label: 'Créer les tables', cmd: `${q(php.exe)} artisan migrate --force`, cwd: dir, phpDir });
      if (opts.npm !== false) steps.push({ ...npmInstall, label: 'Installer les dépendances de l\'interface' });
      break;
    }
    case 'next': {
      const latest = v.id === 'latest';
      const f = [ts ? '--ts' : '--js', opts.tailwind === false ? '--no-tailwind' : '--tailwind', opts.eslint === false ? '--no-eslint' : '--eslint',
        '--app', '--src-dir', '--import-alias "@/*"', '--use-npm', ...(latest ? ['--yes'] : [])];
      steps.push({ label: `Créer le projet ${latest ? 'Next.js' : v.label} et installer ses dépendances`, cmd: `npx --yes create-next-app@${v.id} ${q(name)} ${f.join(' ')}`, cwd: parent });
      break;
    }
    case 'nuxt':
      steps.push({ label: 'Créer le projet Nuxt', cmd: `npx --yes nuxi@latest init ${q(name)} --packageManager=npm --gitInit=false --template=minimal --no-install`, cwd: parent });
      steps.push(npmInstall);
      break;
    case 'react': case 'vue': case 'svelte': {
      steps.push({ label: `Créer le projet ${t.label}`, cmd: `npm create vite@latest ${q(name)} -- --template ${type}${ts ? '-ts' : ''} --no-rolldown --no-immediate`, cwd: parent });
      steps.push(npmInstall);
      if (type === 'react' && v.id === '18') {
        steps.push({ label: 'Passer à React 18', cmd: `npm install --no-audit --no-fund react@18 react-dom@18${ts ? ' && npm install --no-audit --no-fund -D @types/react@18 @types/react-dom@18' : ''}`, cwd: dir });
      }
      break;
    }
    case 'angular':
      steps.push({ label: `Créer le projet ${v.id === 'latest' ? 'Angular' : v.label} et installer ses dépendances`, cmd: `npx --yes @angular/cli@${v.id} new ${q(name)} --defaults --skip-git --ssr=false --style=css --routing=true --package-manager=npm`, cwd: parent, env: { NG_CLI_ANALYTICS: 'false' } });
      break;
    case 'astro':
      steps.push({ label: 'Créer le projet Astro et installer ses dépendances', cmd: `npm create astro@latest ${q(name)} -- --template minimal --install --no-git --yes --skip-houston`, cwd: parent });
      break;
    case 'express':
      steps.push({ label: 'Créer les fichiers de l\'API', run: () => scaffoldExpress(dir, name, opts.port, v.id) });
      steps.push(npmInstall);
      break;
    case 'php':
      steps.push({ label: 'Créer les fichiers du site', run: () => scaffoldPhp(dir, name) });
      break;
  }
  return { dir, steps, version: v, php };
}

function scaffoldExpress(dir, name, port = 3000, major = '5') {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({
    name, version: '1.0.0', private: true, type: 'module',
    scripts: { dev: 'node --watch index.js', start: 'node index.js' },
    dependencies: { express: major === '4' ? '^4.21.2' : '^5.1.0' }
  }, null, 2) + '\n');
  fs.writeFileSync(path.join(dir, 'index.js'), `import express from 'express';

const app = express();
app.use(express.json());

// Première route : http://localhost:<port>/api/sante
app.get('/api/sante', (req, res) => {
  res.json({ statut: 'ok', date: new Date().toISOString() });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(\`API démarrée sur http://localhost:\${port}\`));
`);
  fs.writeFileSync(path.join(dir, '.gitignore'), 'node_modules\n.env\n');
  fs.writeFileSync(path.join(dir, '.env'), `PORT=${port}\n`);
}

function scaffoldPhp(dir, name) {
  fs.mkdirSync(path.join(dir, 'assets'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.php'), `<?php
$titre = '${name.replace(/'/g, '')}';
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($titre) ?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <main>
    <h1><?= htmlspecialchars($titre) ?></h1>
    <p>Le site fonctionne. Modifie <code>index.php</code> pour commencer.</p>
    <p class="faint">PHP <?= PHP_VERSION ?> · <?= date('d/m/Y H:i') ?></p>
  </main>
</body>
</html>
`);
  fs.writeFileSync(path.join(dir, 'assets', 'style.css'), 'body{margin:0;font:16px/1.6 system-ui,sans-serif;color:#1d2125;background:#f4f5f7}main{max-width:720px;margin:60px auto;padding:0 20px}.faint{color:#8b939c}code{background:#e8ecf0;padding:1px 5px;border-radius:4px}\n');
}

module.exports = { TYPES, requirements, catalog, plan, phpFor, validName, slugDb, cmpVersion };
