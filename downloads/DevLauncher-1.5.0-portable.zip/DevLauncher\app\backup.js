// Sauvegardes du serveur local : export SQL des bases (mysqldump), fichiers de configuration,
// copie brute du dossier data (quand MySQL ne démarre plus), restauration d'une base.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn, execFile } = require('child_process');
const maint = require('./maintenance');

const SYSTEM_DBS = new Set(['information_schema', 'performance_schema', 'mysql', 'sys', 'phpmyadmin']);
const stampName = () => {
  const d = new Date(), p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
};

function defaultDir() { return path.join(os.homedir(), 'Documents', 'DevLauncher', 'Sauvegardes'); }

function ps(script) {
  return new Promise((resolve, reject) => {
    execFile('powershell', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')],
      { windowsHide: true, maxBuffer: 16 * 1024 * 1024, timeout: 30 * 60 * 1000 }, (err, stdout, stderr) => (err ? reject(new Error(stderr || err.message)) : resolve(stdout)));
  });
}
const psq = s => "'" + String(s).replace(/'/g, "''") + "'";
const zipDir = (src, zip) => ps(`Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::CreateFromDirectory(${psq(src)}, ${psq(zip)}, 'Optimal', $false)`);
// Le .NET Framework range les fichiers avec "\" dans le zip : on compare les chemins sans tenir compte du séparateur.
const extractEntry = (zip, entry, out) => ps(`Add-Type -AssemblyName System.IO.Compression.FileSystem; $z = [IO.Compression.ZipFile]::OpenRead(${psq(zip)}); try { $want = ${psq(entry)}.Replace('\\', '/'); $e = $z.Entries | Where-Object { $_.FullName.Replace('\\', '/') -eq $want } | Select-Object -First 1; if (-not $e) { throw 'Fichier absent de la sauvegarde' }; [IO.Compression.ZipFileExtensions]::ExtractToFile($e, ${psq(out)}, $true) } finally { $z.Dispose() }`);

function mysqlArgs(my, creds) {
  return ['--protocol=TCP', '-h', '127.0.0.1', '-P', String(my.port), '-u', creds.user || 'root', '--default-character-set=utf8mb4'];
}
const mysqlEnv = creds => ({ ...process.env, MYSQL_PWD: creds.password || '' });

function query(my, creds, sql) {
  return new Promise((resolve, reject) => {
    execFile(my.client, [...mysqlArgs(my, creds), '--batch', '--skip-column-names', '-e', sql], { windowsHide: true, env: mysqlEnv(creds), timeout: 20000 },
      (err, stdout, stderr) => (err ? reject(new Error(/1045/.test(stderr) ? 'Utilisateur ou mot de passe MySQL refusé.' : /2003|10061/.test(stderr) ? 'MySQL ne répond pas : démarre-le d\'abord.' : (stderr || err.message).trim())) : resolve(stdout.split(/\r?\n/).filter(Boolean).map(l => l.split('\t')))));
  });
}

async function listDatabases(server, creds = {}) {
  const my = maint.mysqlConfig(server);
  const rows = await query(my, creds, "SELECT s.schema_name, COUNT(t.table_name), COALESCE(SUM(t.data_length + t.index_length), 0), COALESCE(SUM(t.table_type = 'BASE TABLE' AND t.engine IS NULL), 0) FROM information_schema.schemata s LEFT JOIN information_schema.tables t ON t.table_schema = s.schema_name GROUP BY s.schema_name ORDER BY s.schema_name");
  const probe = await maint.probeTables(my, creds);
  return rows.filter(r => !SYSTEM_DBS.has(r[0].toLowerCase())).map(r => {
    const p = probe.find(x => x.name === r[0]);
    return { name: r[0], tables: Number(r[1]), size: Number(r[2]), broken: p ? p.count : Number(r[3]) };
  });
}

// Export d'une base, robuste aux tables illisibles (« doesn't exist in engine ») :
// on n'exporte que les tables lisibles, et une table qui échoue malgré tout est mise de côté puis l'export relancé.
async function dumpDb(my, creds, db, file) {
  const esc = s => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
  const rows = await query(my, creds, `SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = '${esc(db)}'`);
  // Test d'accès réel : les métadonnées peuvent annoncer une table saine alors qu'elle est illisible.
  const unreadable = new Set(((await maint.probeTables(my, creds, db))[0] || { tables: [] }).tables);
  let tables = rows.filter(r => !unreadable.has(r[0])).map(r => r[0]);
  const skipped = rows.filter(r => unreadable.has(r[0])).map(r => r[0]);
  if (!tables.length) {
    fs.writeFileSync(file, `-- DevLauncher : aucune table lisible dans « ${db} » au moment de la sauvegarde.\n`);
    return { size: fs.statSync(file).size, skipped };
  }
  for (let attempt = 0; attempt < 50; attempt++) {
    try {
      const size = await dumpTables(my, creds, db, tables, file);
      return { size, skipped };
    } catch (err) {
      const bad = (err.message.match(/Table '[^.']+\.([^']+)' doesn't exist in engine/) || [])[1];
      if (!bad || !tables.includes(bad)) throw new Error(`Export de « ${db} » impossible : ${err.message}`);
      tables = tables.filter(t => t !== bad);
      skipped.push(bad);
      if (!tables.length) return dumpDb(my, creds, db, file);
    }
  }
  throw new Error(`Export de « ${db} » impossible : trop de tables illisibles.`);
}

function dumpTables(my, creds, db, tables, file) {
  return new Promise((resolve, reject) => {
    // --single-transaction : export cohérent sans bloquer les tables InnoDB. Pas de --databases : la restauration peut cibler un autre nom.
    const args = [...mysqlArgs(my, creds), '--single-transaction', '--quick', '--routines', '--triggers', '--events', '--hex-blob', '--add-drop-table', db, ...tables];
    const out = fs.createWriteStream(file);
    const child = spawn(my.mysqldump, args, { windowsHide: true, env: mysqlEnv(creds) });
    let err = '';
    child.stdout.pipe(out);
    child.stderr.on('data', d => { err += d; });
    child.on('error', reject);
    child.on('close', code => out.close(() => (code === 0 ? resolve(fs.statSync(file).size) : reject(new Error(err.trim().split('\n').pop() || `code ${code}`)))));
  });
}

const CONFIG_FILES = server => {
  const my = maint.mysqlConfig(server), ap = maint.apacheConfig(server);
  const php = server.php ? path.join(path.dirname(server.php), 'php.ini') : null;
  return [
    server.myini && ['mysql', server.myini],
    ap && ['apache', ap.conf],
    ap && ap.ssl && ['apache', ap.ssl],
    ap && ['apache', path.join(ap.root, 'conf', 'extra', 'httpd-vhosts.conf')],
    php && ['php', php],
    my && null
  ].filter(x => x && fs.existsSync(x[1]));
};

/**
 * Crée une sauvegarde .zip dans le dossier des sauvegardes.
 * opts : { type: 'dump' | 'raw', databases: [noms] | null (toutes), config: bool, label, creds, onProgress }
 */
async function create(server, dir, opts = {}) {
  const { type = 'dump', config = true, label = '', creds = {}, onProgress = () => {} } = opts;
  const my = maint.mysqlConfig(server);
  fs.mkdirSync(dir, { recursive: true });
  const name = `${stampName()}_${server.type.toLowerCase()}${label ? '_' + label.replace(/[^\w-]+/g, '-').slice(0, 30) : ''}`;
  const work = path.join(os.tmpdir(), `devlauncher-backup-${Date.now()}`);
  fs.mkdirSync(work, { recursive: true });
  const manifest = { app: 'DevLauncher', version: 1, name, date: new Date().toISOString(), server: { type: server.type, base: server.base }, type, label, databases: [], files: [] };
  try {
    if (type === 'dump') {
      if (!my.mysqldump) throw new Error('mysqldump.exe introuvable pour ce serveur.');
      let dbs = await listDatabases(server, creds);
      if (opts.databases && opts.databases.length) dbs = dbs.filter(d => opts.databases.includes(d.name));
      if (!dbs.length) throw new Error('Aucune base à sauvegarder.');
      fs.mkdirSync(path.join(work, 'databases'));
      for (let i = 0; i < dbs.length; i++) {
        onProgress({ step: 'dump', db: dbs[i].name, i: i + 1, n: dbs.length });
        const r = await dumpDb(my, creds, dbs[i].name, path.join(work, 'databases', `${dbs[i].name}.sql`));
        manifest.databases.push({ ...dbs[i], dumpSize: r.size, skipped: r.skipped });
      }
    } else {
      // Copie brute du dossier data : MySQL doit être arrêté pour que les fichiers soient cohérents.
      if (await maint.isPortOpen(my.port)) {
        const o = await maint.portOwner(my.port);
        if (o && maint.same(o.exe, server.mysqld)) throw new Error('Arrête MySQL avant une sauvegarde brute du dossier data (ou fais un export SQL, possible MySQL démarré).');
      }
      onProgress({ step: 'raw', i: 1, n: 1 });
      fs.cpSync(my.datadir, path.join(work, 'data'), { recursive: true, filter: src => !/\.(pid|dmp)$/i.test(src) && !/[\\/]ibtmp1$/i.test(src) });
      manifest.databases = fs.readdirSync(my.datadir, { withFileTypes: true }).filter(e => e.isDirectory() && !SYSTEM_DBS.has(e.name.toLowerCase())).map(e => ({ name: e.name }));
      manifest.datadir = my.datadir;
    }
    if (config) {
      fs.mkdirSync(path.join(work, 'config'));
      for (const [group, file] of CONFIG_FILES(server)) {
        const dest = path.join(work, 'config', `${group}-${path.basename(file)}`);
        fs.copyFileSync(file, dest);
        manifest.files.push({ group, source: file, name: path.basename(dest) });
      }
    }
    fs.writeFileSync(path.join(work, 'manifest.json'), JSON.stringify(manifest, null, 2));
    onProgress({ step: 'zip' });
    const zip = path.join(dir, `${name}.zip`);
    await zipDir(work, zip);
    manifest.size = fs.statSync(zip).size;
    fs.writeFileSync(path.join(dir, `${name}.json`), JSON.stringify(manifest, null, 2)); // index lisible sans ouvrir le zip
    return { ...manifest, file: zip };
  } finally {
    fs.rmSync(work, { recursive: true, force: true });
  }
}

function list(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter(f => f.endsWith('.json')).map(f => {
    try {
      const m = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
      const zip = path.join(dir, f.replace(/\.json$/, '.zip'));
      if (m.app !== 'DevLauncher' || !fs.existsSync(zip)) return null;
      return { ...m, file: zip, size: fs.statSync(zip).size };
    } catch { return null; }
  }).filter(Boolean).sort((a, b) => (a.date < b.date ? 1 : -1));
}

function remove(dir, name) {
  if (!/^[\w.-]+$/.test(name)) throw new Error('Nom invalide.');
  for (const ext of ['.zip', '.json']) fs.rmSync(path.join(dir, name + ext), { force: true });
  return true;
}

// Garde les « keep » dernières sauvegardes automatiques.
function rotate(dir, label, keep) {
  const autos = list(dir).filter(b => b.label === label);
  for (const b of autos.slice(keep)) remove(dir, b.name);
}

/**
 * Restaure une base depuis une sauvegarde SQL.
 * La base cible existante est d'abord sauvegardée automatiquement (label « avant-restauration »).
 */
async function restore(server, dir, backupName, db, target, creds = {}, onProgress = () => {}) {
  const b = list(dir).find(x => x.name === backupName);
  if (!b) throw new Error('Sauvegarde introuvable.');
  if (b.type !== 'dump') throw new Error('Cette sauvegarde est une copie brute du dossier data : restaure-la manuellement (voir le guide).');
  if (!b.databases.some(d => d.name === db)) throw new Error(`La base « ${db} » n'est pas dans cette sauvegarde.`);
  if (!/^[A-Za-z0-9_$-]{1,64}$/.test(target)) throw new Error('Nom de base cible invalide.');
  const my = maint.mysqlConfig(server);
  const existing = (await listDatabases(server, creds)).find(d => d.name.toLowerCase() === target.toLowerCase());
  let safety = null;
  if (existing && existing.tables > existing.broken) {
    onProgress({ step: 'safety', db: target });
    safety = await create(server, dir, { type: 'dump', databases: [existing.name], config: false, label: 'avant-restauration', creds });
  }
  onProgress({ step: 'extract' });
  const tmp = path.join(os.tmpdir(), `devlauncher-restore-${Date.now()}.sql`);
  try {
    await extractEntry(b.file, `databases/${db}.sql`, tmp);
    await query(my, creds, `CREATE DATABASE IF NOT EXISTS \`${target.replace(/`/g, '``')}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    onProgress({ step: 'import', db: target });
    await new Promise((resolve, reject) => {
      const child = spawn(my.client, [...mysqlArgs(my, creds), target], { windowsHide: true, env: mysqlEnv(creds) });
      let err = '';
      child.stderr.on('data', d => { err += d; });
      child.on('error', reject);
      child.on('close', code => (code === 0 ? resolve() : reject(new Error(err.trim().split('\n').pop() || `Import échoué (code ${code}).`))));
      fs.createReadStream(tmp).pipe(child.stdin);
    });
  } finally { fs.rmSync(tmp, { force: true }); }
  return { ok: true, message: `Base « ${target} » restaurée depuis la sauvegarde du ${new Date(b.date).toLocaleString('fr-FR')}.`, safety: safety ? safety.name : null };
}

module.exports = { defaultDir, create, list, remove, rotate, restore, listDatabases, extractEntry };
