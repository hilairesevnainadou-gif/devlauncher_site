// File d'attente Laravel (pilote « database ») : e-mails, notifications et tâches en attente ou en échec.
const { execFile } = require('child_process');
const db = require('./db');
const H = require('./humanize');

// Exécute une requête avec la connexion du .env du projet (sortie --batch : tabulations, \n échappés).
function query(client, conn, sql) {
  return new Promise((resolve, reject) => {
    const args = ['--protocol=TCP', '-h', conn.host || '127.0.0.1', '-P', String(conn.port || 3306), '-u', conn.username || 'root',
      '--batch', '--skip-column-names', '--connect-timeout=4', '--default-character-set=utf8mb4', conn.database, '-e', sql];
    execFile(client, args, { windowsHide: true, timeout: 20000, maxBuffer: 64 * 1024 * 1024, env: { ...process.env, MYSQL_PWD: conn.password || '' } }, (err, stdout, stderr) => {
      if (err) return reject(new Error(/1146/.test(stderr) ? 'TABLE_MISSING' : /2003|10061/.test(stderr) ? 'MySQL ne répond pas.' : /1045/.test(stderr) ? 'Identifiants MySQL refusés.' : (stderr || err.message).trim().split('\n').pop()));
      const unesc = v => (v === 'NULL' ? null : v.replace(/\\(n|t|\\|0)/g, (_, c) => ({ n: '\n', t: '\t', '\\': '\\', 0: '\0' }[c])));
      resolve(stdout.split('\n').filter(Boolean).map(l => l.split('\t').map(unesc)));
    });
  });
}

// Lit le contenu d'une tâche (payload JSON + objet PHP sérialisé) : type, intitulé, destinataires.
function describe(payloadText) {
  let p = {};
  try { p = JSON.parse(payloadText || '{}'); } catch { /* payload illisible */ }
  const data = p.data || {};
  const command = String(data.command || '');
  const display = String(p.displayName || data.commandName || '');
  let kind = 'Tâche', cls = display;
  let m;
  if (/SendQueuedMailable/.test(display) || /SendQueuedMailable/.test(data.commandName || '')) {
    kind = 'E-mail';
    if ((m = command.match(/s:8:"mailable";O:\d+:"([^"]+)"/))) cls = m[1];
  } else if (/SendQueuedNotifications/.test(display) || /SendQueuedNotifications/.test(data.commandName || '')) {
    kind = 'Notification';
    if ((m = command.match(/s:12:"notification";O:\d+:"([^"]+)"/))) cls = m[1];
  } else if (/Mail\\/.test(display) || /Mailable/.test(command)) kind = 'E-mail';
  else if (/Notification/.test(display)) kind = 'Notification';
  const short = cls.split('\\').pop();
  const recipients = [...new Set([...command.matchAll(/s:7:"address";s:\d+:"([^"]+@[^"]+)"/g)].map(x => x[1]))];
  if (!recipients.length) for (const x of command.matchAll(/"([\w.+-]+@[\w-]+\.[\w.-]+)"/g)) recipients.push(x[1]);
  const subject = (command.match(/s:7:"subject";s:\d+:"([^"]*)"/) || [])[1] || null;
  // Intitulé lisible : « WelcomeMail » -> « E-mail de bienvenue », « SendInvoiceReminder » -> « Envoyer le rappel de facture »
  const title = H.phrase(short.replace(/(Mail|Mailable|Notification|Job)$/, '') || short) || H.cap(H.words(short).join(' '));
  return { kind, title, cls: short, recipients: [...new Set(recipients)].slice(0, 10), subject, maxTries: p.maxTries || null, queue: p.queue || null };
}

const toDate = v => (v && /^\d+$/.test(v) ? new Date(Number(v) * 1000).toISOString() : v || null);

/** État de la file d'attente d'un projet Laravel. */
async function info(project, servers) {
  const env = db.readEnv(project).values;
  const connection = env.QUEUE_CONNECTION || env.QUEUE_DRIVER || 'sync';
  const conn = db.connFromEnv(env);
  const out = { connection, table: env.DB_QUEUE_TABLE || 'jobs', pending: [], failed: [], tableMissing: false, failedMissing: false };
  const s = servers.find(x => x.mysqlClient);
  const client = s ? s.mysqlClient : null;
  if (!client || !['mysql', 'mariadb'].includes(String(conn.connection).toLowerCase())) { out.unsupported = true; }
  else {
    const now = Math.floor(Date.now() / 1000);
    try {
      const rows = await query(client, conn, `SELECT id, queue, attempts, reserved_at, available_at, created_at, payload FROM \`${out.table.replace(/`/g, '')}\` ORDER BY id LIMIT 500`);
      out.pending = rows.map(([id, queue, attempts, reserved, available, created, payload]) => ({
        id: Number(id), queue, attempts: Number(attempts), created: toDate(created), available: toDate(available),
        state: reserved ? 'running' : Number(available) > now ? 'scheduled' : 'waiting', ...describe(payload)
      }));
    } catch (err) { if (err.message === 'TABLE_MISSING') out.tableMissing = true; else out.error = err.message; }
    try {
      const rows = await query(client, conn, 'SELECT id, uuid, queue, failed_at, payload, LEFT(exception, 3000) FROM failed_jobs ORDER BY id DESC LIMIT 300');
      out.failed = rows.map(([id, uuid, queue, failedAt, payload, exception]) => ({
        id: Number(id), uuid, queue, failed: failedAt, error: String(exception || '').split('\n')[0].replace(/^[\w\\]+: /, '').slice(0, 300), ...describe(payload)
      }));
    } catch (err) { if (err.message === 'TABLE_MISSING') out.failedMissing = true; else if (!out.error) out.error = err.message; }
  }
  out.queues = [...new Set(out.pending.map(j => j.queue).filter(Boolean))];
  return out;
}

async function deletePending(project, servers, ids) {
  const env = db.readEnv(project).values;
  const conn = db.connFromEnv(env);
  const s = servers.find(x => x.mysqlClient);
  if (!s) throw new Error('Client mysql.exe introuvable.');
  const list = (ids === 'all' ? [] : ids).map(Number).filter(Number.isInteger);
  const table = (env.DB_QUEUE_TABLE || 'jobs').replace(/`/g, '');
  // Les tâches en cours de traitement (reserved_at) ne sont pas supprimées
  const sql = ids === 'all' ? `DELETE FROM \`${table}\` WHERE reserved_at IS NULL` : list.length ? `DELETE FROM \`${table}\` WHERE id IN (${list.join(',')}) AND reserved_at IS NULL` : null;
  if (!sql) return 0;
  await query(s.mysqlClient, conn, sql);
  return list.length || 'all';
}

module.exports = { info, deletePending, describe };
