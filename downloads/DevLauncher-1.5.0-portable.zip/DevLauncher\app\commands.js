// Construit les commandes à exécuter selon le type de projet.
const path = require('path');

function q(p) { return `"${p}"`; }

function pmRun(pm, script) {
  return pm === 'npm' ? `npm run ${script}` : `${pm} ${script}`;
}

function pmInstall(pm) {
  return pm === 'npm' ? 'npm install' : `${pm} install`;
}

// Commande de lancement du serveur de dev.
function startCommand(project, port, tools) {
  const php = (project.php || tools.php) ? q(project.php || tools.php) : 'php';
  const env = {};
  switch (project.type) {
    case 'laravel':
      return { cmd: `${php} artisan serve --host=127.0.0.1 --port=${port}`, env };
    case 'php':
      // docroot : dossier de la page d'entrée (« public » pour les projets PHP structurés)
      return { cmd: `${php} -S 127.0.0.1:${port}${project.docroot ? ' -t ' + q(project.docroot) : ''}`, env };
    case 'static':
      // Site HTML : petit serveur intégré, exécuté par le Node de DevLauncher (rien à installer)
      return { cmd: `${q(process.execPath)} ${q(path.join(__dirname, 'static-server.js'))} ${port}`, env };
    case 'next':
      return { cmd: `npx --no-install next dev -p ${port}`, env };
    case 'nuxt':
      return { cmd: `npx --no-install nuxt dev --port ${port}`, env: { PORT: String(port), NUXT_PORT: String(port) } };
    case 'angular':
      return { cmd: `npx --no-install ng serve --port ${port}`, env };
    case 'astro':
      return { cmd: `npx --no-install astro dev --port ${port}`, env };
    case 'cra':
      return { cmd: 'npx --no-install react-scripts start', env: { PORT: String(port), BROWSER: 'none' } };
    case 'vuecli':
      return { cmd: `npx --no-install vue-cli-service serve --port ${port}`, env };
    case 'vite':
      return { cmd: `npx --no-install vite --port ${port} --strictPort`, env };
    default: {
      const script = project.scripts.includes('dev') ? 'dev' : 'start';
      return { cmd: pmRun(project.pm, script), env: { PORT: String(port) } };
    }
  }
}

// Serveur Vite des assets pour un projet Laravel (le plugin laravel-vite écrit public/hot automatiquement).
function viteCommand(port) {
  return { cmd: `npx --no-install vite --port ${port} --strictPort`, env: {} };
}

// Actions secondaires disponibles par type de projet.
// group : regroupement dans l'interface ; danger : action destructrice (confirmation renforcée).
function actions(project, tools) {
  const php = (project.php || tools.php) ? q(project.php || tools.php) : 'php';
  const composer = tools.composer ? q(tools.composer) : 'composer';
  const list = [];
  const add = (id, group, label, desc, cmd, danger = false) => list.push({ id, group, label, desc, cmd, danger });

  if (project.type === 'laravel') {
    add('install', 'Projet', 'Installer les dépendances',
      'composer install, création du .env depuis .env.example s\'il manque, génération de la clé si elle est vide' + (project.hasVite ? ', puis npm install.' : '.'),
      buildLaravelInstall(project, php, composer));
    add('clear', 'Projet', 'Vider les caches', 'Vide les caches de configuration, routes, vues et événements. Utile après une modification du .env.', `${php} artisan optimize:clear`);
    add('storage', 'Projet', 'Lien de stockage', 'Crée le lien public/storage pour rendre accessibles les fichiers envoyés.', `${php} artisan storage:link`);
    add('migrate', 'Base de données', 'Migrer', 'Crée les tables et colonnes des migrations pas encore exécutées. Les données existantes sont conservées.', `${php} artisan migrate --force`);
    add('status', 'Base de données', 'État des migrations', 'Affiche les migrations déjà exécutées et celles en attente. Ne modifie rien.', `${php} artisan migrate:status`);
    add('seed', 'Base de données', 'Remplir (seed)', 'Exécute les seeders pour insérer les données de départ ou de test.', `${php} artisan db:seed --force`);
    add('rollback', 'Base de données', 'Annuler la dernière migration', 'Annule le dernier lot de migrations exécuté. Les données des tables concernées peuvent être perdues.', `${php} artisan migrate:rollback --force`, true);
    add('fresh', 'Base de données', 'Réinitialiser la base', 'Supprime TOUTES les tables, relance toutes les migrations puis les seeders. Toutes les données sont perdues.', `${php} artisan migrate:fresh --seed --force`, true);
  } else if (project.type === 'php') {
    add('install', 'Projet', 'Installer les dépendances', 'Installe les paquets du composer.json dans vendor.', `${composer} install`);
  } else if (project.type === 'static') {
    // Site HTML : aucune dépendance, sauf s'il utilise un package.json pour ses outils (Tailwind, etc.)
    if (project.scripts.length) add('install', 'Projet', 'Installer les outils', `Installe les paquets du package.json (${project.pm}), s'il y en a.`, pmInstall(project.pm));
    if (project.scripts.includes('build')) add('build', 'Projet', 'Compiler (build)', 'Exécute le script build du package.json.', pmRun(project.pm, 'build'));
  } else {
    add('install', 'Projet', 'Installer les dépendances', `Installe les paquets du package.json dans node_modules (${project.pm}).`, pmInstall(project.pm));
    if (project.scripts.includes('build')) add('build', 'Projet', 'Compiler (build)', 'Génère la version de production du projet.', pmRun(project.pm, 'build'));
    if (project.hasPrisma) {
      add('generate', 'Base de données', 'Générer le client Prisma', 'Régénère le client Prisma à partir du schéma.', 'npx --no-install prisma generate');
      add('migrate', 'Base de données', 'Migrer', 'Applique les migrations Prisma en attente. Les données existantes sont conservées.', 'npx --no-install prisma migrate deploy');
      add('status', 'Base de données', 'État des migrations', 'Affiche les migrations appliquées et en attente. Ne modifie rien.', 'npx --no-install prisma migrate status');
      add('seed', 'Base de données', 'Remplir (seed)', 'Exécute le script de seed Prisma.', 'npx --no-install prisma db seed');
      add('reset', 'Base de données', 'Réinitialiser la base', 'Supprime toutes les données, réapplique les migrations puis le seed.', 'npx --no-install prisma migrate reset --force', true);
    }
  }
  return list;
}

function buildLaravelInstall(project, php, composer) {
  const steps = [`${composer} install`];
  if (!project.hasEnv && project.hasEnvExample) steps.push('copy /Y .env.example .env');
  if (project.needsKey) steps.push(`${php} artisan key:generate --force`);
  if (project.hasVite) steps.push(pmInstall(project.pm));
  return steps.join(' && ');
}

module.exports = { startCommand, viteCommand, actions };
