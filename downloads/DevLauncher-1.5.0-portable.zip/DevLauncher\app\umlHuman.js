// Diagrammes UML en langage courant : aucune méthode HTTP, nom de méthode, de contrôleur ni commande.
// Réutilise l'analyse du code de uml.js ; les libellés viennent de humanize.js.
const fs = require('fs');
const path = require('path');
const u = require('./uml');
const H = require('./humanize');

const clean = s => String(s).replace(/[;\r\n]+/g, ' ').replace(/"/g, '\'').trim();
const short = (s, n = 70) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

// Intitulé d'une action de contrôleur : celui de sa route si elle en a une, sinon le nom reformulé.
function actionTitle(p, file, fn, cls) {
  const ctrl = cls || path.basename(file).replace(/\.\w+$/, '');
  const r = u.routes(p).find(x => x.controller.split('\\').pop() === ctrl && x.method === fn);
  if (r) return H.routeTitle(r);
  return H.phrase(fn, H.words(ctrl)) || H.cap(H.words(fn).join(' '));
}

function modelsOf(p) {
  const dir = path.join(p.path, 'app', 'Models');
  try { return new Set(fs.readdirSync(dir).filter(f => f.endsWith('.php')).map(f => f.slice(0, -4))); } catch { return new Set(); }
}

// Variables typées : $invoice = Invoice::find(...), paramètres « Invoice $invoice »
function collectVars(params, models) {
  const vars = {};
  for (const m of String(params || '').matchAll(/(\w+)\s+\$(\w+)/g)) if (models.has(m[1])) vars[m[2]] = m[1];
  return vars;
}

// ---------- Activité ----------
function activityLines(nodes, ctx, depth = 1) {
  const pad = '  '.repeat(depth);
  const out = [];
  let buf = [];
  const flush = () => {
    const uniq = buf.filter((x, i) => buf.indexOf(x) === i);
    for (let k = 0; k < uniq.length; k += 3) out.push(`${pad}:${uniq.slice(k, k + 3).map(clean).join('\\n')};`);
    buf = [];
  };
  for (const n of nodes) {
    if (n.type === 'stmt') {
      const vm = n.text.match(/^\$(\w+)\s*=\s*([A-Z]\w+)::/);
      if (vm && ctx.models.has(vm[2])) ctx.vars[vm[1]] = vm[2];
      const s = H.statement(n.text, ctx);
      if (s) buf.push(s);
      continue;
    }
    flush();
    if (n.type === 'return') { out.push(`${pad}:${clean(H.responsePhrase(n.text))};`, `${pad}stop`); continue; }
    if (n.type === 'if') {
      n.branches.forEach((b, k) => {
        out.push(`${pad}${k === 0 ? 'if' : 'elseif'} (${clean(short(H.condition(b.cond), 60))} ?) then (oui)`);
        const inner = activityLines(b.body, ctx, depth + 1);
        out.push(...(inner.length ? inner : [`${pad}  :Continuer;`]));
      });
      if (n.else) { out.push(`${pad}else (non)`); out.push(...activityLines(n.else, ctx, depth + 1)); }
      out.push(`${pad}endif`);
      continue;
    }
    if (n.type === 'loop') {
      const fe = n.cond.match(/^(.*?)\s+as\s+(?:\$\w+\s*=>\s*)?\$(\w+)/i);
      const label = n.kind === 'foreach' && fe ? `pour chaque ${H.fieldName(fe[2])}` : `tant que ${H.condition(n.cond)}`;
      out.push(`${pad}while (${clean(short(label, 60))} ?) is (oui)`);
      const inner = activityLines(n.body, ctx, depth + 1);
      out.push(...(inner.length ? inner : [`${pad}  :Traiter l'élément;`]));
      out.push(`${pad}endwhile (terminé)`);
      continue;
    }
    if (n.type === 'try') {
      out.push(...activityLines(n.body, ctx, depth));
      for (const c of n.catches) {
        out.push(`${pad}if (une erreur survient ?) then (oui)`);
        const inner = activityLines(c.body, ctx, depth + 1);
        out.push(...(inner.length ? inner : [`${pad}  :Signaler l'erreur;`]));
        out.push(`${pad}endif`);
      }
    }
  }
  flush();
  return out;
}

function activityHuman(p, file, fnName) {
  const full = path.join(p.path, file);
  if (!full.startsWith(p.path) || !fs.existsSync(full)) throw new Error('Fichier introuvable.');
  const { src, m, fns } = u.functionsOf(full);
  const fn = fns.find(f => f.name === fnName);
  if (!fn) throw new Error('Fonction introuvable dans ce fichier.');
  const models = modelsOf(p);
  const ctx = { models, vars: collectVars(fn.params, models), src };
  const body = u.parseBlock(src, m, fn.start + 1, fn.end);
  const title = actionTitle(p, file, fn.name, fn.class);
  let lines = activityLines(body, ctx);
  if (!lines.some(l => /^\s*:/.test(l))) lines = ['  :Traiter la demande;', ...lines];
  const text = ['@startuml', "' type: activity", `' source: ${file.replace(/\\/g, '/')} (ligne ${fn.line})`, `title ${title}`, 'start', ...lines, 'stop', '@enduml', ''].join('\n');
  return text.replace(/(\n\s*stop)\nstop\n@enduml/, '$1\n@enduml');
}

// ---------- Séquence ----------
function sequenceHuman(p, routeIndex) {
  const r = u.routes(p)[Number(routeIndex)];
  if (!r) throw new Error('Route introuvable.');
  const title = H.routeTitle(r);
  const file = u.controllerFile(p, r.controller);
  const models = modelsOf(p);
  const parts = new Map(); // clé -> { alias, label, kind }
  const part = (key, label, kind = 'participant') => {
    if (!parts.has(key)) parts.set(key, { alias: `P${parts.size + 1}`, label, kind });
    return parts.get(key).alias;
  };
  const out = [`Utilisateur -> App : ${clean(title)}`];
  let finalReturn = null;
  const pad = d => '  '.repeat(d);
  if (file) {
    const { src, m, fns } = u.functionsOf(file);
    const ctrl = r.controller.split('\\').pop();
    const fn = fns.find(f => f.name === r.method && f.class === ctrl) || fns.find(f => f.name === r.method);
    const props = {};
    const ctor = fns.find(f => f.name === '__construct');
    if (ctor) for (const pm of ctor.params.matchAll(/(\w+)\s+\$(\w+)/g)) props[pm[2]] = pm[1];
    if (fn) {
      const vars = collectVars(fn.params, models);
      const formRequest = (fn.params.match(/(\w+Request)\s+\$\w+/) || [])[1];
      if (formRequest && formRequest !== 'Request') {
        const v = part('validation', 'Validation', 'control');
        out.push(`App -> ${v} : Vérifier les informations saisies`, `${v} --> App : Informations valides`);
      }
      const msg = (d, to, text, ret, async) => {
        out.push(`${pad(d)}App ${async ? '->>' : '->'} ${to} : ${clean(text)}`);
        if (ret) out.push(`${pad(d)}${to} --> App : ${clean(ret)}`);
      };
      const calls = (t, d) => {
        // Validation dans le contrôleur
        if (/\$request->validate\(|Validator::make/.test(t)) msg(d, part('validation', 'Validation', 'control'), 'Vérifier les informations saisies', 'Informations valides');
        for (const c of t.matchAll(/\b([A-Z]\w+)::(\w+)\(/g)) {
          if (models.has(c[1])) msg(d, part('m:' + c[1], H.modelLabel(c[1]), 'entity'), H.modelCall(c[1], c[2]), H.modelResult(c[1], c[2]));
          else if (H.FACADES[c[1]]) msg(d, part('f:' + c[1], H.FACADES[c[1]].label, c[1] === 'DB' ? 'database' : 'participant'), H.FACADES[c[1]].call(c[2]), null, c[1] === 'Event');
        }
        for (const c of t.matchAll(/\$this->(\w+)->(\w+)\(/g)) {
          const type = props[c[1]] || c[1];
          msg(d, part('s:' + type, H.serviceLabel(type)), H.phrase(c[2], H.words(type)) || 'Traiter la demande', 'Résultat');
        }
        for (const c of t.matchAll(/\$(\w+)->(save|update|delete|attach|detach|sync|refresh|load|increment|decrement)\(/g)) {
          if (vars[c[1]]) msg(d, part('m:' + vars[c[1]], H.modelLabel(vars[c[1]]), 'entity'), H.modelCall(vars[c[1]], c[2]), null);
        }
        if (/->notify\(|Notification::send/.test(t)) msg(d, part('f:Notification', 'Notifications'), 'Envoyer une notification', null, true);
        if (/\bevent\(|::dispatch\(|\bdispatch\(/.test(t) && !/Event::/.test(t)) msg(d, part('f:Event', 'Traitements automatiques'), 'Déclencher un traitement automatique', null, true);
        if (/auth\(\)->(login|attempt|logout)/.test(t)) msg(d, part('f:Auth', 'Authentification'), H.FACADES.Auth.call(t.match(/auth\(\)->(\w+)/)[1]), null);
        if (/->(store|storeAs|storePublicly)\(/.test(t) && /file|photo|image|avatar|document|upload/i.test(t)) msg(d, part('f:Storage', 'Stockage des fichiers'), 'Enregistrer le fichier envoyé', null);
      };
      const walk = (nodes, d) => {
        for (const n of nodes) {
          if (n.type === 'stmt' || n.type === 'return') {
            const vm = n.text.match(/^\$(\w+)\s*=\s*([A-Z]\w+)::/);
            if (vm && models.has(vm[2])) vars[vm[1]] = vm[2];
            calls(n.text, d);
            if (n.type === 'return') { const label = H.responsePhrase(n.text); if (d === 1) finalReturn = label; else out.push(`${pad(d)}App --> Utilisateur : ${clean(label)}`); }
          } else if (n.type === 'if') {
            n.branches.forEach((b, k) => { out.push(`${pad(d)}${k === 0 ? 'alt' : 'else'} ${clean(short(H.condition(b.cond), 60))}`); walk(b.body, d + 1); });
            if (n.else) { out.push(`${pad(d)}else sinon`); walk(n.else, d + 1); }
            out.push(`${pad(d)}end`);
          } else if (n.type === 'loop') {
            const fe = n.cond.match(/^(.*?)\s+as\s+(?:\$\w+\s*=>\s*)?\$(\w+)/i);
            out.push(`${pad(d)}loop ${clean(short(n.kind === 'foreach' && fe ? `pour chaque ${H.fieldName(fe[2])}` : `tant que ${H.condition(n.cond)}`, 60))}`);
            walk(n.body, d + 1);
            out.push(`${pad(d)}end`);
          } else if (n.type === 'try') {
            walk(n.body, d);
            for (const c of n.catches) { out.push(`${pad(d)}opt en cas d'erreur`); walk(c.body, d + 1); out.push(`${pad(d)}end`); }
          }
        }
      };
      walk(u.parseBlock(src, m, fn.start + 1, fn.end), 1);
    }
  }
  out.push(`App --> Utilisateur : ${clean(finalReturn || 'Afficher le résultat')}`);
  const head = ['@startuml', "' type: sequence", `' source: routes/${r.file} (${r.verb} ${r.uri})`, `title ${title}`, 'actor Utilisateur', 'participant "Application" as App'];
  for (const pr of parts.values()) head.push(`${pr.kind} "${pr.label}" as ${pr.alias}`);
  return [...head, ...u.dropEmptyFragments(out), '@enduml', ''].join('\n');
}

// ---------- Classes ----------
const HIDDEN = new Set(['id', 'remember_token', 'password', 'deleted_at', 'email_verified_at_token']);
const REL_VERB = { hasMany: 'possède', hasOne: 'a', belongsToMany: 'est lié à', morphMany: 'possède', morphOne: 'a', morphToMany: 'est lié à', morphedByMany: 'est lié à', hasManyThrough: 'accède à', hasOneThrough: 'accède à' };

function classHuman(p, opts = {}) {
  const source = opts.source || (p.type === 'laravel' ? 'models' : 'typescript');
  let classes;
  if (source === 'prisma') classes = u.prismaClasses(p);
  else if (source === 'typescript') classes = u.tsClasses(p);
  else {
    const dir = source === 'models' ? path.join(p.path, 'app', 'Models') : path.join(p.path, opts.folder || 'app');
    classes = u.phpClasses(u.walk(fs.existsSync(dir) ? dir : path.join(p.path, 'app'), /\.php$/, 800));
    if (source === 'models') classes = classes.filter(c => /Model|Authenticatable|Pivot|User/.test(c.parent || '') || c.relations.length || classes.some(o => o.parent === c.name));
  }
  if (!classes || !classes.length) throw new Error('Aucune classe trouvée pour cette source.');
  classes = classes.slice(0, 60);
  const columns = source === 'models' ? u.migrationColumns(p) : {};
  const names = new Set(classes.map(c => c.name));
  const label = c => (source === 'models' || source === 'prisma' ? H.modelLabel(c.name, false) : H.cap(H.words(c.name).join(' ')));
  const lines = ['@startuml', "' type: class", `title ${source === 'models' || source === 'prisma' ? 'Modèle des données' : 'Organisation du code'} : ${p.name}`];
  for (const c of classes) {
    const kw = c.kind === 'interface' ? 'interface' : c.kind === 'enum' ? 'enum' : c.abstract ? 'abstract class' : 'class';
    const members = [];
    const add = (name, type) => { const t = H.typeName(type); members.push(`  ${H.fieldName(name)}${t ? ' : ' + t : ''}`); };
    if (opts.attributes !== false) {
      const cols = columns[c.table || u.plural(u.snake(c.name))];
      if (cols && cols.length) for (const col of cols) { if (!HIDDEN.has(col.name) && !col.fk && !/_id$/.test(col.name)) add(col.name, c.casts && c.casts[col.name] ? c.casts[col.name].split(':')[0] : col.type); }
      else for (const f of c.fillable || []) if (!HIDDEN.has(f) && !/_id$/.test(f)) add(f, c.casts && c.casts[f]);
      for (const f of c.fields || []) if (!/\{PK\}/.test(f.type) && !/Id$|_id$/.test(f.name)) add(H.words(f.name).join('_'), f.type.replace(/[[\]?]/g, ''));
      if (source !== 'models') for (const pr of (c.props || []).filter(x => !x.injected)) add(H.words(pr.name).join('_'), pr.type);
    }
    const uniq = members.filter((x, i) => members.indexOf(x) === i);
    lines.push(uniq.length ? `${kw} "${label(c)}" as ${c.name} {` : `${kw} "${label(c)}" as ${c.name}`, ...uniq, ...(uniq.length ? ['}'] : []));
  }
  const done = new Set();
  for (const c of classes) {
    if (c.parent && names.has(c.parent)) lines.push(`${c.parent} <|-- ${c.name}`);
    for (const i of c.interfaces || []) if (names.has(i)) lines.push(`${i} <|.. ${c.name}`);
    for (const r of c.relations || []) {
      if (!r.target || !names.has(r.target)) continue;
      // belongsTo : la relation est décrite par le hasMany / hasOne inverse s'il existe
      if (r.kind === 'belongsTo') {
        const key = [c.name, r.target].sort().join('|');
        if (classes.some(o => o.name === r.target && (o.relations || []).some(x => x.target === c.name && /^has/.test(x.kind))) || done.has(key)) continue;
        done.add(key);
        lines.push(`${r.target} "1" --> "*" ${c.name} : possède`);
        continue;
      }
      const key = [c.name, r.target].sort().join('|') + (r.kind === 'belongsToMany' ? '|m2m' : '|' + r.kind);
      if (done.has(key)) continue;
      done.add(key);
      done.add([c.name, r.target].sort().join('|'));
      const [a, b] = u.MULT[r.kind] || ['1', '*'];
      lines.push(`${c.name} "${a}" ${/ToMany|belongsToMany|morphedByMany/.test(r.kind) ? '--' : '-->'} "${b}" ${r.target} : ${REL_VERB[r.kind] || 'est lié à'}`);
    }
    for (const r of c.prismaRels || []) {
      if (!names.has(r.target)) continue;
      const other = classes.find(o => o.name === r.target);
      const back = (other.prismaRels || []).find(x => x.target === c.name);
      if (!r.many && back && back.many) continue;
      const key = [c.name, r.target].sort().join('|') + '|prisma';
      if (r.many && back && back.many) { if (done.has(key)) continue; done.add(key); lines.push(`${c.name} "*" -- "*" ${r.target} : est lié à`); continue; }
      lines.push(r.many ? `${c.name} "1" --> "*" ${r.target} : possède` : `${r.target} "1" --> "*" ${c.name} : possède`);
    }
  }
  lines.push('@enduml', '');
  return lines.join('\n');
}

// Noms de fichiers lisibles : « Séquence - Créer une facture »
const nameFor = {
  sequence: (p, idx) => `Séquence - ${H.routeTitle(u.routes(p)[idx])}`,
  activity: (p, file, fn) => `Activité - ${actionTitle(p, file, fn)}`,
  class: opts => (opts && (opts.source === 'models' || opts.source === 'prisma') ? 'Classes - Modèle des données' : `Classes - ${opts && opts.folder ? opts.folder.replace(/[\\/]/g, ' ') : 'Organisation du code'}`)
};

module.exports = { activityHuman, sequenceHuman, classHuman, actionTitle, nameFor };
