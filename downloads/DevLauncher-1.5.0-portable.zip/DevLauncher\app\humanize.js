// Reformulation en langage courant (français) des noms de code : routes, méthodes, conditions, colonnes.
// Sert aux diagrammes UML « langage courant » : aucun GET/POST, nom de méthode, de contrôleur ou de commande.

// Noms : anglais -> [français, genre ('m' | 'f'), pluriel facultatif]
const NOUNS = {
  user: ['utilisateur', 'm'], users: ['utilisateur', 'm'], account: ['compte', 'm'], invoice: ['facture', 'f'], payment: ['paiement', 'm'],
  transfer: ['virement', 'm'], card: ['carte', 'f'], request: ['demande', 'f'], notification: ['notification', 'f'], message: ['message', 'm'],
  profile: ['profil', 'm'], setting: ['paramètre', 'm'], settings: ['paramètre', 'm'], dashboard: ['tableau de bord', 'm', 'tableaux de bord'],
  report: ['rapport', 'm'], product: ['produit', 'm'], order: ['commande', 'f'], cart: ['panier', 'm'], category: ['catégorie', 'f'],
  post: ['article', 'm'], article: ['article', 'm'], comment: ['commentaire', 'm'], ad: ['annonce', 'f'], reservation: ['réservation', 'f'],
  booking: ['réservation', 'f'], photo: ['photo', 'f'], image: ['image', 'f'], file: ['fichier', 'm'], document: ['document', 'm'],
  client: ['client', 'm'], customer: ['client', 'm'], admin: ['administrateur', 'm'], administrator: ['administrateur', 'm'], role: ['rôle', 'm'],
  permission: ['permission', 'f'], team: ['équipe', 'f'], member: ['membre', 'm'], contact: ['contact', 'm'], subscription: ['abonnement', 'm'],
  subscriber: ['abonné', 'm'], newsletter: ['lettre d\'information', 'f', 'lettres d\'information'], currency: ['devise', 'f'], currencies: ['devise', 'f'],
  loan: ['prêt', 'm'], credit: ['crédit', 'm'], kyc: ['vérification d\'identité', 'f', 'vérifications d\'identité'], field: ['champ', 'm'],
  link: ['lien', 'm'], banking: ['coordonnée bancaire', 'f'], bank: ['banque', 'f'], seller: ['vendeur', 'm'], buyer: ['acheteur', 'm'],
  vehicle: ['véhicule', 'm'], computer: ['ordinateur', 'm'], camera: ['appareil photo', 'm', 'appareils photo'], feature: ['caractéristique', 'f'],
  like: ['mention « j\'aime »', 'f', 'mentions « j\'aime »'], draft: ['brouillon', 'm'], page: ['page', 'f'], home: ['page d\'accueil', 'f', 'pages d\'accueil'],
  login: ['connexion', 'f'], logout: ['déconnexion', 'f'], signup: ['inscription', 'f'], register: ['inscription', 'f'], registration: ['inscription', 'f'],
  password: ['mot de passe', 'm', 'mots de passe'], email: ['e-mail', 'm'], mail: ['e-mail', 'm'], otp: ['code de vérification', 'm', 'codes de vérification'],
  code: ['code', 'm'], token: ['jeton', 'm'], verification: ['vérification', 'f'], activation: ['activation', 'f'], invitation: ['invitation', 'f'],
  company: ['entreprise', 'f'], organization: ['organisation', 'f'], project: ['projet', 'm'], task: ['tâche', 'f'], event: ['événement', 'm'],
  ticket: ['ticket', 'm'], support: ['assistance', 'f'], chat: ['discussion', 'f'], conversation: ['conversation', 'f'], group: ['groupe', 'm'],
  plan: ['formule', 'f'], price: ['prix', 'm', 'prix'], tax: ['taxe', 'f'], discount: ['remise', 'f'], coupon: ['coupon', 'm'], address: ['adresse', 'f'],
  city: ['ville', 'f'], country: ['pays', 'm', 'pays'], phone: ['téléphone', 'm'], status: ['statut', 'm'], history: ['historique', 'm'],
  log: ['journal', 'm', 'journaux'], activity: ['activité', 'f'], statistic: ['statistique', 'f'], stats: ['statistique', 'f'], analytics: ['statistique', 'f'],
  balance: ['solde', 'm'], wallet: ['portefeuille', 'm'], transaction: ['transaction', 'f'], movement: ['mouvement', 'm'], deposit: ['dépôt', 'm'],
  withdrawal: ['retrait', 'm'], contract: ['contrat', 'm'], template: ['modèle', 'm'], agency: ['agence', 'f'], branch: ['agence', 'f'],
  service: ['service', 'm'], department: ['service', 'm'], employee: ['employé', 'm'], student: ['élève', 'm'], course: ['cours', 'm', 'cours'],
  lesson: ['leçon', 'f'], exam: ['examen', 'm'], book: ['livre', 'm'], author: ['auteur', 'm'], review: ['avis', 'm', 'avis'], rating: ['note', 'f'],
  question: ['question', 'f'], answer: ['réponse', 'f'], survey: ['sondage', 'm'], menu: ['menu', 'm'], delivery: ['livraison', 'f'],
  shipment: ['expédition', 'f'], stock: ['stock', 'm'], inventory: ['inventaire', 'm'], supplier: ['fournisseur', 'm'], brand: ['marque', 'f'],
  tag: ['étiquette', 'f'], slider: ['diaporama', 'm'], banner: ['bannière', 'f'], faq: ['foire aux questions', 'f', 'foires aux questions'],
  testimonial: ['témoignage', 'm'], partner: ['partenaire', 'm'], gallery: ['galerie', 'f'], video: ['vidéo', 'f'], note: ['note', 'f'],
  reminder: ['rappel', 'm'], schedule: ['planning', 'm'], appointment: ['rendez-vous', 'm', 'rendez-vous'], calendar: ['calendrier', 'm'],
  locale: ['langue', 'f'], language: ['langue', 'f'], translation: ['traduction', 'f'], upload: ['envoi', 'm'], download: ['téléchargement', 'm'],
  export: ['export', 'm'], import: ['import', 'm'], pdf: ['PDF', 'm', 'PDF'], csv: ['fichier CSV', 'm', 'fichiers CSV'], data: ['donnée', 'f'],
  detail: ['détail', 'm'], list: ['liste', 'f'], item: ['élément', 'm'], config: ['configuration', 'f'], configuration: ['configuration', 'f'],
  option: ['option', 'f'], preference: ['préférence', 'f'], association: ['association', 'f'], donation: ['don', 'm'], meeting: ['réunion', 'f'],
  site: ['site', 'm'], form: ['formulaire', 'm'], session: ['session', 'f'], name: ['nom', 'm'], title: ['titre', 'm'], description: ['description', 'f'],
  amount: ['montant', 'm'], total: ['total', 'm', 'totaux'], quantity: ['quantité', 'f'], date: ['date', 'f'], number: ['numéro', 'm'],
  reference: ['référence', 'f'], type: ['type', 'm'], level: ['niveau', 'm', 'niveaux'], avatar: ['photo de profil', 'f', 'photos de profil'],
  attachment: ['pièce jointe', 'f', 'pièces jointes'], social: ['réseau social', 'm', 'réseaux sociaux'], notice: ['avis', 'm', 'avis'],
  unblock: ['déblocage', 'm'], block: ['blocage', 'm'], virement: ['virement', 'm'], declaration: ['déclaration', 'f'], guarantee: ['garantie', 'f'],
  receipt: ['reçu', 'm'], statement: ['relevé', 'm'], beneficiary: ['bénéficiaire', 'm'], operation: ['opération', 'f'], fee: ['frais', 'm', 'frais'],
  limit: ['plafond', 'm'], rate: ['taux', 'm', 'taux'], interest: ['intérêt', 'm'], installment: ['échéance', 'f'], due: ['échéance', 'f'],
  verify: ['vérification', 'f'], reset: ['réinitialisation', 'f'], validation: ['validation', 'f'], access: ['accès', 'm', 'accès'],
  iban: ['IBAN', 'm', 'IBAN'], bic: ['BIC', 'm', 'BIC'], attempt: ['tentative', 'f'], tries: ['tentative', 'f'], try: ['tentative', 'f'], kind: ['nature', 'f'], icon: ['icône', 'f'], counterparty: ['contrepartie', 'f'],
  read: ['lecture', 'f'], holder: ['titulaire', 'm'], expiry: ['expiration', 'f'], expiration: ['expiration', 'f'], fees: ['frais', 'm', 'frais'],
  reason: ['motif', 'm'], label: ['libellé', 'm'], value: ['valeur', 'f'], key: ['clé', 'f'], content: ['contenu', 'm'], url: ['lien', 'm'], forgot: ['mot de passe oublié', 'm', 'mots de passe oubliés'], welcome: ['bienvenue', 'f'],
  network: ['réseau', 'm', 'réseaux'], spending: ['dépenses', 'f', 'dépenses'], unlock: ['déblocage', 'm'], application: ['demande', 'f'],
  push: ['notification push', 'f', 'notifications push'], cap: ['plafond', 'm'], symbol: ['symbole', 'm'], exchange: ['change', 'm'],
  subtotal: ['sous-total', 'm', 'sous-totaux'], issue: ['émission', 'f'],
  zip: ['code postal', 'm', 'codes postaux'],
  atelier: ['atelier', 'm'], maison: ['maison', 'f'], projet: ['projet', 'm'], annonce: ['annonce', 'f'], facture: ['facture', 'f'], compte: ['compte', 'm']
};

const ADJ = {
  verified: 'vérifié', active: 'actif', default: 'par défaut', main: 'principal', new: 'nouveau', pending: 'en attente', paid: 'payé',
  current: 'actuel', public: 'public', private: 'privé', full: 'complet', first: 'premier', last: 'dernier', bank: 'bancaire', social: 'social',
  online: 'en ligne', unread: 'non lu', read: 'lu', blocked: 'bloqué', approved: 'approuvé', rejected: 'rejeté', expired: 'expiré', recent: 'récent',
  monthly: 'mensuel', annual: 'annuel', daily: 'quotidien', global: 'global', personal: 'personnel', admin: 'd\'administration'
};

const VERBS = {
  send: 'Envoyer', show: 'Afficher', view: 'Afficher', display: 'Afficher', get: 'Récupérer', fetch: 'Récupérer', list: 'Consulter', create: 'Créer',
  store: 'Enregistrer', add: 'Ajouter', edit: 'Modifier', update: 'Mettre à jour', save: 'Enregistrer', delete: 'Supprimer', destroy: 'Supprimer',
  remove: 'Retirer', approve: 'Approuver', validate: 'Valider', reject: 'Rejeter', refuse: 'Refuser', cancel: 'Annuler', confirm: 'Confirmer',
  verify: 'Vérifier', check: 'Vérifier', activate: 'Activer', deactivate: 'Désactiver', enable: 'Activer', disable: 'Désactiver', block: 'Bloquer',
  unblock: 'Débloquer', reset: 'Réinitialiser', download: 'Télécharger', upload: 'Envoyer', export: 'Exporter', import: 'Importer', generate: 'Générer',
  print: 'Imprimer', pay: 'Payer', mark: 'Marquer', search: 'Rechercher', filter: 'Filtrer', sort: 'Trier', assign: 'Attribuer', attach: 'Associer',
  detach: 'Dissocier', invite: 'Inviter', accept: 'Accepter', decline: 'Refuser', resend: 'Renvoyer', notify: 'Notifier', publish: 'Publier',
  unpublish: 'Retirer de la publication', archive: 'Archiver', restore: 'Restaurer', duplicate: 'Dupliquer', toggle: 'Activer ou désactiver',
  follow: 'Suivre', reply: 'Répondre à', rate: 'Noter', book: 'Réserver', reserve: 'Réserver', reserver: 'Réserver', checkout: 'Valider',
  track: 'Suivre', close: 'Fermer', open: 'Ouvrir', start: 'Démarrer', stop: 'Arrêter', process: 'Traiter', handle: 'Traiter', calculate: 'Calculer',
  compute: 'Calculer', sync: 'Synchroniser', refresh: 'Actualiser', preview: 'Prévisualiser', declare: 'Déclarer', submit: 'Soumettre',
  transfer: 'Transférer', withdraw: 'Retirer', credit: 'Créditer', debit: 'Débiter', convert: 'Convertir', change: 'Changer', set: 'Définir',
  reorder: 'Réordonner', count: 'Compter', load: 'Charger', subscribe: 'S\'abonner à', unsubscribe: 'Se désabonner de', login: 'Se connecter',
  logout: 'Se déconnecter', signin: 'Se connecter', signup: 'S\'inscrire', register: 'S\'inscrire', apply: 'Appliquer', complete: 'Terminer',
  finalize: 'Finaliser', request: 'Demander', contact: 'Contacter', like: 'Aimer', unlike: 'Ne plus aimer', share: 'Partager', report: 'Signaler',
  answer: 'Répondre à', comment: 'Commenter', select: 'Choisir', choose: 'Choisir', upgrade: 'Mettre à niveau', renew: 'Renouveler', clear: 'Vider',
  receive: 'Recevoir', make: 'Préparer', forget: 'Récupérer', forgot: 'Récupérer', recover: 'Récupérer', build: 'Construire', render: 'Afficher', parse: 'Analyser', format: 'Mettre en forme', resolve: 'Résoudre',
  assigner: 'Attribuer', valider: 'Valider', envoyer: 'Envoyer', creer: 'Créer', supprimer: 'Supprimer', modifier: 'Modifier', afficher: 'Afficher'
};

const STOP = new Set(['the', 'a', 'an', 'of', 'to', 'for', 'by', 'and', 'or', 'with', 'in', 'on', 'at', 'from', 'controller', 'action', 'method', 'handler', 'attribute', 'scope', 'api', 'v1', 'v2', 'index', 'is', 'has', 'can', 'do', 'all', 'form', 'page']);

const VOWEL = /^[aàâeéèêëiîïoôuùûyh]/i;
const cap = s => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);

// « SellerBankAccount », « seller_bank_account », « seller-bank » -> ['seller', 'bank', 'account']
// keepSuffix : un modèle « CardRequest » est une demande de carte, pas une classe de validation.
function words(id, keepSuffix = false) {
  return String(id || '').replace(keepSuffix ? /^$/ : /Controller$|Request$|Service$|Repository$/, '').replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .split(/[^A-Za-z0-9À-ÿ]+/).filter(Boolean).map(w => w.toLowerCase());
}

const singular = w => (NOUNS[w] ? w : w.endsWith('ies') && NOUNS[w.slice(0, -3) + 'y'] ? w.slice(0, -3) + 'y' : w.endsWith('es') && NOUNS[w.slice(0, -2)] ? w.slice(0, -2) : w.endsWith('s') && NOUNS[w.slice(0, -1)] ? w.slice(0, -1) : w);
const isPlural = w => !NOUNS[w] || NOUNS[w][0] === NOUNS[singular(w)][0] ? w !== singular(w) : false;

// Forme française d'un nom : { text, gender, plural, known }
function noun(w, plural = false) {
  const s = singular(w);
  const e = NOUNS[s];
  if (!e) return { text: w, gender: 'm', plural, known: false };
  const pl = e[2] || (/[sxz]$/.test(e[0]) ? e[0] : e[0].includes(' ') ? e[0].replace(/^(\S+)/, '$1s') : e[0] + 's');
  return { text: plural ? pl : e[0], gender: e[1], plural, known: true };
}

// Groupe nominal : la tête est le dernier mot anglais, les autres la complètent (« bank account » -> « compte bancaire »).
function nounPhrase(ws, { plural } = {}) {
  ws = ws.filter(w => !STOP.has(w));
  if (!ws.length) return null;
  const headW = ws[ws.length - 1];
  const pl = plural !== undefined ? plural : headW !== singular(headW);
  const head = noun(headW, pl);
  let text = head.text;
  const mods = ws.slice(0, -1).reverse();
  let known = head.known;
  for (const m of mods) {
    if (ADJ[m] && !(NOUNS[m] && m !== 'bank' && m !== 'social' && m !== 'admin')) { text += ' ' + agree(ADJ[m], head.gender, pl); continue; }
    const n = noun(m, false);
    known = known && n.known;
    text += (VOWEL.test(n.text) ? ' d\'' : ' de ') + n.text;
  }
  return { text, gender: head.gender, plural: pl, known };
}

function agree(adj, g, pl) {
  if (/^(par |en |non |d')/.test(adj) || adj === 'public' && g === 'm') return adj;
  let a = adj;
  if (g === 'f') a = a === 'nouveau' ? 'nouvelle' : a === 'premier' ? 'première' : a === 'dernier' ? 'dernière' : a === 'public' ? 'publique' : a === 'actif' ? 'active' : /[^e]$/.test(a) ? a + 'e' : a;
  if (pl && !/[sx]$/.test(a)) a = a.endsWith('al') && g === 'm' ? a.slice(0, -2) + 'aux' : a === 'nouveau' ? 'nouveaux' : a + 's';
  return a;
}

// Avec article : défini (le, la, l', les) ou indéfini (un, une, des)
function art(np, kind = 'def') {
  if (!np) return '';
  if (np.plural) return (kind === 'def' ? 'les ' : 'des ') + np.text;
  if (kind === 'def') return (VOWEL.test(np.text) ? 'l\'' : np.gender === 'f' ? 'la ' : 'le ') + np.text;
  return (np.gender === 'f' ? 'une ' : 'un ') + np.text;
}
const aArt = np => { const a = art(np); return /^le /.test(a) ? 'au ' + a.slice(3) : /^les /.test(a) ? 'aux ' + a.slice(4) : 'à ' + a; };
const deArt = (np, kind = 'def') => { const a = art(np, kind); return /^le /.test(a) ? 'du ' + a.slice(3) : /^les /.test(a) ? 'des ' + a.slice(4) : /^des /.test(a) ? 'de ' + a.slice(4) : 'de ' + a; };

// Phrase à partir d'un nom de méthode ou de fonction : « sendActivationMail » -> « Envoyer l'e-mail d'activation »
function phrase(name, resourceWords = []) {
  const ws = words(name).filter(w => !['get', 'set'].includes(w) || words(name).length === 1);
  if (!ws.length) return null;
  const vi = ws.findIndex(w => VERBS[w]);
  if (vi >= 0) {
    const verb = VERBS[ws[vi]];
    let rest = [...ws.slice(0, vi), ...ws.slice(vi + 1)];
    if (!rest.length && resourceWords.length) rest = resourceWords;
    const np = nounPhrase(rest);
    const base = verb.replace(/ (à|de)$/, '');
    if (!np) return base;
    // Verbe suivi de « à » ou « de » : contraction (au, aux, du, des)
    if (/ à$/.test(verb)) return np.known ? `${base} ${aArt(np)}` : base;
    if (/ de$/.test(verb)) return np.known ? `${base} ${deArt(np)}` : base;
    if (/^(Se |S')/.test(verb)) return verb; // « Se connecter », « S'inscrire » : sans complément
    return np.known ? `${verb} ${art(np)}` : `${verb} : ${np.text}`;
  }
  const np = nounPhrase(ws);
  return np ? cap(np.text) : null;
}

// Ressource d'une route : nom du contrôleur (InvoiceController -> invoice) ou dernier segment fixe de l'adresse.
function resourceOf(route) {
  // Mots génériques des noms de contrôleurs : « TransferValidationController » -> virement
  const fromCtrl = words(String(route.controller || '').split('\\').pop()).filter(w => !['validation', 'management', 'manager', 'handler', 'crud', 'resource'].includes(w));
  if (fromCtrl.length && !fromCtrl.every(w => STOP.has(w) || ['app', 'main', 'page', 'home', 'site', 'base'].includes(w))) return fromCtrl;
  const segs = String(route.uri || '').split('/').filter(s => s && !s.startsWith('{') && s !== 'api' && s !== 'admin');
  return segs.length ? words(segs[segs.length - 1]) : [];
}

// Intitulé en langage courant d'une route (action de l'utilisateur).
function routeTitle(route) {
  const m = route.method || '';
  const res = resourceOf(route);
  const r0 = res.join(' ');
  const admin = /^\/?(api\/)?admin\b/.test(String(route.uri || '').replace(/^\//, '')) ? ' (administration)' : '';
  const np = nounPhrase(res, { plural: false });
  const npPl = nounPhrase(res, { plural: true });
  // Cas courants : authentification, inscription, mot de passe, tableau de bord
  if (res.some(w => /^(login|signin|auth|session)$/.test(w)) || /login/i.test(m)) {
    if (/forget|forgot|recover/i.test(m)) return 'Récupérer l\'accès au compte' + admin;
    if (/^(create|show|showLoginForm|loginForm|index)$/.test(m) || /form/i.test(m)) return 'Afficher le formulaire de connexion' + admin;
    if (/^(destroy|logout)$/.test(m) || /logout/i.test(m)) return 'Se déconnecter' + admin;
    return 'Se connecter' + admin;
  }
  if (/logout/i.test(m) || r0 === 'logout') return 'Se déconnecter' + admin;
  if (/^(signup|register|registration|registered user)$/.test(r0)) return (/^(create|show|index)$/.test(m) || /form/i.test(m) ? 'Afficher le formulaire d\'inscription' : 'S\'inscrire') + admin;
  if (/password/.test(r0) || /password/i.test(m)) return (/^(create|show|index)$/.test(m) || /form|request/i.test(m) ? 'Afficher le formulaire de mot de passe' : /reset|update|store/i.test(m) ? 'Réinitialiser le mot de passe' : 'Gérer le mot de passe') + admin;
  if (/^(dashboard|home)$/.test(r0) && /^(index|show|__invoke)$/.test(m)) return (r0 === 'home' ? 'Afficher la page d\'accueil' : 'Afficher le tableau de bord') + admin;
  const mw = words(m);
  if (mw.some(w => /^(pdf|print|download|export|csv|excel)$/.test(w)) && np && np.known) {
    const what = mw.includes('csv') || mw.includes('excel') ? 'Exporter' : mw.includes('print') ? 'Imprimer' : 'Télécharger';
    return `${what} ${art(mw.includes('export') && /index|all/.test(m) ? npPl : np)}${mw.includes('pdf') ? ' en PDF' : mw.includes('csv') ? ' en CSV' : mw.includes('excel') ? ' en Excel' : ''}` + admin;
  }
  if (mw.includes('subscribe') && (mw.includes('mail') || mw.includes('newsletter') || r0 === 'contact')) return 'S\'abonner à la lettre d\'information' + admin;
  const crud = {
    index: () => npPl ? `Consulter la liste ${deArt(npPl)}` : 'Consulter la liste',
    show: () => np ? `Consulter le détail ${deArt({ ...np, plural: false }, 'indef').replace(/^de un /, 'd\'un ').replace(/^de une /, 'd\'une ')}` : 'Consulter le détail',
    create: () => np ? `Ouvrir le formulaire de création ${deArt({ ...np, plural: false }, 'indef').replace(/^de un /, 'd\'un ').replace(/^de une /, 'd\'une ')}` : 'Ouvrir le formulaire de création',
    store: () => np ? `Créer ${art({ ...np, plural: false }, 'indef')}` : 'Enregistrer',
    edit: () => np ? `Ouvrir le formulaire de modification ${deArt({ ...np, plural: false }, 'indef').replace(/^de un /, 'd\'un ').replace(/^de une /, 'd\'une ')}` : 'Ouvrir le formulaire de modification',
    update: () => np ? `Modifier ${art({ ...np, plural: false }, 'indef')}` : 'Modifier',
    destroy: () => np ? `Supprimer ${art({ ...np, plural: false }, 'indef')}` : 'Supprimer',
    __invoke: () => np ? (np.known ? `Afficher ${art(np)}` : `Afficher : ${np.text}`) : 'Afficher la page'
  };
  if (crud[m] && np && np.known) return crud[m]() + admin;
  if (crud[m] && !np) return crud[m]() + admin;
  // Méthode avec un verbe (« sendActivationMail ») : phrase directe ; la ressource complète un verbe seul.
  if (mw.some(w => VERBS[w])) return (phrase(m, res) || 'Action') + admin;
  // Méthode qui n'est qu'un nom (« invoice », « history ») : le verbe vient de l'action HTTP.
  const what = nounPhrase(mw);
  const verb = { GET: 'Consulter', HEAD: 'Consulter', POST: 'Enregistrer', PUT: 'Modifier', PATCH: 'Modifier', DELETE: 'Supprimer' }[String(route.verb || 'GET').toUpperCase()] || 'Consulter';
  // Même chose désignée par la méthode et la ressource (« accounts » sur /accounts) : pas de répétition
  const same = np && singular(mw[mw.length - 1] || '') === singular(res[res.length - 1] || '');
  if (what && what.known) return `${verb} ${art(what)}${np && np.known && !same ? ' ' + deArt(np) : ''}` + admin;
  if (np && np.known) return `${verb} ${art(np)}${mw.length ? ` (${mw.join(' ')})` : ''}` + admin;
  return (what ? `${verb} : ${what.text}` : 'Action') + admin;
}

// Libellé d'un modèle : « Invoice » -> « facture » (nom commun, pour les phrases)
function modelNp(model, plural = false) {
  const np = nounPhrase(words(model, true), { plural });
  return np || { text: model, gender: 'm', plural, known: false };
}
function modelLabel(model, plural = true) {
  const np = modelNp(model, plural);
  if (model === 'User') return plural ? 'Comptes utilisateurs' : 'Compte utilisateur';
  return cap(np.text);
}

// Appel d'un modèle Eloquent : (« Invoice », « create ») -> « Enregistrer la nouvelle facture »
function modelCall(model, method) {
  const one = model === 'User' ? { text: 'compte utilisateur', gender: 'm', plural: false, known: true } : modelNp(model, false);
  const many = model === 'User' ? { text: 'comptes utilisateurs', gender: 'm', plural: true, known: true } : modelNp(model, true);
  const a1 = art(one), aN = art(many);
  const R = [
    [/^(create|insert|forceCreate)$/, () => `Enregistrer ${one.gender === 'f' ? 'la nouvelle' : VOWEL.test(one.text) ? 'le nouvel' : 'le nouveau'} ${one.text}`],
    [/^(firstOrCreate|updateOrCreate|upsert)$/, () => `Créer ou mettre à jour ${a1}`],
    [/^(find|findOrFail|first|firstOrFail|firstWhere|sole)$/, () => `Rechercher ${a1}`],
    [/^(where|query|with|latest|oldest|orderBy|all|get|paginate|simplePaginate|whereIn|whereHas|select|search|filter|take|limit)$/, () => `Récupérer ${aN}`],
    [/^(count|sum|avg|max|min)$/, () => `Calculer le total ${deArt(many)}`],
    [/^(exists|doesntExist)$/, () => `Vérifier si ${a1} existe`],
    [/^(update|increment|decrement|fill|forceFill|touch)$/, () => `Mettre à jour ${a1}`],
    [/^(save|push)$/, () => `Enregistrer les modifications ${deArt(one)}`],
    [/^(delete|destroy|forceDelete)$/, () => `Supprimer ${a1}`],
    [/^(restore)$/, () => `Restaurer ${a1}`],
    [/^(attach|sync|syncWithoutDetaching|associate)$/, () => `Associer ${a1}`],
    [/^(detach|dissociate)$/, () => `Dissocier ${a1}`],
    [/^(load|loadMissing|refresh|fresh)$/, () => `Recharger les informations ${deArt(one)}`],
    [/^(pluck|value|toArray)$/, () => `Récupérer les informations ${deArt(many)}`]
  ];
  for (const [re, f] of R) if (re.test(method)) return f();
  // Méthode du modèle sans verbe (« Currency::codes ») : « Récupérer les codes des devises »
  const mw = words(method);
  if (!mw.some(w => VERBS[w])) { const np = nounPhrase(mw); if (np && np.known) return `Récupérer ${art(np)} ${deArt(many)}`; }
  return phrase(method, words(model)) || `Traiter ${a1}`;
}
const modelResult = (model, method) => {
  const one = model === 'User' ? { text: 'compte utilisateur', gender: 'm', plural: false, known: true } : modelNp(model, false);
  const many = model === 'User' ? { text: 'comptes utilisateurs', gender: 'm', plural: true, known: true } : modelNp(model, true);
  if (/^(create|insert|firstOrCreate|updateOrCreate)$/.test(method)) return `${cap(one.text)} ${one.gender === 'f' ? 'enregistrée' : 'enregistré'}`;
  if (/^(find|findOrFail|first|firstOrFail|firstWhere|sole)$/.test(method)) return `${cap(one.text)} ${one.gender === 'f' ? 'trouvée' : 'trouvé'}`;
  if (/^(count|sum|avg|max|min)$/.test(method)) return 'Total calculé';
  if (/^(exists|doesntExist)$/.test(method)) return 'Réponse oui / non';
  if (/^(where|query|with|latest|oldest|orderBy|all|get|paginate|simplePaginate|whereIn|whereHas|select|search|filter|pluck|take|limit)$/.test(method)) return cap(many.text);
  return null;
};

// Façades et services courants de Laravel
const FACADES = {
  Auth: { label: 'Authentification', call: m => (/attempt/.test(m) ? 'Vérifier les identifiants' : /login|loginUsingId/.test(m) ? 'Ouvrir la session de l\'utilisateur' : /logout/.test(m) ? 'Fermer la session' : /user|id|check|guest/.test(m) ? 'Identifier l\'utilisateur connecté' : 'Contrôler l\'accès') },
  Hash: { label: 'Sécurité', call: m => (/check/.test(m) ? 'Vérifier le mot de passe' : 'Chiffrer le mot de passe') },
  Mail: { label: 'Messagerie', call: () => 'Envoyer un e-mail' },
  Notification: { label: 'Notifications', call: () => 'Envoyer une notification' },
  DB: { label: 'Base de données', call: m => (/transaction|beginTransaction/.test(m) ? 'Démarrer une transaction' : /commit/.test(m) ? 'Valider la transaction' : /rollBack/.test(m) ? 'Annuler la transaction' : 'Interroger la base de données') },
  Storage: { label: 'Stockage des fichiers', call: m => (/delete/.test(m) ? 'Supprimer le fichier' : /url|temporaryUrl/.test(m) ? 'Obtenir le lien du fichier' : /exists/.test(m) ? 'Vérifier si le fichier existe' : /download|get/.test(m) ? 'Lire le fichier' : 'Enregistrer le fichier') },
  Cache: { label: 'Cache', call: m => (/forget|flush/.test(m) ? 'Vider le cache' : /put|remember|forever/.test(m) ? 'Mémoriser en cache' : 'Consulter le cache') },
  Http: { label: 'Service externe', call: () => 'Appeler un service externe' },
  Event: { label: 'Traitements automatiques', call: () => 'Déclencher un traitement automatique' },
  Session: { label: 'Session', call: m => (/forget|flush/.test(m) ? 'Effacer la session' : 'Mémoriser en session') },
  Gate: { label: 'Droits d\'accès', call: () => 'Vérifier les droits d\'accès' },
  Validator: { label: 'Validation', call: () => 'Vérifier les informations saisies' },
  Queue: { label: 'File d\'attente', call: () => 'Mettre en file d\'attente' },
  Bus: { label: 'File d\'attente', call: () => 'Mettre en file d\'attente' },
  Log: null, Str: null, Arr: null, Carbon: null, Config: null, URL: null, Route: null, Response: null, Redirect: null, View: null, Inertia: null, App: null, Lang: null
};

// Nom de service injecté : « InvoiceService » -> « Service des factures »
function serviceLabel(type) {
  const ws = words(type);
  const np = nounPhrase(ws, { plural: true });
  return np && np.known ? `Service ${deArt(np)}` : `Service : ${ws.join(' ')}`;
}

// Réponse finale : vue, redirection, JSON, téléchargement...
function responsePhrase(text) {
  let m;
  if ((m = text.match(/view\(\s*['"]([^'"]+)['"]/)) || (m = text.match(/Inertia::render\(\s*['"]([^'"]+)['"]/))) return `Afficher ${pageName(m[1])}`;
  if (/->back\(\)|back\(\)/.test(text)) return 'Revenir à la page précédente';
  if ((m = text.match(/(?:to_route|route)\(\s*['"]([^'"]+)['"]/))) return `Rediriger vers ${pageName(m[1].replace(/\./g, '/'))}`;
  if (/redirect\(/.test(text)) return 'Rediriger vers la page suivante';
  if (/->json\(|Response::json|NextResponse\.json|res\.json/.test(text)) return 'Renvoyer les informations demandées';
  if (/->download\(|->streamDownload|Storage::download/.test(text)) return 'Télécharger le fichier';
  if (/->stream\(|->inline\(|pdf/i.test(text)) return 'Afficher le document';
  if (/abort\(\s*40[13]/.test(text)) return 'Refuser l\'accès';
  if (/abort\(\s*404/.test(text)) return 'Indiquer que la page est introuvable';
  if (/^throw\b/.test(text)) return 'Signaler une erreur';
  if (/^return\s+</.test(text)) return 'Afficher la page';
  return 'Renvoyer la réponse';
}

// « invoices.index » -> « la liste des factures », « admin/users/edit » -> « la page de modification d'un compte utilisateur »
function pageName(view) {
  const segs = String(view).split(/[./]/).filter(s => s && !['pages', 'admin', 'livewire', 'components', 'app', 'auth', 'frontend', 'backend', 'site'].includes(s));
  const last = segs[segs.length - 1] || '';
  const res = segs.length > 1 ? words(segs[segs.length - 2]) : [];
  const np = res.length ? nounPhrase(res) : null;
  const one = np ? nounPhrase(res, { plural: false }) : null;
  const known = np && np.known;
  if (/^(index|list|all)$/.test(last) && known) return `la liste ${deArt(nounPhrase(res, { plural: true }))}`;
  if (/^(show|detail|view)$/.test(last) && known) return `le détail ${deArt(one, 'indef').replace(/^de un /, 'd\'un ').replace(/^de une /, 'd\'une ')}`;
  if (/^(create|new|add)$/.test(last) && known) return `le formulaire de création ${deArt(one, 'indef').replace(/^de un /, 'd\'un ').replace(/^de une /, 'd\'une ')}`;
  if (/^(edit|update)$/.test(last) && known) return `le formulaire de modification ${deArt(one, 'indef').replace(/^de un /, 'd\'un ').replace(/^de une /, 'd\'une ')}`;
  if (/^(login)$/.test(last)) return 'la page de connexion';
  if (/^(register|signup)$/.test(last)) return 'la page d\'inscription';
  if (/^(dashboard)$/.test(last)) return 'le tableau de bord';
  if (/^(home|welcome|index)$/.test(last)) return 'la page d\'accueil';
  const lp = nounPhrase(words(last));
  return lp && lp.known ? `la page « ${lp.text} »` : `la page « ${words(last).join(' ')} »`;
}

// Condition en langage courant : « user->fresh()->email_verified_at » -> « e-mail vérifié »
function condition(cond) {
  let c = String(cond || '').replace(/\$this->/g, '').replace(/\$/g, '').trim();
  const neg = /^!\s*/.test(c) && !/^!\s*\(/.test(c);
  c = c.replace(/^!\s*/, '');
  const parts = c.split(/\s*(&&|\|\||\band\b|\bor\b)\s*/);
  if (parts.length > 2) {
    const out = [];
    for (let i = 0; i < parts.length; i += 2) out.push(condition(parts[i]));
    return out.join(parts[1] === '&&' || parts[1] === 'and' ? ' et ' : ' ou ').slice(0, 90);
  }
  let m;
  const r = (s) => (neg ? negate(s) : s);
  if (/auth\(\)->check\(\)|Auth::check\(\)/.test(c)) return r('utilisateur connecté');
  if (/auth\(\)->guest\(\)|Auth::guest\(\)/.test(c)) return r('visiteur non connecté');
  if ((m = c.match(/->is(Admin|SuperAdmin|Activated|Active|Verified|Blocked|Paid|Pending)\(\)/))) return r({ Admin: 'administrateur', SuperAdmin: 'super administrateur', Activated: 'compte activé', Active: 'actif', Verified: 'vérifié', Blocked: 'bloqué', Paid: 'payé', Pending: 'en attente' }[m[1]]);
  if ((m = c.match(/->hasRole\(\s*['"]([^'"]+)['"]/))) return r(`rôle « ${m[1]} »`);
  if ((m = c.match(/->(?:can|cannot)\(\s*['"]([^'"]+)['"]/))) return r(`droit « ${m[1]} » accordé`);
  if ((m = c.match(/->(?:has|filled)\(\s*['"]([^'"]+)['"]/))) return r(`« ${fieldName(m[1])} » renseigné`);
  if ((m = c.match(/->hasFile\(\s*['"]([^'"]+)['"]/))) return r(`fichier « ${fieldName(m[1])} » envoyé`);
  if ((m = c.match(/^(?:is_null|empty)\((.*)\)$/))) return r(`${subject(m[1])} introuvable`);
  if ((m = c.match(/^isset\((.*)\)$/))) return r(`${subject(m[1])} renseigné`);
  if ((m = c.match(/^count\((.*)\)\s*(>|>=|===?|<)\s*0$/)) || (m = c.match(/^(.*)->(?:count|isNotEmpty)\(\)\s*(>|>=)?\s*0?$/))) return r(`${subject(m[1])} présents`);
  if ((m = c.match(/^(.*)->isEmpty\(\)$/))) return r(`${subject(m[1])} absents`);
  if ((m = c.match(/^in_array\(\s*([^,]+),/))) return r(`${subject(m[1])} autorisé`);
  // Comparaison (le « > » de « -> » ou « => » n'en est pas une)
  if ((m = c.match(/^(.+?)\s*(===|==|!==|!=|>=|<=|(?<![-=])>|<(?!=))\s*(.+)$/))) {
    const left = subject(m[1]);
    const raw = m[3].trim();
    const op = { '===': 'égal à', '==': 'égal à', '!==': 'différent de', '!=': 'différent de', '>=': 'au moins', '<=': 'au plus', '>': 'supérieur à', '<': 'inférieur à' }[m[2]];
    // Constante (Card::STATUS_BLOCKED, self::MAX_ATTEMPTS) : sa signification ; expression : son sujet
    if (/::/.test(raw) && !/['"]/.test(raw)) {
      const cst = constantName(raw.split('::').pop());
      return r(/égal|différent/.test(op) ? `${left} ${/égal/.test(op) ? 'est' : 'n\'est pas'} « ${cst} »` : `${left} ${op} ${cst}`);
    }
    if (/->|\(|\$/.test(raw)) return r(`${left} ${op} ${subject(raw)}`.replace(/ de ([aeéèêiîoôuh])/i, ' d\'$1'));
    const val = raw.replace(/^['"]|['"]$/g, '').trim();
    const v = /^(null|false)$/i.test(val) ? null : /^true$/i.test(val) ? 'oui' : ADJ[val] || val;
    if (v === null) return r(/^(===|==)$/.test(m[2]) ? `${left} introuvable` : `${left} renseigné`);
    return r(/^\d/.test(v) ? `${left} ${op} ${v}` : `${left} ${/égal/.test(op) ? 'est' : 'n\'est pas'} « ${v} »`).replace(/ est « oui »$/, '');
  }
  // Appel ou propriété : les mots du dernier élément
  return r(subject(c) || 'condition remplie');
}
// « STATUS_BLOCKED » -> « bloqué », « RESET_LINK_SENT » -> « lien de réinitialisation envoyé », « MAX_ATTEMPTS » -> « nombre maximal de tentatives »
function constantName(c) {
  const ws = String(c).toLowerCase().split('_').filter(w => w && !['status', 'state', 'type', 'kind'].includes(w));
  if (!ws.length) return String(c).toLowerCase();
  if (ws[0] === 'max' || ws[0] === 'min') { const np = nounPhrase(ws.slice(1), { plural: true }); return `${ws[0] === 'max' ? 'maximum' : 'minimum'} ${np && np.known ? deArt(np) : 'de ' + ws.slice(1).join(' ')}`; }
  const PART = { sent: 'envoyé', reset: 'réinitialisé', blocked: 'bloqué', active: 'actif', pending: 'en attente', paid: 'payé', approved: 'approuvé', rejected: 'rejeté', cancelled: 'annulé', canceled: 'annulé', completed: 'terminé', failed: 'échoué', draft: 'brouillon', open: 'ouvert', closed: 'fermé', expired: 'expiré', verified: 'vérifié', suspended: 'suspendu', required: 'requis', done: 'terminé' };
  const last = ws[ws.length - 1];
  if (PART[last] && ws.length === 1) return PART[last];
  if (PART[last]) { const np = nounPhrase(ws.slice(0, -1)); return `${np && np.known ? np.text : ws.slice(0, -1).join(' ')} ${PART[last]}`; }
  const np = nounPhrase(ws);
  return np && np.known ? np.text : ws.join(' ');
}

function negate(s) {
  if (/^non /.test(s)) return s.slice(4);
  if (/^aucun /.test(s)) return s.replace(/^aucun /, '') + ' présents';
  if (/ introuvable$/.test(s)) return s.replace(/ introuvable$/, ' trouvé');
  if (/ présents$/.test(s)) return s.replace(/ présents$/, ' absents');
  // « langue autorisée » -> « langue non autorisée »
  const m = s.match(/^(.*) (autorisé|renseigné|envoyé|accordé|vérifié|connecté|activé|payé|actif|administrateur|bloqué|en attente)$/);
  return m ? `${m[1]} non ${m[2]}` : `non ${s}`;
}

// Sujet d'une expression : « user->fresh()->email_verified_at » -> « e-mail vérifié »
function subject(expr) {
  const ids = String(expr).replace(/\([^()]*\)/g, '').split(/->|::|\.|\[|\]/).map(s => s.replace(/['"\s$]/g, '')).filter(s => s && !/^(fresh|first|get|this|request|input|query|auth|user|value|count)$/.test(s));
  const last = ids[ids.length - 1] || ids[0] || '';
  return fieldName(last);
}

// Colonnes et champs : « email_verified_at » -> « date de vérification de l'e-mail »
const FIELDS = {
  id: 'identifiant', name: 'nom', first_name: 'prénom', last_name: 'nom', firstname: 'prénom', lastname: 'nom', full_name: 'nom complet', email: 'adresse e-mail',
  password: 'mot de passe', created_at: 'date de création', updated_at: 'date de modification', deleted_at: 'date de suppression',
  email_verified_at: 'e-mail vérifié', remember_token: 'jeton de connexion', phone: 'téléphone', telephone: 'téléphone', address: 'adresse', city: 'ville',
  country: 'pays', status: 'statut', type: 'type', amount: 'montant', price: 'prix', total: 'total', quantity: 'quantité', description: 'description',
  title: 'titre', slug: 'adresse web', image: 'image', photo: 'photo', avatar: 'photo de profil', path: 'emplacement du fichier', url: 'lien',
  currency: 'devise', balance: 'solde', reference: 'référence', note: 'note', notes: 'notes', message: 'message', subject: 'sujet', content: 'contenu',
  body: 'contenu', locale: 'langue', role: 'rôle', role_id: 'rôle', is_active: 'actif', active: 'actif', is_default: 'par défaut', published_at: 'date de publication',
  paid_at: 'date de paiement', expires_at: 'date d\'expiration', otp_code: 'code de vérification', otp_expires_at: 'expiration du code', code: 'code',
  token: 'jeton', iban: 'IBAN', bic: 'BIC', bank_name: 'nom de la banque', account_holder_name: 'titulaire du compte', postal_code: 'code postal',
  zip: 'code postal', region: 'région', department: 'département', date: 'date', start_date: 'date de début', end_date: 'date de fin', due_date: 'date d\'échéance',
  birth_date: 'date de naissance', gender: 'sexe', plan: 'formule', views: 'nombre de vues', likes_count: 'nombre de « j\'aime »', position: 'position', order: 'ordre',
  sort_order: 'ordre', color: 'couleur', size: 'taille', weight: 'poids', mime_type: 'type de fichier', original_name: 'nom d\'origine', disk: 'espace de stockage',
  ip_address: 'adresse IP', user_agent: 'navigateur', last_active_at: 'dernière activité', verified_at: 'date de vérification', approved_at: 'date d\'approbation',
  rejected_at: 'date de refus', reason: 'motif', comment: 'commentaire', rating: 'note', data: 'données', payload: 'données', meta: 'informations complémentaires', settings: 'paramètres'
};
function fieldName(col) {
  const c = String(col || '').replace(/^['"]|['"]$/g, '');
  if (FIELDS[c]) return FIELDS[c];
  let m;
  if (/^last_?four$/.test(c)) return '4 derniers chiffres';
  if ((m = c.match(/^id_(type|number|card)$/))) return { type: 'type de pièce d\'identité', number: 'numéro de pièce d\'identité', card: 'pièce d\'identité' }[m[1]];
  if ((m = c.match(/^(.+)_expires?_at$/))) return `expiration ${deArt(nounPhrase(words(m[1])) || { text: fieldName(m[1]), gender: 'm' })}`;
  if ((m = c.match(/^(.+?)(_locked)?_until$/))) return `${fieldName(m[1])} ${m[2] ? 'bloqué ' : 'valable '}jusqu'au`;
  if ((m = c.match(/^(.+)_required$/))) return `${fieldName(m[1])} obligatoire`;
  if ((m = c.match(/^(.+)_(before|after)$/))) return `${fieldName(m[1])} ${m[2] === 'before' ? 'avant' : 'après'}`;
  if (/^(tries|attempts|retries)$/.test(c)) return 'nombre de tentatives';
  if ((m = c.match(/^(.+)_id$/))) { const np = nounPhrase(words(m[1])); return np && np.known ? np.text : words(m[1]).join(' '); }
  if ((m = c.match(/^(?:(.+)_)?(processed|handled|sent|generated|verified|locked|paid|approved|rejected|cancelled|canceled|completed|read|opened|issued)_at$/))) {
    const what = { processed: 'traitement', handled: 'traitement', sent: 'envoi', generated: 'génération', verified: 'vérification', locked: 'blocage', paid: 'paiement',
      approved: 'approbation', rejected: 'refus', cancelled: 'annulation', canceled: 'annulation', completed: 'fin', read: 'lecture', opened: 'ouverture', issued: 'émission' }[m[2]];
    return `date ${VOWEL.test(what) ? 'd\'' : 'de '}${what}${m[1] ? ` (${fieldName(m[1])})` : ''}`;
  }
  if ((m = c.match(/^(.+)_at$/))) { const np = nounPhrase(words(m[1])); return `date ${np && np.known ? deArt(np).replace(/^de /, 'de ') : 'de ' + words(m[1]).join(' ')}`.replace(/^date de l/, 'date de l'); }
  if ((m = c.match(/^(is|has|can)_(.+)$/))) return words(m[2]).map(w => ADJ[w] || (NOUNS[w] ? NOUNS[w][0] : w)).join(' ');
  if ((m = c.match(/^(.+)_count$/))) { const np = nounPhrase(words(m[1]), { plural: true }); return `nombre ${np && np.known ? deArt(np) : 'de ' + words(m[1]).join(' ')}`; }
  const np = nounPhrase(words(c));
  return np && np.known ? np.text : words(c).join(' ');
}

// Type de colonne : « bigint » -> « nombre », « datetime » -> « date et heure »
function typeName(t) {
  const x = String(t || '').toLowerCase().replace(/\s*\{.*\}$/, '');
  if (/^(bigint|int|integer|smallint|tinyint|year|unsignedbiginteger)$/.test(x)) return 'nombre';
  if (/^(decimal|float|double|real)$/.test(x)) return 'nombre décimal';
  if (/^(bool|boolean)$/.test(x)) return 'oui / non';
  if (/^(datetime|timestamp|immutable_datetime)$/.test(x)) return 'date et heure';
  if (/^date/.test(x)) return 'date';
  if (/^time$/.test(x)) return 'heure';
  if (/^(json|array|collection|object)$/.test(x)) return 'liste d\'informations';
  if (/^enum/.test(x)) return 'choix';
  if (/^uuid$/.test(x)) return 'identifiant unique';
  if (/^hashed$/.test(x)) return 'texte protégé';
  if (/^(text|longtext|mediumtext)$/.test(x)) return 'texte long';
  if (/^(string|char|varchar)$/.test(x)) return 'texte';
  if (/encrypt/.test(x)) return 'texte chiffré';
  if (/^(integer|int)$/.test(x)) return 'nombre';
  // Type inconnu (cast personnalisé, classe) : on ne l'affiche pas plutôt que d'écrire du code
  return '';
}

// Instruction de code -> action en langage courant (null si rien d'utile à dire)
function statement(text, ctx = {}) {
  const t = String(text).trim();
  let m;
  if (/^(Log::|logger\(|info\(|dd\(|dump\(|\$this->authorize\b)/.test(t) && !/authorize/.test(t)) return null;
  if (/authorize\(|Gate::/.test(t)) return 'Vérifier les droits d\'accès';
  if (/\$request->validate\(|Validator::make|->validated\(\)|->validate\(\)/.test(t)) return 'Vérifier les informations saisies';
  if ((m = t.match(/\b([A-Z]\w+)::(\w+)\(/)) && ctx.models && ctx.models.has(m[1])) return modelCall(m[1], m[2]);
  if ((m = t.match(/\b(Auth|Hash|Mail|Notification|DB|Storage|Cache|Http|Event|Session|Gate|Queue|Bus)::(\w+)/)) && FACADES[m[1]]) return FACADES[m[1]].call(m[2]);
  if (/auth\(\)->(login|attempt|logout)/.test(t)) return FACADES.Auth.call(t.match(/auth\(\)->(\w+)/)[1]);
  if (/->notify\(/.test(t)) return 'Envoyer une notification';
  if (/\b(event|dispatch)\(|::dispatch\(/.test(t)) return 'Déclencher un traitement automatique';
  if (/->(store|storeAs|storePublicly|move)\(/.test(t)) return 'Enregistrer le fichier envoyé';
  if (/session\(\s*\[|->session\(\)->(put|flash)|session\(\)->put/.test(t)) return 'Mémoriser des informations en session';
  if (/->session\(\)->regenerate/.test(t)) return null;
  if (/setLocale\(/.test(t)) return 'Définir la langue';
  if ((m = t.match(/\$(\w+)->(save|update|delete|attach|detach|sync|refresh|load|increment|decrement)\(/)) && ctx.vars && ctx.vars[m[1]]) return modelCall(ctx.vars[m[1]], m[2]);
  if ((m = t.match(/->assignRole\(\s*['"]([^'"]+)['"]/))) return `Attribuer le rôle « ${m[1]} »`;
  if ((m = t.match(/\$request->(?:input|get|query|post|string|integer|boolean|file)\(\s*['"]([^'"]+)['"]/))) return `Lire le champ « ${fieldName(m[1])} »`;
  if ((m = t.match(/\$request->(only|all|except)\(/))) return 'Lire les informations du formulaire';
  if (/(?:^|[^\w])(fetch|axios\.\w+|api\.\w+)\(/.test(t)) return 'Appeler le serveur';
  if ((m = t.match(/\bset(\w+)\(/)) && /use[A-Z]|\[\w+,\s*set\w+\]/.test(ctx.src || '') ) return `Mettre à jour ${fieldName(words(m[1]).join('_'))}`;
  if (/^\$?\w+\s*=\s*(['"`\d\[]|true|false|null|new\s)/.test(t)) return null; // affectation d'une simple valeur
  // Appel de fonction ou de méthode : son nom reformulé
  const calls = [...t.matchAll(/(?:->|::|\.|^|[\s(=!])(\w+)\s*\(/g)].map(x => x[1]).filter(n => !/^(if|for|foreach|while|switch|return|function|array|isset|empty|count|compact|now|today|collect|app|config|route|url|asset|__|trans|sprintf|json_encode|json_decode|strtolower|strtoupper|trim|explode|implode|in_array|array_\w+|str_\w+|is_\w+|max|min|round|abs|intval|floatval|date|time|Carbon|parse|format|toDateString|with|where|get|first|fresh|map|filter|each|pluck|toArray|only|except|merge|push|put)$/.test(n));
  for (const n of calls) {
    const p = phrase(n);
    if (p && (VERBS[words(n)[0]] || words(n).some(w => VERBS[w]))) return p;
  }
  return null;
}

module.exports = { words, phrase, routeTitle, resourceOf, modelLabel, modelCall, modelResult, FACADES, serviceLabel, responsePhrase, pageName, condition, fieldName, typeName, statement, nounPhrase, art, cap };
