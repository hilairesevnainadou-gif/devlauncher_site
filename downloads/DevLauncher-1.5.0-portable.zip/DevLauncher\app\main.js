// DevLauncher : serveur local qui pilote les projets et sert l'interface (ouverte dans une fenêtre Edge en mode application).
const path = require('path');
const fs = require('fs');
const net = require('net');
const http = require('http');
const crypto = require('crypto');
const { spawn, exec } = require('child_process');
const { detectServers, detectTools, detectProject, scanRoot, pickPhp, searchProjects } = require('./detect');
const { startCommand, viteCommand, actions } = require('./commands');
const { scanExternal } = require('./external');
const { MailStore, startSmtp } = require('./smtp');
const logs = require('./logs');
const db = require('./db');
const maint = require('./maintenance');
const backup = require('./backup');
const uml = require('./uml');
const queue = require('./queue');
const creator = require('./creator');
const seeders = require('./seeders');

// DEVLAUNCHER_PORT / DEVLAUNCHER_DATA : instance de test isolée (port et configuration à part).
const UI_PORT = Number(process.env.DEVLAUNCHER_PORT) || 47821;
const DATA_DIR = process.env.DEVLAUNCHER_DATA || path.join(process.env.APPDATA || process.env.USERPROFILE, 'DevLauncher');
const UI_DIR = path.join(__dirname, 'ui');
const VERSION = '1.5.0';
const BACKGROUND = process.argv.includes('--background'); // lancé au démarrage de Windows : pas de fenêtre
const STARTUP = process.argv.includes('--startup');       // lancé au démarrage de Windows, fenêtre ouverte
const NO_WINDOW = process.argv.includes('--no-window') || BACKGROUND;

// Journal de démarrage et des incidents (%APPDATA%\DevLauncher\journal.log) : indispensable pour comprendre
// un démarrage avec Windows qui échoue, puisqu'aucune fenêtre n'est alors visible.
const JOURNAL = path.join(DATA_DIR, 'journal.log');
function journal(msg) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(JOURNAL) && fs.statSync(JOURNAL).size > 512 * 1024) fs.renameSync(JOURNAL, JOURNAL + '.1');
    fs.appendFileSync(JOURNAL, `[${new Date().toLocaleString('fr-FR')}] ${msg}\n`);
  } catch { /* journal indisponible : sans conséquence */ }
}
// Une erreur imprévue ne doit pas arrêter DevLauncher (ni les projets qu'il a lancés) : elle est notée.
process.on('uncaughtException', err => journal(`Erreur imprévue : ${err && err.stack || err}`));
process.on('unhandledRejection', err => journal(`Promesse rejetée : ${err && err.stack || err}`));

let env = { servers: [], tools: {} };
let projects = [];               // projets détectés (avec config fusionnée)
const procs = new Map();         // clé "path|kind" -> ChildProcess
const status = new Map();        // path -> 'stopped' | 'starting' | 'running' | 'busy' | 'error'

// ---------- Configuration persistante ----------
const configFile = () => path.join(DATA_DIR, 'config.json');
const DEFAULT_SETTINGS = {
  startMysql: true,         // démarrer MySQL à l'ouverture
  startApache: false,       // démarrer Apache à l'ouverture
  autostartWindows: false,  // lancer DevLauncher au démarrage de Windows
  autostartShow: true,      // ... en ouvrant sa fenêtre (sinon : en arrière-plan, icône près de l'horloge)
  keepRunning: false,       // garder les serveurs actifs quand la fenêtre est fermée
  mailCapture: true,        // intercepter les mails des projets lancés par DevLauncher
  smtpPort: 2525,
  autoBackup: false,        // sauvegarde SQL quotidienne de toutes les bases
  autoBackupKeep: 7,        // nombre de sauvegardes automatiques conservées
  backupDir: ''             // vide = Documents\DevLauncher\Sauvegardes
};
const backupDir = () => settings().backupDir || backup.defaultDir();
// discoveredProjects : projets trouvés en cours d'exécution hors des dossiers des serveurs ; ignoredDiscovered : retirés par l'utilisateur.
let config = { extraRoots: [], extraProjects: [], discoveredProjects: [], ignoredDiscovered: [], hiddenRoots: [], projects: {}, settings: {} };
const settings = () => ({ ...DEFAULT_SETTINGS, ...config.settings });

function loadConfig() {
  try { config = { ...config, ...JSON.parse(fs.readFileSync(configFile(), 'utf8')) }; } catch { /* premier lancement */ }
  for (const k of ['extraRoots', 'extraProjects', 'discoveredProjects', 'ignoredDiscovered', 'hiddenRoots']) if (!Array.isArray(config[k])) config[k] = [];
  config.settings = config.settings || {};
}
function saveConfig() {
  fs.mkdirSync(path.dirname(configFile()), { recursive: true });
  fs.writeFileSync(configFile(), JSON.stringify(config, null, 2));
}

// ---------- Utilitaires ----------
function isPortOpen(port) {
  return new Promise(resolve => {
    const s = net.connect({ port, host: '127.0.0.1' });
    s.setTimeout(400);
    s.once('connect', () => { s.destroy(); resolve(true); });
    s.once('timeout', () => { s.destroy(); resolve(false); });
    s.once('error', () => resolve(false));
  });
}

// Évènements poussés vers l'interface (Server-Sent Events).
const clients = new Set();
function send(channel, payload) {
  const data = `event: ${channel}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of clients) res.write(data);
}

// La sortie console est aussi gardée côté serveur, pour l'analyse des erreurs.
const consoleBuf = new Map();
const MAX_CONSOLE = 300000;
function log(projectPath, text, kind = 'server') {
  const clean = text.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '');
  let buf = (consoleBuf.get(projectPath) || '') + clean;
  if (buf.length > MAX_CONSOLE) buf = buf.slice(-MAX_CONSOLE);
  consoleBuf.set(projectPath, buf);
  send('log', { path: projectPath, kind, text: clean });
}

// ---------- Interception des mails ----------
const mailStore = new MailStore(path.join(DATA_DIR, 'mails'));
const smtp = { server: null, port: null, error: null };
const mailId = p => crypto.createHash('md5').update(p.path.toLowerCase()).digest('hex').slice(0, 8);

// Variables d'environnement qui redirigent les mails du projet vers la boîte de test.
// Laravel ne remplace pas une variable d'environnement déjà définie par celle du .env : elles ont donc priorité.
function mailEnv(p) {
  const c = config.projects[p.path] || {};
  if (!smtp.server || !settings().mailCapture || c.mailCapture === false) return {};
  const port = String(smtp.port);
  return {
    MAIL_MAILER: 'smtp', MAIL_HOST: '127.0.0.1', MAIL_PORT: port,
    MAIL_USERNAME: 'null', MAIL_PASSWORD: 'null', MAIL_ENCRYPTION: 'null', MAIL_SCHEME: 'smtp',
    MAIL_EHLO_DOMAIN: `dl-${mailId(p)}.devlauncher.local`, // permet de savoir quel projet a envoyé le mail
    SMTP_HOST: '127.0.0.1', SMTP_PORT: port, SMTP_SECURE: 'false'
  };
}

function resolveMailProject(ehlo) {
  const m = String(ehlo || '').match(/^dl-([0-9a-f]{8})\./i);
  const p = m && projects.find(x => mailId(x) === m[1].toLowerCase());
  return p ? p.path : null;
}

async function startMailCatcher() {
  if (smtp.server) { smtp.server.close(); smtp.server = null; }
  const port = settings().smtpPort;
  try {
    smtp.server = await startSmtp(port, mailStore, resolveMailProject);
    smtp.port = port;
    smtp.error = null;
  } catch (err) {
    smtp.error = err.code === 'EADDRINUSE' ? `Le port ${port} est déjà utilisé : choisis-en un autre dans les paramètres.` : err.message;
  }
}

mailStore.on('mail', summary => {
  const p = summary.project && getProject(summary.project);
  send('mail', { ...summary, projectName: p ? p.name : null });
});

// Envoie un mail d'exemple à la boîte de test pour vérifier qu'elle fonctionne.
function sendSampleMail() {
  return new Promise((resolve, reject) => {
    if (!smtp.server) return reject(new Error(smtp.error || 'La boîte de test est arrêtée.'));
    const boundary = 'dl' + Date.now();
    const html = `<!doctype html><html><body style="margin:0;background:#f4f5f7;font-family:Segoe UI,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 12px">
<table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#fff;border-radius:8px;border:1px solid #e2e5e9">
<tr><td style="padding:22px 28px;border-bottom:4px solid #0373BB"><b style="font-size:18px;color:#1d2125">DevLauncher</b>
<span style="color:#8b939c"> · Novatech Solution</span></td></tr>
<tr><td style="padding:26px 28px;color:#1d2125;font-size:15px;line-height:1.6">
<h1 style="font-size:20px;margin:0 0 12px">Bonjour,</h1>
<p>Ceci est un mail de test : il a été capturé par la boîte de test de DevLauncher et n'a été envoyé à personne.</p>
<p>Tes projets lancés depuis DevLauncher arrivent ici automatiquement, avec leur mise en forme réelle.</p>
<p style="margin:26px 0"><a href="https://novatechbenin.com" style="background:#0373BB;color:#fff;text-decoration:none;padding:11px 20px;border-radius:6px;display:inline-block">Bouton d'exemple</a></p>
<p style="color:#57606a;font-size:13px">Accents : é è à ç ù ô — Symboles : € © ✓</p></td></tr>
<tr><td style="padding:16px 28px;background:#f8f9fa;color:#8b939c;font-size:12px;border-radius:0 0 8px 8px">Novatech Solution · Abomey-Calavi, Bénin</td></tr>
</table></td></tr></table></body></html>`;
    const text = "Bonjour,\n\nCeci est un mail de test : il a été capturé par la boîte de test de DevLauncher et n'a été envoyé à personne.\n\nAccents : é è à ç ù ô — Symboles : € © ✓\n";
    const b64 = s => Buffer.from(s, 'utf8').toString('base64').replace(/.{76}/g, '$&\r\n');
    const msg = [
      'From: "DevLauncher" <test@devlauncher.local>',
      'To: "Client exemple" <client@example.com>',
      `Subject: =?UTF-8?B?${Buffer.from('Mail de test DevLauncher ✓').toString('base64')}?=`,
      `Date: ${new Date().toUTCString()}`,
      'MIME-Version: 1.0',
      `Content-Type: multipart/alternative; boundary="${boundary}"`,
      '',
      `--${boundary}`, 'Content-Type: text/plain; charset=utf-8', 'Content-Transfer-Encoding: base64', '', b64(text),
      `--${boundary}`, 'Content-Type: text/html; charset=utf-8', 'Content-Transfer-Encoding: base64', '', b64(html),
      `--${boundary}--`, ''
    ].join('\r\n');
    const steps = ['EHLO devlauncher', 'MAIL FROM:<test@devlauncher.local>', 'RCPT TO:<client@example.com>', 'DATA', msg + '\r\n.', 'QUIT'];
    const sock = net.connect(smtp.port, '127.0.0.1');
    let i = 0;
    sock.on('data', d => {
      if (/^[45]\d\d/m.test(d.toString())) { sock.destroy(); return reject(new Error(d.toString())); }
      if (i < steps.length) sock.write(steps[i++] + '\r\n'); else { sock.end(); resolve(true); }
    });
    sock.on('end', () => resolve(true));
    sock.on('error', reject);
  });
}

function setStatus(projectPath, s, extra = {}) {
  status.set(projectPath, s);
  send('status', { path: projectPath, status: s, ...extra });
}

function childEnv(extra, project) {
  const php = (project && project.php) || env.tools.php;
  const dirs = [php, env.tools.composer].filter(Boolean).map(p => path.dirname(p));
  const sep = ';';
  const PATH = [...dirs, process.env.PATH || process.env.Path || ''].join(sep);
  const e = { ...process.env, PATH, Path: PATH, FORCE_COLOR: '0', NO_COLOR: '1', BROWSER: 'none', ...extra };
  return e;
}

function killTree(child) {
  return new Promise(resolve => {
    if (!child || child.exitCode !== null) return resolve();
    child.once('close', () => resolve());
    exec(`taskkill /PID ${child.pid} /T /F`, () => setTimeout(resolve, 1500));
  });
}

// Lance une commande shell et relaie sa sortie dans les logs du projet.
function run(project, kind, cmd, extraEnv = {}) {
  log(project.path, `\n> ${cmd}\n`, kind);
  const child = spawn(cmd, {
    cwd: project.path, shell: true, windowsHide: true, env: childEnv({ ...mailEnv(project), ...extraEnv }, project)
  });
  const key = `${project.path}|${kind}`;
  procs.set(key, child);
  child.stdout.on('data', d => log(project.path, d.toString(), kind));
  child.stderr.on('data', d => log(project.path, d.toString(), kind));
  child.on('error', err => log(project.path, `Erreur : ${err.message}\n`, kind));
  const done = new Promise(resolve => child.on('close', code => {
    if (procs.get(key) === child) procs.delete(key);
    log(project.path, `\n[${kind}] terminé (code ${code})\n`, kind);
    resolve(code);
  }));
  return { child, done };
}

// ---------- Ports ----------
// Donne un port aux nouveaux projets : celui où il tourne déjà s'il a été lancé à la main,
// sinon le premier port libre (ni attribué à un autre projet, ni occupé par un programme).
function assignPorts() {
  const used = new Set(Object.values(config.projects).flatMap(c => [c.port, c.vitePort]).filter(Boolean));
  for (const port of external.byPort.keys()) used.add(port);
  const next = start => { let p = start; while (used.has(p)) p++; used.add(p); return p; };
  for (const p of projects) {
    const c = config.projects[p.path] || (config.projects[p.path] = {});
    const ext = external.byProject.get(p.path);
    if (!c.port && ext) c.port = ext[0].port;
    if (!c.port) c.port = next(p.defaultPort);
    if (p.type === 'laravel' && p.hasVite) {
      if (!c.vitePort) c.vitePort = next(5173);
      if (c.withVite === undefined) c.withVite = true;
    }
  }
  saveConfig();
}

function findConflicts() {
  const seen = new Map();
  const conflicts = new Set();
  for (const p of projects) {
    const c = config.projects[p.path];
    for (const port of [c.port, c.withVite ? c.vitePort : null].filter(Boolean)) {
      if (seen.has(port)) { conflicts.add(p.path); conflicts.add(seen.get(port)); }
      else seen.set(port, p.path);
    }
  }
  return conflicts;
}

// ---------- Scan ----------
function scanAll({ assign = true } = {}) {
  env.servers = detectServers();
  env.tools = detectTools(env.servers);
  const roots = [...env.servers.map(s => s.root), ...config.extraRoots]
    .filter(r => !config.hiddenRoots.includes(r));
  const byPath = new Map();
  for (const root of roots) {
    // serverBase : le serveur local auquel appartient le projet (son dossier www / htdocs).
    const owner = env.servers.find(s => s.root === root);
    for (const p of scanRoot(root)) byPath.set(p.path, { ...p, root, rel: path.relative(root, path.dirname(p.path)), serverBase: owner ? owner.base : null, serverType: owner ? owner.type : null });
  }
  for (const dir of config.extraProjects) {
    const p = detectProject(dir);
    if (p) byPath.set(p.path, { ...p, root: 'Ajoutés manuellement' });
  }
  for (const dir of config.discoveredProjects || []) {
    if (byPath.has(dir) || !fs.existsSync(dir)) continue;
    const p = detectProject(dir);
    if (p) byPath.set(p.path, { ...p, root: DISCOVERED, discovered: true });
  }
  // Groupés par dossier racine (dans l'ordre de détection), puis par nom.
  const rootOrder = [...roots, 'Ajoutés manuellement', DISCOVERED];
  projects = [...byPath.values()].sort((a, b) =>
    (rootOrder.indexOf(a.root) - rootOrder.indexOf(b.root)) || a.name.localeCompare(b.name, 'fr', { sensitivity: 'base' }));
  for (const p of projects) {
    if (p.type !== 'laravel' && p.type !== 'php') continue;
    const php = pickPhp(env.tools.phps, p);
    if (php) { p.php = php.exe; p.phpVersion = php.version; }
  }
  if (assign) assignPorts();
}

// ---------- Projets lancés en dehors de l'application ----------
let external = { byProject: new Map(), byPort: new Map() };
let externalRun = null;
const isManaged = projectPath => procs.has(`${projectPath}|server`);

const DISCOVERED = 'Détectés hors des serveurs';

// Dossier du projet qui contient un fichier ou un dossier (remonte jusqu'à 8 niveaux) ; ignore Windows et les programmes.
const SYSTEM_DIR = /^[a-z]:\\(windows|program files|program files \(x86\)|programdata)\\|\\appdata\\(roaming\\npm|local\\programs|local\\npm-cache)\\/i;
function locateProject(target) {
  let dir = path.resolve(String(target || ''));
  try { if (fs.existsSync(dir) && fs.statSync(dir).isFile()) dir = path.dirname(dir); } catch { return null; }
  // Une racine de serveur (htdocs, www) ou un dossier qui en contient une n'est jamais un projet : on s'arrête là.
  const roots = [...env.servers.map(x => x.root), ...config.extraRoots].filter(Boolean).map(r => path.resolve(r).toLowerCase() + '\\');
  for (let i = 0; i < 8 && dir; i++) {
    const key = dir.toLowerCase() + '\\';
    if (SYSTEM_DIR.test(key) || roots.some(r => r.startsWith(key))) return null;
    if (fs.existsSync(dir) && detectProject(dir)) return dir;
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  return null;
}

// force = attendre l'analyse en cours puis en relancer une (résultat à jour garanti).
async function refreshExternal(force = false) {
  if (externalRun) {
    if (!force) return;
    await externalRun;
  }
  if (!projects.length) return;
  externalRun = doRefreshExternal().finally(() => { externalRun = null; });
  return externalRun;
}

async function doRefreshExternal(again = true) {
  {
    // Ports de DevLauncher lui-même (interface, boîte mail de test) : jamais pris pour un projet.
    const ignore = new Set([UI_PORT, smtp.port].filter(Boolean));
    for (const p of projects) {
      if (!isManaged(p.path)) continue;
      const c = config.projects[p.path];
      ignore.add(c.port);
      if (c.vitePort) ignore.add(c.vitePort);
    }
    const previous = external.byProject;
    external = await scanExternal(projects, ignore, { locate: locateProject });
    // Projets en cours d'exécution situés hors des dossiers des serveurs : ajoutés à la liste, puis nouvelle analyse
    // pour les rattacher (état « lancé à la main », port, ouverture dans le navigateur).
    const added = [];
    for (const o of external.outside || []) {
      const known = [...config.discoveredProjects, ...config.extraProjects, ...config.ignoredDiscovered].some(d => d.toLowerCase() === o.dir.toLowerCase());
      if (known || added.includes(o.dir)) continue;
      config.discoveredProjects.push(o.dir);
      added.push(o.dir);
    }
    if (added.length && again) {
      saveConfig();
      scanAll();
      send('discovered', added.map(dir => ({ path: dir, name: path.basename(dir) })));
      return doRefreshExternal(false);
    }
    const found = [];
    for (const p of projects) {
      if (isManaged(p.path)) continue;
      const entries = external.byProject.get(p.path);
      if (entries) {
        const port = entries[0].port;
        if (status.get(p.path) !== 'external') {
          setStatus(p.path, 'external', { external: entries, url: `http://localhost:${port}` });
        }
        if (!previous.has(p.path)) found.push({ path: p.path, name: p.name, ports: entries.map(e => e.port), pids: entries.map(e => e.pid) });
      } else if (status.get(p.path) === 'external') {
        setStatus(p.path, 'stopped');
      }
    }
    if (found.length) send('external-found', found);
  }
}

function describePortOwner(port) {
  const e = external.byPort.get(port);
  if (!e) return 'un autre programme';
  if (e.project) {
    const p = getProject(e.project);
    return `le projet « ${p ? p.name : e.project} » lancé manuellement (PID ${e.pid})`;
  }
  return `${e.name} (PID ${e.pid})`;
}

async function killExternal(projectPath) {
  const entries = external.byProject.get(projectPath) || [];
  await Promise.all(entries.map(e => new Promise(r => exec(`taskkill /PID ${e.pid} /T /F`, () => r()))));
  await refreshExternal(true);
}

function snapshot() {
  const conflicts = findConflicts();
  return {
    version: VERSION,
    servers: env.servers,
    tools: env.tools,
    extraRoots: config.extraRoots,
    settings: settings(),
    canAutostart: !!process.env.DEVLAUNCHER_EXE,
    mail: { running: !!smtp.server, port: smtp.port, error: smtp.error, unread: mailStore.mails.filter(m => !m.read).length },
    projects: projects.map(p => ({
      ...p,
      config: config.projects[p.path],
      // Configuration Laravel en cache : les variables d'environnement (dont les mails) sont alors ignorées.
      configCached: p.type === 'laravel' && fs.existsSync(path.join(p.path, 'bootstrap', 'cache', 'config.php')),
      mailCapture: settings().mailCapture && (config.projects[p.path] || {}).mailCapture !== false,
      status: status.get(p.path) || 'stopped',
      external: isManaged(p.path) ? null : (external.byProject.get(p.path) || null),
      conflict: conflicts.has(p.path),
      actions: actions(p, env.tools)
    }))
  };
}

const getProject = projectPath => projects.find(p => p.path === projectPath);

// ---------- Démarrage / arrêt ----------
async function needsInstall(p) {
  if (p.type === 'laravel') return !fs.existsSync(path.join(p.path, 'vendor')) || (p.hasVite && withVite(p) && !fs.existsSync(path.join(p.path, 'node_modules')));
  if (p.type === 'php') return fs.existsSync(path.join(p.path, 'composer.json')) && !fs.existsSync(path.join(p.path, 'vendor'));
  if (p.type === 'static') return false; // fichiers servis tels quels
  return !fs.existsSync(path.join(p.path, 'node_modules'));
}

const withVite = p => p.type === 'laravel' && p.hasVite && config.projects[p.path].withVite;

async function startProject(projectPath) {
  const p = getProject(projectPath);
  if (!p) return;
  const c = config.projects[p.path];
  if (procs.has(`${p.path}|server`)) return;

  if (findConflicts().has(p.path)) {
    setStatus(p.path, 'error', { message: `Le port ${c.port} est déjà attribué à un autre projet.` });
    return;
  }
  if (external.byProject.has(p.path)) {
    const ports = external.byProject.get(p.path).map(e => e.port).join(', ');
    setStatus(p.path, 'external', { message: `Ce projet tourne déjà (lancé manuellement) sur le port ${ports}. Arrête-le d'abord ou utilise-le tel quel.` });
    return;
  }
  if (await isPortOpen(c.port)) {
    await refreshExternal(true);
    setStatus(p.path, 'error', { message: `Le port ${c.port} est déjà utilisé par ${describePortOwner(c.port)}. Choisis un autre port.` });
    return;
  }
  if (withVite(p) && await isPortOpen(c.vitePort)) {
    await refreshExternal(true);
    setStatus(p.path, 'error', { message: `Le port Vite ${c.vitePort} est déjà utilisé par ${describePortOwner(c.vitePort)}.` });
    return;
  }

  setStatus(p.path, 'starting');

  // Dépendances manquantes : on installe d'abord.
  if (await needsInstall(p)) {
    log(p.path, 'Dépendances manquantes, installation...\n');
    const install = actions(p, env.tools).find(a => a.id === 'install');
    const code = await run(p, 'action', install.cmd).done;
    p.hasNodeModules = fs.existsSync(path.join(p.path, 'node_modules'));
    p.hasVendor = fs.existsSync(path.join(p.path, 'vendor'));
    p.hasEnv = fs.existsSync(path.join(p.path, '.env'));
    p.needsKey = false;
    if (code !== 0) { setStatus(p.path, 'error', { message: "L'installation a échoué, voir les logs." }); return; }
  }

  const { cmd, env: extra } = startCommand(p, c.port, env.tools);
  // APP_URL locale qui ne correspond pas au port du projet : corrigée pour cette session (le .env n'est pas modifié).
  if (p.type === 'laravel') {
    const appUrl = db.readEnv(p).values.APP_URL || '';
    const m = appUrl.match(/^(https?:\/\/(?:localhost|127\.0\.0\.1))(?::(\d+))?(\/.*)?$/);
    if (!appUrl || (m && Number(m[2] || 80) !== Number(c.port))) extra.APP_URL = `${m ? m[1] : 'http://localhost'}:${c.port}${m && m[3] ? m[3] : ''}`;
  }
  const server = run(p, 'server', cmd, extra);
  // Traitement automatique de la file d'attente lancé avec le projet (option de l'onglet File d'attente)
  if (p.type === 'laravel' && c.queueWorker) startQueueWorker(p);
  if (withVite(p)) {
    const v = viteCommand(c.vitePort);
    run(p, 'vite', v.cmd, v.env);
  }
  watchEnv(p);
  server.done.then(() => {
    if (procs.has(`${p.path}|server`)) return; // un nouveau serveur a déjà pris le relais (redémarrage)
    const vite = procs.get(`${p.path}|vite`);
    if (vite) killTree(vite);
    if (!envRestarting.has(p.path)) unwatchEnv(p.path);
    if (status.get(p.path) !== 'stopped') setStatus(p.path, 'stopped');
  });

  // Attend que le port réponde (jusqu'à 3 minutes : premier build Next/Nuxt parfois lent).
  const started = Date.now();
  const poll = async () => {
    if (!procs.has(`${p.path}|server`)) return;
    if (await isPortOpen(c.port)) return setStatus(p.path, 'running', { url: `http://localhost:${c.port}` });
    if (Date.now() - started < 180000) setTimeout(poll, 700);
  };
  poll();
}

// ---------- .env d'un projet lancé : modification prise en compte automatiquement ----------
// PHP / Laravel relisent le .env à chaque requête (cache de configuration Laravel vidé s'il existe) ;
// Node, Vite, Next, Nuxt, Angular, Astro ne le lisent qu'au démarrage : le projet est redémarré.
const ENV_FILE = /^\.env(\.local|\.development|\.development\.local)?$/;
const envWatchers = new Map();   // path -> { watcher, snapshot, timer }
const envRestarting = new Set(); // projets en cours de redémarrage après une modification du .env

function readEnvFiles(dir) {
  const values = {};
  for (const f of ['.env', '.env.local', '.env.development', '.env.development.local']) {
    let text = '';
    try { text = fs.readFileSync(path.join(dir, f), 'utf8'); } catch { continue; }
    for (const line of text.split(/\r?\n/)) {
      const m = line.match(/^\s*(?:export\s+)?([A-Za-z_][\w.]*)\s*=\s*(.*)$/);
      if (m) values[m[1]] = m[2].trim();
    }
  }
  return values;
}

function watchEnv(p) {
  if (envWatchers.has(p.path) || (config.projects[p.path] || {}).envWatch === false) return;
  let watcher;
  try {
    // Surveille le dossier (et non le fichier) : les éditeurs remplacent souvent le fichier en l'enregistrant.
    watcher = fs.watch(p.path, { persistent: false }, (event, name) => {
      if (!name || !ENV_FILE.test(String(name))) return;
      const w = envWatchers.get(p.path);
      if (!w) return;
      clearTimeout(w.timer);
      w.timer = setTimeout(() => onEnvChange(p.path), 600); // un enregistrement déclenche plusieurs événements
    });
  } catch (err) { log(p.path, `Surveillance du .env impossible : ${err.message}\n`, 'server'); return; }
  watcher.on('error', () => unwatchEnv(p.path));
  envWatchers.set(p.path, { watcher, snapshot: readEnvFiles(p.path), timer: null });
}

function unwatchEnv(projectPath) {
  const w = envWatchers.get(projectPath);
  if (!w) return;
  clearTimeout(w.timer);
  try { w.watcher.close(); } catch { /* déjà fermé */ }
  envWatchers.delete(projectPath);
}

async function onEnvChange(projectPath) {
  const w = envWatchers.get(projectPath);
  const p = getProject(projectPath);
  if (!w || !p) return;
  const now = readEnvFiles(projectPath);
  const keys = [...new Set([...Object.keys(w.snapshot), ...Object.keys(now)])].filter(k => w.snapshot[k] !== now[k]);
  w.snapshot = now;
  if (!keys.length) return; // enregistré sans modification
  const shown = keys.slice(0, 8).join(', ') + (keys.length > 8 ? ` (+${keys.length - 8})` : '');
  let action;
  if (p.type === 'laravel' || p.type === 'php') {
    const cache = path.join(projectPath, 'bootstrap', 'cache', 'config.php');
    if (p.type === 'laravel' && fs.existsSync(cache)) {
      // Configuration en cache : Laravel ignorerait le .env tant qu'elle n'est pas vidée.
      try { fs.unlinkSync(cache); action = 'cache de configuration vidé, pris en compte immédiatement'; }
      catch (err) { action = `cache de configuration impossible à vider (${err.message})`; }
    } else action = 'pris en compte immédiatement (PHP relit le .env à chaque requête)';
    // Variables lues par Vite (VITE_*) : seul le serveur Vite doit redémarrer.
    if (p.type === 'laravel' && withVite(p) && keys.some(k => k.startsWith('VITE_')) && procs.has(`${projectPath}|vite`)) {
      await killTree(procs.get(`${projectPath}|vite`));
      const v = viteCommand(config.projects[projectPath].vitePort);
      run(p, 'vite', v.cmd, v.env);
      action += ' ; Vite redémarré pour les variables VITE_';
    }
  } else if ((config.projects[projectPath] || {}).envRestart === false) {
    action = 'redémarre le projet pour l\'appliquer (redémarrage automatique désactivé)';
  } else {
    action = 'projet redémarré pour l\'appliquer';
    envRestarting.add(projectPath);
    try { await stopProject(projectPath); await startProject(projectPath); } finally { envRestarting.delete(projectPath); }
  }
  log(projectPath, `\n[.env modifié] ${shown} : ${action}\n`, 'server');
  journal(`.env de ${p.name} modifié (${shown}) : ${action}`);
  send('env-changed', { path: projectPath, name: p.name, keys, action });
}

async function stopProject(projectPath) {
  if (!envRestarting.has(projectPath)) unwatchEnv(projectPath);
  setStatus(projectPath, 'stopped');
  const kills = [];
  for (const [key, child] of procs) {
    if (key.startsWith(projectPath + '|')) kills.push(killTree(child));
  }
  await Promise.all(kills);
}

// Quel MySQL va réellement recevoir les requêtes du projet ? (celui qui écoute sur DB_HOST:DB_PORT du .env)
// match = false quand ce n'est pas le MySQL du serveur du projet (ex. projet Laragon, MySQL de XAMPP démarré).
async function dbTarget(p) {
  if (!p || p.type !== 'laravel') return { applicable: false };
  const conn = db.connFromEnv(db.readEnv(p).values);
  if (!['mysql', 'mariadb'].includes(String(conn.connection).toLowerCase())) return { applicable: false };
  if (!['127.0.0.1', 'localhost', '::1'].includes(String(conn.host).toLowerCase())) return { applicable: false, remote: true, host: conn.host };
  const port = Number(conn.port) || 3306;
  const own = env.servers.find(s => s.base === p.serverBase && s.mysqld) || null;
  const owner = await isPortOpen(port) ? await maint.portOwner(port) : null;
  const listening = owner ? env.servers.find(s => maint.same(owner.exe, s.mysqld)) : null;
  return {
    applicable: true, port, database: conn.database,
    projectServer: own ? { type: own.type, base: own.base } : null,
    running: !!owner,
    listening: listening ? { type: listening.type, base: listening.base } : owner ? { type: null, name: owner.name } : null,
    match: !own ? !!owner : !!listening && listening.base === own.base
  };
}

const DB_ACTIONS = new Set(['migrate', 'status', 'seed', 'rollback', 'fresh']);

// Traitement continu de la file d'attente Laravel (les e-mails passent par la boîte de test si l'interception est active).
function startQueueWorker(p) {
  const key = `${p.path}|worker`;
  if (procs.has(key)) return;
  const php = `"${p.php || env.tools.php || 'php'}"`;
  const w = run(p, 'worker', `${php} artisan queue:work --sleep=3 --tries=3`);
  send('queue', { path: p.path, worker: true });
  w.done.then(() => send('queue', { path: p.path, worker: false }));
}

async function runAction(projectPath, actionId, opts = {}) {
  const p = getProject(projectPath);
  const a = p && actions(p, env.tools).find(x => x.id === actionId);
  if (!a) return;
  if (procs.has(`${p.path}|action`)) {
    log(p.path, 'Une action est déjà en cours pour ce projet.\n');
    return;
  }
  // Garde-fou : une action sur la base ne part pas vers le MySQL d'un autre serveur, sauf confirmation explicite.
  if (DB_ACTIONS.has(actionId) && !opts.force) {
    const t = await dbTarget(p);
    if (t.applicable && !t.match) {
      const why = !t.running ? `aucun MySQL ne répond sur le port ${t.port}`
        : `le MySQL qui répond sur le port ${t.port} est celui de ${t.listening.type || t.listening.name}, pas celui de ${t.projectServer ? t.projectServer.type : 'ce projet'}`;
      log(p.path, `\n[${actionId}] bloqué : ${why}.\n`, 'action');
      send('action', { path: p.path, running: false, id: actionId, code: -1, blocked: true, target: t });
      return { blocked: true, target: t };
    }
  }
  send('action', { path: p.path, running: true, id: actionId });
  const code = await run(p, 'action', a.cmd).done;
  send('action', { path: p.path, running: false, id: actionId, code });
  if (actionId === 'install') {
    p.hasNodeModules = fs.existsSync(path.join(p.path, 'node_modules'));
    p.hasVendor = fs.existsSync(path.join(p.path, 'vendor'));
    p.hasEnv = fs.existsSync(path.join(p.path, '.env'));
    if (code === 0) p.needsKey = false;
  }
}

// ---------- Services du serveur local (MySQL, Apache) ----------
// Ils restent actifs après la fermeture de DevLauncher, comme lorsqu'on les démarre depuis XAMPP ou Laragon.
const SERVICES = {
  mysql: { label: 'MySQL', port: 3306, exe: s => s.mysqld, args: s => (fs.existsSync(s.myini) ? [`--defaults-file=${s.myini}`, '--standalone'] : ['--standalone']) },
  apache: { label: 'Apache', port: 80, exe: s => s.httpd, args: () => [] }
};

async function serviceStatus(name) {
  const def = SERVICES[name];
  const server = env.servers.find(s => def.exe(s));
  return { name, label: def.label, port: def.port, available: !!server, running: await isPortOpen(def.port), server: server ? server.type : null };
}

async function services() {
  return { mysql: await serviceStatus('mysql'), apache: await serviceStatus('apache') };
}

// Démarre MySQL ou Apache (premier serveur qui le fournit, ou celui indiqué) ; en cas d'échec, l'extrait du log est renvoyé.
async function startService(name, base) {
  const def = SERVICES[name];
  if (!def) return null;
  const server = base ? env.servers.find(s => s.base === base) : env.servers.find(s => def.exe(s));
  if (!server || !def.exe(server)) return serviceStatus(name);
  const r = name === 'mysql' ? await maint.startMysql(server) : await maint.startApache(server);
  const st = { ...(await serviceStatus(name)), ...r, running: r.ok || (await serviceStatus(name)).running };
  send('services', await services());
  return st;
}

// ---------- Sauvegardes ----------
let backupRunning = null;
async function runBackup(server, opts) {
  if (backupRunning) throw new Error('Une sauvegarde est déjà en cours.');
  backupRunning = server.base;
  try {
    const r = await backup.create(server, backupDir(), { ...opts, onProgress: p => send('backup', { ...p, server: server.type }) });
    send('backup', { step: 'done', name: r.name, server: server.type, label: r.label });
    return r;
  } catch (err) {
    send('backup', { step: 'error', message: err.message, server: server.type });
    throw err;
  } finally { backupRunning = null; }
}

// Sauvegarde automatique : au plus une par jour et par serveur, uniquement si son MySQL tourne.
async function autoBackupTick() {
  if (!settings().autoBackup) return;
  const existing = backup.list(backupDir()).filter(b => b.label === 'auto');
  for (const server of env.servers.filter(s => s.mysqld)) {
    const last = existing.find(b => b.server.base === server.base);
    if (last && Date.now() - new Date(last.date).getTime() < 20 * 3600 * 1000) continue;
    const my = maint.mysqlConfig(server);
    const owner = await isPortOpen(my.port) ? await maint.portOwner(my.port) : null;
    if (!owner || !maint.same(owner.exe, server.mysqld)) continue;
    try {
      await runBackup(server, { type: 'dump', config: true, label: 'auto' });
      backup.rotate(backupDir(), 'auto', settings().autoBackupKeep);
    } catch (err) { console.error('Sauvegarde automatique :', err.message); }
  }
}
const serverByBase = base => {
  const s = env.servers.find(x => x.base === base);
  if (!s) throw new Error('Serveur introuvable.');
  return s;
};

// ---------- Démarrage automatique ----------
const RUN_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
function setWindowsAutostart(enabled) {
  return new Promise((resolve, reject) => {
    const exe = process.env.DEVLAUNCHER_EXE;
    if (enabled && !exe) return reject(new Error('Disponible uniquement dans la version installée de DevLauncher.'));
    const mode = settings().autostartShow ? '--startup' : '--background';
    const cmd = enabled
      ? `reg add "${RUN_KEY}" /v DevLauncher /t REG_SZ /d "\\"${exe}\\" ${mode}" /f`
      : `reg delete "${RUN_KEY}" /v DevLauncher /f`;
    exec(cmd, { windowsHide: true }, err => (err && enabled ? reject(err) : resolve()));
  });
}

// À l'ouverture : détection, services du serveur local, puis projets marqués « lancer automatiquement ».
async function bootstrap() {
  await startMailCatcher();
  scanAll({ assign: false });
  await refreshExternal(true);
  assignPorts();
  const s = settings();
  if (s.startMysql) await startService('mysql');
  if (s.startApache) await startService('apache');
  for (const p of projects) {
    const c = config.projects[p.path];
    if (c.autostart && !external.byProject.has(p.path)) startProject(p.path);
  }
  autoBackupTick();
  setInterval(autoBackupTick, 3600 * 1000);
}
let ready = null;

// ---------- Fenêtres et dialogues Windows ----------
function openExternal(url) {
  if (/^https?:\/\//.test(url)) spawn('cmd.exe', ['/c', 'start', '""', url], { windowsHide: true, detached: true }).unref();
}
function openFolder(p) {
  spawn('explorer.exe', [p], { detached: true }).unref();
}
function pickFolder(description = 'Choisis un projet ou un dossier qui contient des projets') {
  const ps = [
    'Add-Type -AssemblyName System.Windows.Forms;',
    '$o = New-Object System.Windows.Forms.Form -Property @{TopMost=$true};',
    '$d = New-Object System.Windows.Forms.FolderBrowserDialog;',
    `$d.Description = '${description.replace(/['"]/g, ' ')}';`,
    "if ($d.ShowDialog($o) -eq 'OK') { [Console]::OutputEncoding = [Text.Encoding]::UTF8; Write-Output $d.SelectedPath }"
  ].join(' ');
  return new Promise(resolve => {
    exec(`powershell -NoProfile -STA -Command "${ps}"`, { windowsHide: true, encoding: 'utf8' }, (err, out) => resolve(err ? null : out.trim() || null));
  });
}

let pcSearch = null; // recherche de projets sur le PC en cours

// ---------- Création de projet ----------
// Une seule création à la fois ; sa sortie est relayée en direct (événement « create »).
let creation = null;

function createLog(text) {
  if (!creation) return;
  const clean = text.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '');
  creation.log += clean;
  if (creation.log.length > 200000) creation.log = creation.log.slice(-200000);
  send('create', { log: clean });
}

async function freePort(from) {
  const used = new Set(Object.values(config.projects).flatMap(c => [c.port, c.vitePort]).filter(Boolean));
  let port = from;
  while (used.has(port) || await isPortOpen(port)) port++;
  return port;
}

function runCreateStep(step) {
  return new Promise(resolve => {
    createLog(`\n> ${step.cmd}\n`);
    const extra = { CI: 'true', npm_config_yes: 'true', ...(step.env || {}) };
    const e = childEnv(extra, step.phpDir ? { php: path.join(step.phpDir, 'php.exe') } : null);
    const child = spawn(step.cmd, { cwd: step.cwd, shell: true, windowsHide: true, env: e });
    creation.child = child;
    child.stdout.on('data', d => createLog(d.toString()));
    child.stderr.on('data', d => createLog(d.toString()));
    child.stdin.end();
    child.on('error', err => createLog(`Erreur : ${err.message}\n`));
    child.on('close', code => { creation.child = null; resolve(code); });
  });
}

// Vérifie la demande de création et prépare ses étapes (sans rien exécuter).
async function prepareCreate(opts, preview = false) {
  const type = opts.type;
  const def = creator.TYPES[type];
  if (!def) throw new Error('Type de projet inconnu.');
  const name = String(opts.name || '').trim();
  if (!creator.validName(type, name)) {
    throw new Error(['laravel', 'php'].includes(type)
      ? 'Nom invalide : lettres, chiffres, point, tiret et _ uniquement, sans espace.'
      : 'Nom invalide : minuscules, chiffres, point, tiret et _ uniquement, sans espace (règle de npm).');
  }
  const parent = String(opts.parent || '');
  if (!parent || !fs.existsSync(parent) || !fs.statSync(parent).isDirectory()) throw new Error('Dossier de destination introuvable.');
  const dir = path.join(parent, name);
  if (fs.existsSync(dir)) throw new Error(`Le dossier « ${name} » existe déjà dans ce dossier de destination.`);
  const req = creator.requirements(env.tools);
  const missing = def.needs.filter(n => !req[n].ok).map(n => req[n].detail);
  if (missing.length) throw new Error(missing.join(' '));
  const port = await freePort(def.defaultPort);
  const p = creator.plan(type, { ...opts, name, parent, port }, { phps: env.tools.phps, composer: env.tools.composer, preview });
  return { type, def, name, parent, dir, port, ...p };
}

async function createProject(opts) {
  if (creation && creation.running) throw new Error('Une création est déjà en cours.');
  const { type, name, parent, dir, port, steps } = await prepareCreate(opts);
  const server = env.servers.find(s => s.root && (parent + path.sep).toLowerCase().startsWith((s.root + path.sep).toLowerCase())) || null;
  const dbName = creator.slugDb(name);
  const helpers = {
    configureLaravel: (d, { sqlite, legacy } = {}) => {
      const patch = { APP_NAME: name, APP_URL: `http://localhost:${port}` };
      if (opts.database === 'mysql') Object.assign(patch, { DB_CONNECTION: 'mysql', DB_HOST: '127.0.0.1', DB_PORT: '3306', DB_DATABASE: dbName, DB_USERNAME: 'root', DB_PASSWORD: '' });
      // Le fichier SQLite peut manquer (Laravel 10 et avant, ou scripts de Laravel sautés après une nouvelle tentative).
      if (sqlite) {
        const file = path.join(d, 'database', 'database.sqlite');
        if (!fs.existsSync(file)) fs.writeFileSync(file, '');
        // Laravel 10 et avant : le .env vise MySQL par défaut.
        if (legacy) Object.assign(patch, { DB_CONNECTION: 'sqlite', DB_DATABASE: file });
      }
      db.writeEnv({ path: d }, patch);
      // writeEnv garde une copie de l'ancien .env : inutile pour un projet tout neuf.
      try { fs.unlinkSync(path.join(d, '.env.devlauncher.bak')); } catch {}
    },
    createDatabase: async d => {
      if (!(await isPortOpen(3306))) await startService('mysql', server ? server.base : undefined);
      const r = await db.create({ path: d }, env.servers, { name: dbName });
      createLog(`${r.message}\n`);
    }
  };

  creation = { running: true, cancelled: false, type, name, dir, port, log: '', steps: steps.map(s => ({ label: s.label, state: 'todo' })), child: null };
  send('create', { state: snapshotCreation() });
  (async () => {
    let ok = true;
    for (let i = 0; i < steps.length; i++) {
      const s = steps[i];
      if (creation.cancelled) {
        for (let j = i; j < steps.length; j++) creation.steps[j].state = 'skip';
        ok = false; break;
      }
      creation.steps[i].state = 'run';
      creation.steps[i].startedAt = Date.now(); // durée affichée par l'interface (même horloge : poste local)
      send('create', { state: snapshotCreation() });
      createLog(`\n== ${s.label}\n`);
      let good = true;
      try {
        if (s.cmd) {
          good = (await runCreateStep(s)) === 0 && !creation.cancelled;
          for (let t = 1; !good && s.retry && t <= s.retry.times && !creation.cancelled && fs.existsSync(s.retry.when); t++) {
            createLog(`\n== Nouvelle tentative (${t}/${s.retry.times}) : reprise du téléchargement des dépendances\n`);
            good = (await runCreateStep({ ...s, ...s.retry })) === 0 && !creation.cancelled;
          }
        } else await s.run(helpers);
      } catch (err) { createLog(`Erreur : ${err.message}\n`); good = false; }
      creation.steps[i].state = good ? 'done' : 'error';
      creation.steps[i].endedAt = Date.now();
      if (!good) {
        ok = false;
        // Projet déjà téléchargé : on garde ce qui marche et on signale l'étape à refaire.
        for (let j = i + 1; j < steps.length; j++) creation.steps[j].state = 'skip';
        break;
      }
    }
    creation.running = false;
    creation.ok = ok;
    creation.created = fs.existsSync(dir);
    if (creation.created) {
      if (!server && !config.extraProjects.includes(dir) && !config.extraRoots.includes(parent)) config.extraProjects.push(dir);
      config.projects[dir] = { ...(config.projects[dir] || {}), port };
      saveConfig();
      scanAll();
      creation.found = !!getProject(dir);
    }
    createLog(ok ? `\nProjet « ${name} » prêt (port ${port}).\n` : creation.cancelled ? '\nCréation annulée.\n' : '\nLa création s\'est arrêtée sur une erreur (détails ci-dessus).\n');
    send('create', { state: snapshotCreation(), done: true });
  })();
  return snapshotCreation();
}

function snapshotCreation() {
  if (!creation) return null;
  const { running, cancelled, type, name, dir, port, steps, ok, created, found } = creation;
  return { running, cancelled, type, name, dir, port, steps, ok, created, found };
}

// ---------- API HTTP ----------
const api = {
  // On repère d'abord les serveurs lancés à la main pour ne pas attribuer leurs ports à d'autres projets.
  scan: async () => {
    // Le premier appel attend la détection faite au démarrage au lieu de la refaire.
    if (ready) { const r = ready; ready = null; await r; return snapshot(); }
    scanAll({ assign: false }); await refreshExternal(true); assignPorts(); return snapshot();
  },
  snapshot: () => snapshot(),
  start: p => startProject(p),
  stop: p => stopProject(p),
  restart: async p => { await stopProject(p); await startProject(p); },
  action: (p, id, opts) => runAction(p, id, opts),
  dbTarget: p => dbTarget(getProject(p)),
  // Arrête le MySQL qui occupe le port (autre serveur) et démarre celui du serveur du projet.
  switchMysqlFor: async p => {
    const pr = getProject(p);
    const t = await dbTarget(pr);
    if (!t.applicable || !t.projectServer) throw new Error('Ce projet n\'est rattaché à aucun serveur local.');
    if (t.match) return { ok: true, message: `Le MySQL de ${t.projectServer.type} est déjà actif.` };
    if (t.listening && t.listening.base) {
      const s = await maint.stopMysql(env.servers.find(x => x.base === t.listening.base));
      if (!s.ok) return { ok: false, needForce: s.needForce, message: `Le MySQL de ${t.listening.type} refuse l'arrêt propre (mot de passe root) : arrête-le depuis l'onglet Serveur.` };
    } else if (t.listening) {
      return { ok: false, message: `Le port ${t.port} est occupé par ${t.listening.name} : libère-le depuis l'onglet Serveur.` };
    }
    const r = await startService('mysql', t.projectServer.base);
    return { ok: !!(r && (r.ok || r.running)), message: r && (r.ok || r.running) ? `MySQL de ${t.projectServer.type} démarré.` : `Le MySQL de ${t.projectServer.type} n'a pas démarré${r && r.message ? ' : ' + r.message : ''}.`, log: r && r.log };
  },
  killExternal: p => killExternal(p),
  setConfig: (p, patch) => {
    const before = config.projects[p] || {};
    config.projects[p] = { ...before, ...patch };
    saveConfig();
    // Nouveau port : les adresses locales du .env (APP_URL, localhost:<port>...) sont mises à jour automatiquement.
    let envChanges = [];
    const pr = getProject(p);
    if (pr && patch.port !== undefined && Number(patch.port) !== Number(before.port)) {
      try { envChanges = db.syncPortInEnv(pr, before.port, patch.port); } catch (err) { envChanges = [{ error: err.message }]; }
    }
    return { ...snapshot(), envChanges };
  },
  openUrl: url => openExternal(url),
  openFolder: p => openFolder(p),
  // Invite de commandes placée dans le projet, avec le PHP et Composer du projet dans le PATH.
  // La ligne de commande est écrite telle quelle : Node ajouterait des \" que cmd.exe ne comprend pas
  // (erreur « La syntaxe du nom de fichier... est incorrecte » avec les chemins à espaces et parenthèses).
  openTerminal: p => {
    const pr = getProject(p);
    if (!pr || !fs.existsSync(pr.path)) throw new Error('Dossier du projet introuvable.');
    const title = `DevLauncher - ${pr.name}`.replace(/["^&|<>%]/g, '');
    spawn('cmd.exe', ['/d /s /c', `"start "${title}" /D "${pr.path}" cmd.exe /K"`], {
      detached: true, windowsVerbatimArguments: true, stdio: 'ignore', env: childEnv(mailEnv(pr), pr)
    }).unref();
    return true;
  },
  openEditor: p => { exec(`code "${p}"`, { windowsHide: true }, err => { if (err) openFolder(p); }); },
  addRoot: async () => {
    const dir = await pickFolder();
    if (!dir) return snapshot();
    if (detectProject(dir)) { if (!config.extraProjects.includes(dir)) config.extraProjects.push(dir); }
    else if (!config.extraRoots.includes(dir)) config.extraRoots.push(dir);
    saveConfig(); scanAll(); refreshExternal(); return snapshot();
  },
  // Recherche de projets sur tout le PC (dossier personnel, autres disques) : résultats diffusés au fil de l'eau.
  searchPC: () => {
    if (pcSearch && pcSearch.running) return { running: true };
    pcSearch = { running: true, cancelled: false };
    const skip = [...env.servers.map(x => x.base), ...env.servers.map(x => x.root), ...config.extraRoots, DATA_DIR, path.dirname(__dirname)].filter(Boolean);
    searchProjects({
      skip, known: projects.map(p => p.path),
      cancelled: () => pcSearch.cancelled,
      onProgress: pr => send('pc-search', { kind: 'progress', ...pr }),
      onFound: p => send('pc-search', { kind: 'found', project: { path: p.path, name: p.name, type: p.type, label: p.label } })
    }).then(r => {
      pcSearch.running = false;
      send('pc-search', { kind: 'done', visited: r.visited, ms: r.ms, truncated: r.truncated, cancelled: r.cancelled, count: r.found.length });
    }).catch(err => { pcSearch.running = false; send('pc-search', { kind: 'done', error: err.message }); });
    return { running: true };
  },
  cancelSearchPC: () => { if (pcSearch) pcSearch.cancelled = true; return true; },
  // Ajoute à la liste les projets choisis dans les résultats de la recherche.
  addProjects: paths => {
    let added = 0;
    for (const dir of Array.isArray(paths) ? paths : []) {
      if (!fs.existsSync(dir) || !detectProject(dir)) continue;
      const lc = dir.toLowerCase();
      if (config.extraProjects.some(d => d.toLowerCase() === lc) || projects.some(p => p.path.toLowerCase() === lc)) continue;
      config.extraProjects.push(dir);
      config.ignoredDiscovered = config.ignoredDiscovered.filter(d => d.toLowerCase() !== lc);
      added++;
    }
    saveConfig(); scanAll(); refreshExternal();
    return { ...snapshot(), added };
  },
  // Retire de la liste un projet ajouté ou détecté hors des serveurs (les fichiers ne sont pas touchés).
  forgetProject: p => {
    const lc = String(p).toLowerCase();
    const was = config.discoveredProjects.some(d => d.toLowerCase() === lc);
    config.extraProjects = config.extraProjects.filter(d => d.toLowerCase() !== lc);
    config.discoveredProjects = config.discoveredProjects.filter(d => d.toLowerCase() !== lc);
    if (was && !config.ignoredDiscovered.some(d => d.toLowerCase() === lc)) config.ignoredDiscovered.push(p);
    saveConfig(); scanAll(); return snapshot();
  },
  // Projet retiré auparavant : peut de nouveau être détecté automatiquement.
  allowDiscovery: p => { config.ignoredDiscovered = config.ignoredDiscovered.filter(d => d.toLowerCase() !== String(p).toLowerCase()); saveConfig(); return true; },
  removeRoot: dir => {
    config.extraRoots = config.extraRoots.filter(r => r !== dir);
    saveConfig(); scanAll(); return snapshot();
  },
  services: () => services(),
  startService: (name, base) => startService(name, base),

  // Nouveau projet
  createInfo: () => {
    const req = creator.requirements(env.tools);
    const types = creator.catalog(env.tools);
    const destinations = [
      ...env.servers.filter(s => s.root && fs.existsSync(s.root)).map(s => ({ path: s.root, label: `${s.type} (${s.root})`, server: true })),
      ...config.extraRoots.filter(r => fs.existsSync(r)).map(r => ({ path: r, label: r, server: false }))
    ];
    return { types, destinations, requirements: req, state: snapshotCreation() };
  },
  createProject: opts => createProject(opts || {}),
  // Récapitulatif avant création : dossier, version, PHP utilisé, port et étapes, en clair.
  createPreview: async opts => {
    const p = await prepareCreate(opts || {}, true);
    return { dir: p.dir, port: p.port, version: p.version.label, eol: !!p.version.eol, php: p.php ? { version: p.php.version, tested: p.php.tested } : null, steps: p.steps.map(s => s.label) };
  },
  createState: () => ({ state: snapshotCreation(), log: creation ? creation.log : '' }),
  createCancel: async () => {
    if (!creation || !creation.running) return false;
    creation.cancelled = true;
    if (creation.child) await killTree(creation.child);
    return true;
  },
  createPickFolder: () => pickFolder('Choisis le dossier dans lequel créer le projet'),
  createExists: (parent, name) => !!(parent && name && fs.existsSync(path.join(parent, String(name)))),

  // Maintenance du serveur local
  serverDiagnose: async () => {
    const all = await maint.diagnoseAll(env.servers);
    // Pour chaque base abîmée : les projets Laravel qui l'utilisent (DB_DATABASE du .env), pour proposer de la recréer.
    for (const d of all) {
      for (const issue of (d.mysql ? d.mysql.issues : []).filter(i => i.fix === 'orphan')) {
        for (const b of issue.databases) {
          b.projects = projects.filter(p => p.type === 'laravel' && String(db.readEnv(p).values.DB_DATABASE || '').toLowerCase() === b.name.toLowerCase())
            .map(p => ({ path: p.path, name: p.name, rel: p.rel }));
        }
      }
    }
    return all;
  },
  serverStop: async (base, name, opts = {}) => {
    const s = serverByBase(base);
    const r = name === 'mysql' ? await maint.stopMysql(s, opts) : await maint.stopApache(s);
    send('services', await services());
    return r;
  },
  serverRepair: async (base, kind) => {
    const s = serverByBase(base);
    const r = kind === 'aria' ? await maint.repairAria(s) : kind === 'restore-system' ? await maint.restoreSystem(s) : null;
    if (!r) throw new Error('Réparation inconnue.');
    send('services', await services());
    return r;
  },
  // Arrête le programme qui occupe un port (uniquement un processus qui écoute réellement sur ce port).
  killPortOwner: async port => {
    const o = await maint.portOwner(Number(port));
    if (!o) return { ok: true, message: 'Le port est déjà libre.' };
    if (o.system || o.pid <= 4) throw new Error('Ce port est utilisé par Windows lui-même : change plutôt le port d\'Apache.');
    const ok = await maint.killPid(o.pid);
    await new Promise(r => setTimeout(r, 800));
    send('services', await services());
    return { ok, message: ok ? `${o.name} (PID ${o.pid}) arrêté.` : `Impossible d'arrêter ${o.name} : lance DevLauncher en administrateur ou ferme-le toi-même.` };
  },
  setApachePorts: (base, http, https) => maint.setApachePorts(serverByBase(base), Number(http), https ? Number(https) : undefined),
  serverLog: (base, which) => {
    const s = serverByBase(base);
    const file = which === 'mysql' ? (maint.mysqlConfig(s) || {}).log : (maint.apacheConfig(s) || {}).log;
    return { file, text: maint.readTail(file, 300000) };
  },
  openServerFile: (base, which) => {
    const s = serverByBase(base);
    const file = which === 'my.ini' ? s.myini : which === 'httpd.conf' ? (maint.apacheConfig(s) || {}).conf
      : which === 'mysql-log' ? (maint.mysqlConfig(s) || {}).log : (maint.apacheConfig(s) || {}).log;
    return api.openFile(file);
  },

  // Sauvegardes
  backupInfo: () => ({ dir: backupDir(), running: backupRunning, list: backup.list(backupDir()) }),
  backupDatabases: (base, creds) => backup.listDatabases(serverByBase(base), creds),
  backupCreate: (base, opts = {}) => runBackup(serverByBase(base), {
    type: opts.type === 'raw' ? 'raw' : 'dump', databases: opts.databases || null, config: opts.config !== false, label: String(opts.label || ''), creds: opts.creds || {}
  }),
  backupRestore: (base, name, dbName, target, creds) => backup.restore(serverByBase(base), backupDir(), name, dbName, target || dbName, creds || {}, p => send('backup', { ...p, restore: true })),
  backupDelete: name => backup.remove(backupDir(), name),
  openBackupFolder: () => { fs.mkdirSync(backupDir(), { recursive: true }); openFolder(backupDir()); return true; },
  pickBackupFolder: async () => {
    const dir = await pickFolder();
    if (dir) { config.settings.backupDir = dir; saveConfig(); }
    return backupDir();
  },

  // Paramètres généraux
  setSettings: async patch => {
    const before = settings();
    const allowed = Object.keys(DEFAULT_SETTINGS);
    for (const k of Object.keys(patch)) if (!allowed.includes(k)) delete patch[k];
    if (patch.smtpPort !== undefined) {
      patch.smtpPort = Number(patch.smtpPort);
      if (!Number.isInteger(patch.smtpPort) || patch.smtpPort < 1024 || patch.smtpPort > 65535) throw new Error('Port SMTP invalide (1024 à 65535).');
    }
    const previous = config.settings;
    config.settings = { ...config.settings, ...patch };
    // L'inscription au démarrage de Windows est réécrite avec les nouveaux réglages (mode fenêtre / arrière-plan).
    const autostartChanged = patch.autostartWindows !== undefined && patch.autostartWindows !== before.autostartWindows;
    const modeChanged = patch.autostartShow !== undefined && patch.autostartShow !== before.autostartShow && settings().autostartWindows;
    if (autostartChanged || modeChanged) {
      try { await setWindowsAutostart(settings().autostartWindows); } catch (err) { config.settings = previous; throw err; }
    }
    saveConfig();
    if (patch.smtpPort !== undefined && patch.smtpPort !== before.smtpPort) await startMailCatcher();
    return snapshot();
  },

  // Logs et erreurs
  logFiles: p => { const pr = getProject(p); return pr ? logs.listLogs(pr) : []; },
  readLog: (p, file) => {
    const pr = getProject(p);
    const f = pr && logs.listLogs(pr).find(x => x.path === file);
    if (!f) throw new Error('Fichier de log introuvable.');
    const { text, truncated, size } = logs.readTail(f.path);
    if (pr.type === 'laravel') {
      const entries = logs.parseLaravelLog(text).slice(-800).map(e => ({ ...e, body: e.body.slice(0, 12000) }));
      return { file: f, truncated, size, entries };
    }
    return { file: f, truncated, size, text: text.slice(-400000) };
  },
  clearLog: (p, file) => {
    const pr = getProject(p);
    const f = pr && logs.listLogs(pr).find(x => x.path === file);
    if (!f) throw new Error('Fichier de log introuvable.');
    fs.truncateSync(f.path, 0);
    return true;
  },
  errors: p => {
    const pr = getProject(p);
    if (!pr) return { items: [] };
    const items = [];
    if (pr.type === 'laravel') {
      const f = logs.listLogs(pr)[0];
      if (f) items.push(...logs.laravelErrors(pr, logs.parseLaravelLog(logs.readTail(f.path).text)).map(e => ({ ...e, logFile: f.name })));
    }
    items.unshift(...logs.consoleErrors(pr, consoleBuf.get(pr.path) || ''));
    return { items: items.slice(0, 80) };
  },
  clearConsole: p => { consoleBuf.delete(p); return true; },
  openFile: (file, line) => {
    if (!file || !fs.existsSync(file) || fs.statSync(file).isDirectory()) throw new Error('Fichier introuvable.');
    const target = line ? `${file}:${line}` : file;
    exec(`code -g "${target}"`, { windowsHide: true }, err => {
      if (err) spawn('cmd.exe', ['/c', 'start', '""', file], { windowsHide: true, detached: true }).unref();
    });
    return true;
  },

  // Base de données du projet
  dbInfo: async p => {
    const pr = getProject(p);
    if (!pr) throw new Error('Projet introuvable.');
    const r = await db.info(pr, env.servers);
    const pma = env.servers.find(s => s.phpmyadmin);
    r.phpmyadmin = pma ? { available: true, apache: await isPortOpen(80) } : { available: false };
    r.mysqlRunning = await isPortOpen(Number(r.conn.port) || 3306);
    return r;
  },
  dbTest: (p, values) => db.test(getProject(p), env.servers, values),
  dbSaveEnv: (p, values) => {
    const pr = getProject(p);
    const map = { connection: 'DB_CONNECTION', host: 'DB_HOST', port: 'DB_PORT', database: 'DB_DATABASE', username: 'DB_USERNAME', password: 'DB_PASSWORD' };
    const patch = {};
    for (const [k, v] of Object.entries(values || {})) if (map[k] && v !== undefined && v !== null) patch[map[k]] = String(v);
    if (!Object.keys(patch).length) throw new Error('Aucune valeur à enregistrer.');
    db.writeEnv(pr, patch);
    pr.hasEnv = true;
    return { ok: true, keys: Object.keys(patch) };
  },
  dbCreate: async (p, opts) => {
    const pr = getProject(p);
    const r = await db.create(pr, env.servers, opts);
    // Enregistre la nouvelle base (et l'utilisateur dédié) dans le .env si demandé.
    if (opts.writeEnv) {
      const patch = { DB_DATABASE: opts.name };
      if (opts.user) { patch.DB_USERNAME = opts.user.username; patch.DB_PASSWORD = opts.user.password || ''; }
      if (db.connFromEnv(db.readEnv(pr).values).connection !== 'sqlite') db.writeEnv(pr, patch);
    }
    return r;
  },
  openPhpMyAdmin: async database => {
    if (!(await isPortOpen(80))) await startService('apache');
    openExternal(`http://localhost/phpmyadmin/${database ? `index.php?route=/database/structure&db=${encodeURIComponent(database)}` : ''}`);
    return true;
  },

  // Seeders Laravel : liste, code, exécution d'une sélection dans l'ordre choisi
  seedersList: async p => {
    const pr = getProject(p);
    if (!pr || pr.type !== 'laravel') throw new Error('Disponible pour les projets Laravel.');
    return { ...seeders.list(pr), running: procs.has(`${pr.path}|action`) }; // serveur MySQL vérifié au lancement
  },
  seederRead: (p, file) => seeders.read(getProject(p), file),
  seedRun: async (p, classes, opts = {}) => {
    const pr = getProject(p);
    if (!pr || pr.type !== 'laravel') throw new Error('Disponible pour les projets Laravel.');
    if (procs.has(`${pr.path}|action`)) throw new Error('Une action est déjà en cours pour ce projet : attends sa fin.');
    const known = new Map(seeders.list(pr).seeders.map(x => [x.class, x]));
    const list = (Array.isArray(classes) ? classes : []).filter(c => known.has(c));
    if (!list.length) throw new Error('Aucun seeder sélectionné.');
    // Même garde-fou que les migrations : jamais vers le MySQL d'un autre serveur sans confirmation.
    if (!opts.force) {
      const t = await dbTarget(pr);
      if (t.applicable && !t.match) return { blocked: true, target: t };
    }
    const php = `"${pr.php || env.tools.php || 'php'}"`;
    (async () => {
      send('seed', { path: pr.path, running: true, list });
      for (let i = 0; i < list.length; i++) {
        const cls = known.get(list[i]);
        send('seed', { path: pr.path, step: i, state: 'run', class: cls.class });
        const code = await run(pr, 'action', `${php} artisan db:seed --class="${cls.fqcn}" --force`).done;
        send('seed', { path: pr.path, step: i, state: code === 0 ? 'ok' : 'error', class: cls.class, code });
        if (code !== 0) { send('seed', { path: pr.path, running: false, ok: false, failedAt: i }); return; }
      }
      send('seed', { path: pr.path, running: false, ok: true });
    })();
    return { started: true, list };
  },

  // File d'attente Laravel (e-mails, notifications, tâches)
  queueInfo: async p => {
    const pr = getProject(p);
    if (!pr || pr.type !== 'laravel') throw new Error('Disponible pour les projets Laravel.');
    const [info, target] = await Promise.all([queue.info(pr, env.servers), dbTarget(pr)]);
    return { ...info, worker: procs.has(`${pr.path}|worker`), autoWorker: !!(config.projects[pr.path] || {}).queueWorker, target, running: isManaged(pr.path), mailCapture: settings().mailCapture && (config.projects[pr.path] || {}).mailCapture !== false };
  },
  queueRun: async (p, what, arg, opts = {}) => {
    const pr = getProject(p);
    if (!pr || pr.type !== 'laravel') throw new Error('Disponible pour les projets Laravel.');
    // Toute opération sur la file touche la base : jamais sur le MySQL d'un autre serveur sans confirmation
    if (!opts.force) { const t = await dbTarget(pr); if (t.applicable && !t.match) return { blocked: true, target: t }; }
    const php = `"${pr.php || env.tools.php || 'php'}"`;
    const id = String(arg || '').replace(/[^\w-]/g, '');
    const info = what === 'process' ? await queue.info(pr, env.servers) : null;
    const cmds = {
      process: `${php} artisan queue:work --stop-when-empty --tries=1${info && info.queues.length ? ` --queue=${info.queues.join(',')}` : ''}`,
      retry: `${php} artisan queue:retry ${id || 'all'}`,
      forget: id ? `${php} artisan queue:forget ${id}` : `${php} artisan queue:flush`
    };
    // Table de file : création de la migration (Laravel 11+ : make:queue-table ; avant : queue:table),
    // puis exécution de CETTE migration seulement (pas les autres migrations en attente du projet).
    if (what === 'createTable') {
      if (procs.has(`${pr.path}|queue`)) throw new Error('Une opération sur la file est déjà en cours.');
      send('queue', { path: pr.path, running: true, what });
      const dir = path.join(pr.path, 'database', 'migrations');
      const findJobsMigration = () => { try { return fs.readdirSync(dir).filter(f => /create_jobs_table\.php$/.test(f)).sort().pop() || null; } catch { return null; } };
      let file = findJobsMigration();
      let code = 0;
      if (!file) { code = await run(pr, 'queue', `${php} artisan make:queue-table || ${php} artisan queue:table`).done; file = findJobsMigration(); }
      if (file) code = await run(pr, 'queue', `${php} artisan migrate --force --path=database/migrations/${file}`).done;
      send('queue', { path: pr.path, running: false, what, code });
      return { ok: !!file && code === 0, code, message: file ? `Table créée (migration ${file}).` : 'La migration de la table n\'a pas pu être créée.' };
    }
    if (what === 'deletePending') { await queue.deletePending(pr, env.servers, arg === 'all' ? 'all' : [].concat(arg)); return { ok: true }; }
    if (what === 'enable') {
      db.writeEnv(pr, { QUEUE_CONNECTION: 'database' });
      return { ok: true, message: 'QUEUE_CONNECTION=database enregistré dans le .env.' };
    }
    if (!cmds[what]) throw new Error('Opération inconnue.');
    if (procs.has(`${pr.path}|queue`)) throw new Error('Une opération sur la file est déjà en cours.');
    send('queue', { path: pr.path, running: true, what });
    const code = await run(pr, 'queue', cmds[what]).done;
    send('queue', { path: pr.path, running: false, what, code });
    return { ok: code === 0, code };
  },
  queueWorker: async (p, on, opts = {}) => {
    const pr = getProject(p);
    if (!pr) throw new Error('Projet introuvable.');
    if (opts.auto !== undefined) { config.projects[pr.path] = { ...config.projects[pr.path], queueWorker: !!opts.auto }; saveConfig(); }
    const key = `${pr.path}|worker`;
    if (!on) { if (procs.has(key)) await killTree(procs.get(key)); return { worker: false }; }
    if (procs.has(key)) return { worker: true };
    if (!opts.force) { const t = await dbTarget(pr); if (t.applicable && !t.match) return { blocked: true, target: t }; }
    startQueueWorker(pr);
    return { worker: true };
  },

  // Diagrammes UML (fichiers .puml dans docs/uml du projet)
  umlList: p => uml.list(getProject(p)),
  umlRead: (p, name) => uml.readDiagram(getProject(p), name),
  umlSave: (p, name, text) => uml.save(getProject(p), name, text),
  umlDelete: (p, name) => uml.remove(getProject(p), name),
  umlSources: p => uml.sources(getProject(p)),
  umlRoutes: p => uml.routes(getProject(p)),
  umlFiles: p => uml.sourceFiles(getProject(p)),
  umlFunctions: (p, file) => uml.functions(getProject(p), file),
  umlGenerate: (p, kind, opts = {}) => {
    const pr = getProject(p);
    if (kind === 'class') return uml.generateClass(pr, opts);
    // lang : 'human' (langage courant, par défaut) ou 'tech' (noms de méthodes, routes, contrôleurs)
    if (kind === 'sequence') return uml.generateSequence(pr, opts.route, opts.lang);
    if (kind === 'activity') return uml.generateActivity(pr, opts.file, opts.fn, opts.lang);
    throw new Error('Type de diagramme inconnu.');
  },
  umlActions: p => uml.actions(getProject(p)),
  // Plusieurs diagrammes d'un coup ; les fonctions des fichiers choisis sont développées ici.
  umlGenerateBatch: (p, jobs, opts = {}) => {
    const pr = getProject(p);
    const expanded = [];
    for (const j of jobs || []) {
      if (j.kind === 'activity-file') {
        for (const f of uml.functions(pr, j.file).filter(f => f.name !== '__construct' && f.name !== 'constructor')) expanded.push({ kind: 'activity', file: j.file, fn: f.name });
      } else expanded.push(j);
    }
    if (expanded.length > 1000) throw new Error(`${expanded.length} diagrammes demandés : limite de 1000 par lot.`);
    return uml.generateBatch(pr, expanded, { overwrite: !!opts.overwrite, onProgress: s => send('uml-batch', { path: p, ...s }) });
  },
  umlExport: async (p, name, format, data) => {
    const pr = getProject(p);
    return format === 'pdf' ? uml.exportPdf(pr, name, data.svg, data.width, data.height, findBrowser()) : uml.exportPng(pr, name, data.png);
  },
  umlOpenFolder: p => { const dir = uml.umlDir(getProject(p)); fs.mkdirSync(dir, { recursive: true }); openFolder(dir); return true; },
  umlOpenFile: (p, name, ext) => {
    const file = path.join(uml.umlDir(getProject(p)), String(name).replace(/[<>:"/\\|?*]/g, '') + '.' + (ext === 'pdf' ? 'pdf' : 'png'));
    if (!fs.existsSync(file)) throw new Error('Fichier introuvable : exporte-le d\'abord.');
    spawn('cmd.exe', ['/c', 'start', '""', file], { windowsHide: true, detached: true }).unref();
    return true;
  },

  // Boîte de test des mails
  mails: () => mailStore.mails.map(m => {
    const s = mailStore.summary(m);
    const p = s.project && getProject(s.project);
    return { ...s, projectName: p ? p.name : null };
  }),
  mail: id => {
    const m = mailStore.get(id);
    if (!m) throw new Error('Mail introuvable.');
    mailStore.markRead(id);
    const p = m.project && getProject(m.project);
    return { ...mailStore.detail(m), projectName: p ? p.name : null };
  },
  deleteMail: id => { mailStore.remove(id); return true; },
  clearMails: () => { mailStore.clear(); return true; },
  sendSampleMail: () => sendSampleMail(),
  quitApp: () => { setTimeout(shutdown, 100); return true; },
  // Vérifie un port avant de l'attribuer : déjà donné à un autre projet ? occupé par un programme ?
  portInfo: async (projectPath, port) => {
    port = Number(port);
    if (!Number.isInteger(port) || port < 1 || port > 65535) return { ok: false, reason: 'Port invalide (1 à 65535).' };
    const other = projects.find(p => p.path !== projectPath &&
      (config.projects[p.path].port === port || (config.projects[p.path].withVite && config.projects[p.path].vitePort === port)));
    if (other) return { ok: false, reason: `Déjà attribué au projet « ${other.name} ».` };
    const mine = config.projects[projectPath];
    const ownBusy = isManaged(projectPath) && mine && (mine.port === port || mine.vitePort === port);
    if (!ownBusy && await isPortOpen(port)) {
      await refreshExternal(true);
      return { ok: false, busy: true, reason: `Occupé par ${describePortOwner(port)}.` };
    }
    if (port < 1024) return { ok: true, warn: 'Les ports inférieurs à 1024 sont souvent réservés au système.' };
    return { ok: true };
  },
  suggestPort: async (projectPath, from) => {
    const used = new Set(Object.entries(config.projects).filter(([p]) => p !== projectPath).flatMap(([, c]) => [c.port, c.vitePort]));
    for (let port = Number(from) || 8000; port < 65535; port++) {
      if (!used.has(port) && !(await isPortOpen(port))) return port;
    }
    return null;
  },
  // Utilisé par l'installateur pour fermer l'application avant une mise à jour ou une désinstallation.
  quit: () => { setTimeout(shutdown, 100); return true; }
};

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.ico': 'image/x-icon', '.png': 'image/png', '.svg': 'image/svg+xml' };

function readBody(req) {
  return new Promise(resolve => {
    let body = '';
    req.on('data', c => { body += c; });
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch { resolve({}); } });
  });
}

let lastClientAt = Date.now();
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${UI_PORT}`);
  // Refuse les requêtes venant d'autres sites ouverts dans le navigateur.
  const origin = req.headers.origin;
  if (origin && origin !== `http://127.0.0.1:${UI_PORT}`) { res.writeHead(403); return res.end(); }
  if (req.headers.host !== `127.0.0.1:${UI_PORT}`) { res.writeHead(403); return res.end(); }

  if (url.pathname === '/api/ping') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ app: 'devlauncher' }));
  }
  if (url.pathname === '/api/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write('retry: 1000\n\n');
    clients.add(res);
    req.on('close', () => { clients.delete(res); lastClientAt = Date.now(); });
    return;
  }
  if (url.pathname.startsWith('/api/') && req.method === 'POST') {
    const fn = api[url.pathname.slice(5)];
    if (!fn) { res.writeHead(404); return res.end(); }
    const { args = [] } = await readBody(req);
    try {
      const result = await fn(...args);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result === undefined ? null : result));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }
  // Mails capturés : aperçu HTML, images intégrées (cid:), pièces jointes, source .eml
  const mm = url.pathname.match(/^\/mail\/([\w-]+)\/(html|text|eml|cid|att|view)(?:\/(.+))?$/);
  if (mm) return serveMail(res, mm[1], mm[2], mm[3] ? decodeURIComponent(mm[3]) : null);

  // Guide d'utilisation, affiché dans l'application (onglet Aide). Installé à côté du dossier app ; docs/ en développement.
  if (url.pathname === '/guide') {
    const guide = [path.join(__dirname, '..', 'Guide-DevLauncher.html'), path.join(__dirname, '..', 'docs', 'Guide-DevLauncher.html')].find(f => fs.existsSync(f));
    if (!guide) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Guide introuvable.'); }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return fs.createReadStream(guide).pipe(res);
  }

  // Fichiers de l'interface
  const file = path.normalize(path.join(UI_DIR, url.pathname === '/' ? 'index.html' : url.pathname));
  if (!file.startsWith(UI_DIR) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  fs.createReadStream(file).pipe(res);
});

const escHtml = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const TEXT_EXT = /\.(txt|csv|tsv|json|xml|log|md|ics|vcf|html?|css|js|sql|yml|yaml|ini|env)$/i;
const IMG_TYPES = /^image\/(png|jpe?g|gif|webp|bmp|svg\+xml|x-icon)$/i;
// Type sûr pour l'aperçu d'une pièce jointe, ou null si le format ne se prévisualise pas (docx, zip...).
function viewType(a) {
  const ct = String(a.contentType || '').toLowerCase();
  if (IMG_TYPES.test(ct) && ct !== 'image/svg+xml') return ct;
  if (ct === 'application/pdf' || /\.pdf$/i.test(a.filename)) return 'application/pdf';
  if (/\.(png|jpe?g|gif|webp|bmp)$/i.test(a.filename)) return 'image/' + a.filename.split('.').pop().toLowerCase().replace('jpg', 'jpeg');
  // HTML et SVG sont montrés comme du texte : leur code n'est jamais exécuté.
  if (ct.startsWith('text/') || ct === 'image/svg+xml' || /json|xml|csv|calendar|vcard|javascript/.test(ct) || TEXT_EXT.test(a.filename)) return 'text/plain; charset=utf-8';
  return null;
}

function serveMail(res, id, kind, extra) {
  const m = mailStore.get(id);
  if (!m) { res.writeHead(404); return res.end(); }
  // Le contenu d'un mail n'exécute aucun script ; images et polices externes autorisées pour un rendu fidèle.
  const csp = "default-src 'none'; img-src * data: blob:; style-src 'unsafe-inline' *; font-src * data:; base-uri 'none'; form-action 'none'";
  if (kind === 'html' || kind === 'text') {
    let body;
    if (kind === 'html' && m.html != null) {
      body = m.html.replace(/(["'(])cid:([^"')]+)/gi, (_, q, cid) => `${q}/mail/${id}/cid/${encodeURIComponent(cid)}`);
      // Liens ouverts hors de la fenêtre d'aperçu
      if (!/<base\s/i.test(body)) body = /<head[\s>]/i.test(body) ? body.replace(/<head([^>]*)>/i, '<head$1><base target="_blank">') : '<base target="_blank">' + body;
      if (!/<meta[^>]+charset/i.test(body)) body = '<meta charset="utf-8">' + body;
    } else {
      body = `<!doctype html><meta charset="utf-8"><body style="margin:0;padding:16px;font:13px/1.6 Consolas,monospace;white-space:pre-wrap;word-break:break-word;color:#1d2125">${escHtml(m.text || '(mail sans contenu texte)')}</body>`;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': csp, 'Cache-Control': 'no-store' });
    return res.end(body);
  }
  if (kind === 'eml') {
    res.writeHead(200, { 'Content-Type': 'message/rfc822', 'Content-Disposition': `attachment; filename="mail-${id}.eml"` });
    return res.end(m.raw);
  }
  const a = kind === 'cid' ? m.attachments.find(x => x.cid === extra) : m.attachments[Number(extra)];
  if (!a) { res.writeHead(404); return res.end(); }
  // Affichage dans l'application (sans téléchargement) : images et PDF tels quels, formats texte en texte brut.
  if (kind === 'view') {
    const type = viewType(a);
    if (!type) { res.writeHead(415); return res.end(); }
    const h = { 'Content-Type': type, 'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(a.filename)}`, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store' };
    if (type !== 'application/pdf') h['Content-Security-Policy'] = "default-src 'none'; img-src data:; style-src 'unsafe-inline'";
    res.writeHead(200, h);
    return res.end(a.data);
  }
  const headers = { 'Content-Type': a.contentType || 'application/octet-stream', 'Content-Security-Policy': "default-src 'none'; img-src data:; style-src 'unsafe-inline'", 'X-Content-Type-Options': 'nosniff' };
  if (kind === 'att') headers['Content-Disposition'] = `attachment; filename*=UTF-8''${encodeURIComponent(a.filename)}`;
  res.writeHead(200, headers);
  res.end(a.data);
}

// ---------- Fenêtre de l'application ----------
function findBrowser() {
  const pf = [process.env['ProgramFiles(x86)'], process.env.ProgramFiles, process.env.LOCALAPPDATA].filter(Boolean);
  const rel = [
    ['Microsoft', 'Edge', 'Application', 'msedge.exe'],
    ['Google', 'Chrome', 'Application', 'chrome.exe'],
    ['BraveSoftware', 'Brave-Browser', 'Application', 'brave.exe']
  ];
  for (const r of rel) for (const base of pf) {
    const p = path.join(base, ...r);
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function openWindow() {
  const url = `http://127.0.0.1:${UI_PORT}/`;
  const browser = findBrowser();
  if (!browser) return openExternal(url);
  const profile = path.join(DATA_DIR, 'window');
  spawn(browser, [
    `--app=${url}`, `--user-data-dir=${profile}`, '--window-size=1280,820',
    '--no-first-run', '--no-default-browser-check', '--disable-features=Translate'
  ], { detached: true, stdio: 'ignore' }).unref();
}

// Une seule instance : si DevLauncher tourne déjà, on rouvre simplement sa fenêtre.
function alreadyRunning() {
  return new Promise(resolve => {
    const req = http.get(`http://127.0.0.1:${UI_PORT}/api/ping`, { timeout: 1500 }, res => {
      let body = '';
      res.on('data', c => { body += c; });
      res.on('end', () => resolve(body.includes('devlauncher')));
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

let quitting = false;
async function shutdown(reason = 'fermeture') {
  if (quitting) return;
  quitting = true;
  journal(`Arrêt (${typeof reason === 'string' ? reason : 'signal système'})`);
  await Promise.all([...procs.values()].map(killTree));
  process.exit(0);
}

async function main() {
  if (await alreadyRunning()) { if (!BACKGROUND) openWindow(); return; }
  loadConfig();
  journal(`Démarrage de DevLauncher ${VERSION}${BACKGROUND ? ' (avec Windows, en arrière-plan)' : STARTUP ? ' (avec Windows)' : ''}`);
  // L'inscription au démarrage de Windows suit l'emplacement actuel du programme et le mode choisi.
  if (settings().autostartWindows && process.env.DEVLAUNCHER_EXE) setWindowsAutostart(true).catch(err => journal(`Inscription au démarrage : ${err.message}`));
  // Port occupé au démarrage de Windows (réservé un instant par un autre programme) : nouvelles tentatives pendant 2 minutes.
  let attempts = 0;
  server.on('error', async err => {
    journal(`Port ${UI_PORT} indisponible : ${err.code || err.message}`);
    if (await alreadyRunning()) { journal('Une autre fenêtre DevLauncher est déjà active : arrêt de celle-ci.'); if (!BACKGROUND) openWindow(); process.exit(0); }
    if (++attempts > 24) { journal('Abandon : le port est resté indisponible.'); process.exit(1); }
    setTimeout(() => server.listen(UI_PORT, '127.0.0.1'), 5000);
  });
  server.on('listening', () => {
    console.log(`DevLauncher ${VERSION} : http://127.0.0.1:${UI_PORT}/`);
    journal(`Interface prête sur le port ${UI_PORT}`);
    if (!NO_WINDOW) openWindow();
  });
  server.listen(UI_PORT, '127.0.0.1');
  ready = bootstrap().catch(err => { console.error(err); journal(`Démarrage incomplet : ${err.message}`); });
  setInterval(refreshExternal, 8000);
  // Fenêtre fermée (plus aucune interface connectée depuis 8 s) : on arrête les serveurs lancés et on quitte,
  // sauf si DevLauncher doit rester actif en arrière-plan (paramètre, ou démarrage avec Windows).
  setInterval(() => {
    if (NO_WINDOW || settings().keepRunning) return;
    if (clients.size === 0 && Date.now() - lastClientAt > 8000) shutdown('fenêtre fermée');
  }, 2000);
  lastClientAt = Date.now() + 30000; // laisse le temps à la fenêtre de s'ouvrir
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main();
