// Lecture des fichiers de log et interprétation des erreurs (fichiers concernés + explication).
const fs = require('fs');
const path = require('path');

const MAX_READ = 2 * 1024 * 1024; // on lit au plus les 2 derniers Mo d'un log

// ---------- Fichiers de log ----------
function logDirs(project) {
  if (project.type === 'laravel') return [path.join(project.path, 'storage', 'logs')];
  return [project.path, path.join(project.path, 'logs')];
}

function listLogs(project) {
  const files = [];
  for (const dir of logDirs(project)) {
    let names = [];
    try { names = fs.readdirSync(dir); } catch { continue; }
    for (const n of names) {
      if (!/\.log$/i.test(n)) continue;
      const full = path.join(dir, n);
      try {
        const st = fs.statSync(full);
        if (st.isFile()) files.push({ path: full, name: path.relative(project.path, full), size: st.size, mtime: st.mtimeMs });
      } catch { /* fichier inaccessible */ }
    }
  }
  return files.sort((a, b) => b.mtime - a.mtime);
}

function readTail(file) {
  const st = fs.statSync(file);
  const start = Math.max(0, st.size - MAX_READ);
  const fd = fs.openSync(file, 'r');
  try {
    const buf = Buffer.alloc(st.size - start);
    fs.readSync(fd, buf, 0, buf.length, start);
    let text = buf.toString('utf8');
    if (start > 0) text = text.slice(text.indexOf('\n') + 1); // première ligne coupée
    return { text, truncated: start > 0, size: st.size };
  } finally { fs.closeSync(fd); }
}

// ---------- Explications des erreurs courantes ----------
const HINTS = [
  { re: /SQLSTATE\[HY000\] \[2002\]|Connection refused.*3306|No connection could be made/i, title: 'MySQL ne répond pas', fix: 'Le serveur MySQL est arrêté ou DB_HOST/DB_PORT du .env est faux. Démarre MySQL depuis la barre d\'état.', action: 'mysql' },
  { re: /SQLSTATE\[HY000\] \[1049\]|Unknown database '([^']+)'/i, title: 'Base de données inexistante', fix: 'La base indiquée dans DB_DATABASE (.env) n\'existe pas. Crée-la dans phpMyAdmin puis lance « Migrer ».' },
  { re: /SQLSTATE\[HY000\] \[1045\]|Access denied for user/i, title: 'Identifiants MySQL refusés', fix: 'DB_USERNAME ou DB_PASSWORD du .env ne correspondent pas à ton serveur MySQL (sous XAMPP : root sans mot de passe par défaut).' },
  { re: /\b1813\b|Tablespace for table .* exists/i, title: 'Table orpheline dans MySQL', fix: 'MySQL garde le fichier .ibd d\'une table supprimée. Supprime le fichier <table>.ibd dans le dossier mysql\\data\\<base> (MySQL arrêté), ou recrée la base dans phpMyAdmin.' },
  { re: /SQLSTATE\[42S02\]|Base table or view not found|doesn't exist \(Connection/i, title: 'Table manquante', fix: 'Une table attendue n\'existe pas : les migrations n\'ont pas été exécutées. Lance « Migrer ».', action: 'migrate' },
  { re: /SQLSTATE\[42S22\]|Unknown column/i, title: 'Colonne inconnue', fix: 'Le code utilise une colonne absente de la table. Vérifie les migrations en attente (« État des migrations ») ou le nom de la colonne.', action: 'status' },
  { re: /SQLSTATE\[23000\].*(Duplicate entry|Integrity constraint)/i, title: 'Contrainte d\'intégrité', fix: 'Doublon sur une clé unique ou clé étrangère invalide. Vérifie les données insérées (seeders, formulaire).' },
  { re: /No application encryption key/i, title: 'Clé d\'application absente', fix: 'APP_KEY est vide dans le .env. Lance « Installer les dépendances » qui génère la clé.', action: 'install' },
  { re: /Vite manifest not found|Unable to locate file in Vite manifest/i, title: 'Assets Vite absents', fix: 'Les fichiers CSS/JS ne sont pas compilés. Active « Vite (assets) » et redémarre, ou lance « Compiler (build) ».' },
  { re: /vendor[\\/]autoload\.php.*(No such file|failed to open)|Failed opening required.*autoload\.php/i, title: 'Dépendances PHP absentes', fix: 'Le dossier vendor manque. Lance « Installer les dépendances ».', action: 'install' },
  { re: /Class "([^"]+)" not found|Class '([^']+)' not found/i, title: 'Classe introuvable', fix: 'Vérifie le namespace et le nom du fichier (sensible à la casse). Si la classe vient d\'un paquet, lance « Installer les dépendances ».' },
  { re: /Target class \[([^\]]+)\] does not exist/i, title: 'Contrôleur ou classe introuvable', fix: 'La route pointe vers une classe qui n\'existe pas. Vérifie le nom du contrôleur et son namespace dans routes/.' },
  { re: /Route \[([^\]]+)\] not defined/i, title: 'Route inconnue', fix: 'route(\'…\') utilise un nom de route qui n\'existe pas. Vérifie ->name(...) dans routes/web.php.' },
  { re: /View \[([^\]]+)\] not found/i, title: 'Vue Blade introuvable', fix: 'Le fichier de vue n\'existe pas dans resources/views. Vérifie le nom (points = sous-dossiers).' },
  { re: /Undefined variable \$(\w+)/i, title: 'Variable non définie', fix: 'Une variable est utilisée sans avoir été définie (souvent oubliée dans le compact()/with() de la vue).' },
  { re: /Call to undefined (method|function)/i, title: 'Méthode ou fonction inexistante', fix: 'Le nom est mal écrit ou la méthode n\'existe pas sur cet objet.' },
  { re: /Call to a member function \w+\(\) on null/i, title: 'Appel sur une valeur nulle', fix: 'Un objet attendu vaut null (enregistrement introuvable, relation vide...). Vérifie la requête ou utilise ?-> / findOrFail.' },
  { re: /Allowed memory size of \d+ bytes exhausted/i, title: 'Mémoire PHP épuisée', fix: 'Boucle infinie ou traitement trop lourd. Augmente memory_limit dans php.ini ou traite les données par lots (chunk).' },
  { re: /Maximum execution time of \d+ seconds exceeded/i, title: 'Temps d\'exécution dépassé', fix: 'Le script est trop long (boucle, requête lente, appel réseau). Optimise ou augmente max_execution_time.' },
  { re: /Your (requirements|lock file) could not be resolved|requires php [\^~>=]*[\d.]+ but your php version/i, title: 'Version de PHP incompatible', fix: 'Le projet demande une autre version de PHP. Installe-la (Laragon...) puis clique sur Actualiser : DevLauncher la choisira.' },
  { re: /EADDRINUSE|address already in use|Failed to listen on/i, title: 'Port déjà utilisé', fix: 'Un autre programme utilise ce port. Choisis un autre port pour ce projet.', action: 'port' },
  { re: /Cannot find module '([^']+)'|Module not found: (Error: )?Can't resolve '([^']+)'|Failed to resolve import "([^"]+)"/i, title: 'Module introuvable', fix: 'Un paquet ou un fichier importé est introuvable. Si c\'est un paquet npm, lance « Installer les dépendances » ; sinon vérifie le chemin de l\'import.', action: 'install' },
  { re: /is not recognized as an internal or external command|n'est pas reconnu en tant que commande/i, title: 'Outil introuvable', fix: 'La commande n\'est pas installée ou les dépendances manquent (node_modules). Lance « Installer les dépendances ».', action: 'install' },
  { re: /error TS\d+/i, title: 'Erreur TypeScript', fix: 'Erreur de typage dans le fichier indiqué. Corrige le type ou la valeur à la ligne signalée.' },
  { re: /SyntaxError|Parse ?error|syntax error|Unexpected token/i, title: 'Erreur de syntaxe', fix: 'Le fichier indiqué contient une faute de syntaxe (parenthèse, accolade, guillemet, point-virgule...) à la ligne signalée ou juste avant.' },
  { re: /TypeError|must be of type|Argument #\d+/i, title: 'Type de valeur incorrect', fix: 'Une fonction reçoit une valeur du mauvais type (ex. un nombre décimal au lieu d\'un entier, null au lieu d\'un objet). Convertis la valeur à la ligne indiquée.' },
  { re: /ENOENT/i, title: 'Fichier introuvable', fix: 'Un fichier ou dossier attendu n\'existe pas. Vérifie le chemin indiqué.' },
  { re: /Permission denied|EACCES|EPERM/i, title: 'Accès refusé', fix: 'Le fichier est verrouillé par un autre programme ou protégé. Ferme les programmes qui l\'utilisent puis réessaie.' },
  { re: /Connection could not be established with host|stream_socket_client|Expected response code "?(220|250)"?/i, title: 'Envoi de mail impossible', fix: 'Le serveur SMTP configuré ne répond pas. Active l\'interception des mails de DevLauncher pour ce projet et redémarre-le.' }
];

function hintFor(text) {
  for (const h of HINTS) if (h.re.test(text)) return { title: h.title, fix: h.fix, action: h.action || null };
  return null;
}

// ---------- Fichiers cités dans un texte ----------
// Rend un chemin absolu et vérifie qu'il existe ; marque les fichiers du projet (hors vendor / node_modules).
function fileRef(project, file, line, col) {
  let p = file.replace(/^file:\/\/\/?/, '').replace(/\//g, '\\').replace(/^\.\\/, '');
  if (!/^[A-Za-z]:\\/.test(p)) p = path.join(project.path, p);
  p = path.normalize(p);
  if (!fs.existsSync(p)) return null;
  // Vue Blade compilée (storage\framework\views\<hash>.php) : on remonte au fichier .blade.php d'origine.
  if (/\\storage\\framework\\views\\[0-9a-f]+\.php$/i.test(p)) {
    try {
      const m = fs.readFileSync(p, 'utf8').match(/\/\*\*PATH (.+?) ENDPATH\*\*\//);
      if (m && fs.existsSync(m[1])) return { ...fileRef(project, m[1]), compiled: true };
    } catch { /* vue compilée illisible */ }
  }
  const inProject = p.toLowerCase().startsWith(project.path.toLowerCase() + '\\');
  const thirdParty = /\\(vendor|node_modules)\\/i.test(p);
  return {
    path: p,
    rel: inProject ? path.relative(project.path, p) : p,
    line: line ? Number(line) : null,
    col: col ? Number(col) : null,
    app: inProject && !thirdParty
  };
}

const EXT = '(?:php|js|jsx|ts|tsx|vue|svelte|mjs|cjs|css|scss|json)';
const FILE_PATTERNS = [
  new RegExp(`([A-Za-z]:[\\\\/][^\\n:*?"<>|]+?\\.${EXT}):(\\d+)(?::(\\d+))?`, 'g'),                          // C:\...\file.php:12
  new RegExp(`(?:^|[\\s(\\["'])((?:\\.{1,2}[\\\\/])?[\\w@.\\-]+(?:[\\\\/][\\w@.\\-\\[\\]()]+)*\\.${EXT}):(\\d+)(?::(\\d+))?`, 'gm'), // ./src/app/page.tsx:12:5
  /([A-Za-z]:\\[^\n:*?"<>|]+?\.php)\((\d+)\)/g,                 // C:\...\file.php(123)  (pile PHP)
  /in ([A-Za-z]:\\[^\n:*?"<>|]+?\.php)(?: on line |:)(\d+)/g,   // in C:\...\file.php on line 12
  /([\w./\\-]+\.(?:ts|tsx|js|vue))\((\d+),(\d+)\)/g             // src/x.ts(12,5) : TypeScript
];

function findFiles(project, text, limit = 12) {
  const seen = new Set();
  const files = [];
  for (const re of FILE_PATTERNS) {
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(text)) && files.length < 40) {
      const ref = fileRef(project, m[1].trim(), m[2], m[3]);
      if (!ref) continue;
      const key = `${ref.path.toLowerCase()}:${ref.line}`;
      if (seen.has(key)) continue;
      seen.add(key);
      files.push(ref);
    }
  }
  // Les fichiers du projet d'abord (ce sont eux qu'il faut corriger), puis les dépendances.
  return files.sort((a, b) => (b.app - a.app)).slice(0, limit);
}

// ---------- Log Laravel ----------
const ENTRY_RE = /^\[(\d{4}-\d\d-\d\d[ T]\d\d:\d\d:\d\d(?:\.\d+)?(?:[+-]\d\d:?\d\d)?)\] (\w+)\.(\w+): /gm;

function parseLaravelLog(text) {
  const entries = [];
  const marks = [];
  let m;
  ENTRY_RE.lastIndex = 0;
  while ((m = ENTRY_RE.exec(text))) marks.push({ index: m.index, end: ENTRY_RE.lastIndex, date: m[1], env: m[2], level: m[3].toUpperCase() });
  for (let i = 0; i < marks.length; i++) {
    const body = text.slice(marks[i].end, i + 1 < marks.length ? marks[i + 1].index : text.length).trimEnd();
    const firstLine = body.split('\n')[0];
    const message = firstLine.replace(/\s\{"(exception|userId)".*$/, '').replace(/\s\[\]\s*\[\]$/, '').trim();
    const ex = body.match(/\[object\] \(([\w\\]+)\(code: ([^)]*)\): ([\s\S]*?) at ((?:[A-Za-z]:)?[^\n]*?):(\d+)\)/);
    entries.push({
      date: marks[i].date,
      env: marks[i].env,
      level: marks[i].level,
      message: message || firstLine,
      // Dans le log, le contexte est du JSON : les "\" y sont doublés.
      exception: ex ? { class: ex[1].replace(/\\\\/g, '\\'), code: ex[2], file: ex[4].replace(/\\\\/g, '\\'), line: Number(ex[5]) } : null,
      body
    });
  }
  return entries;
}

// Regroupe les erreurs identiques et ajoute fichiers concernés + explication.
function laravelErrors(project, entries) {
  const groups = new Map();
  for (const e of entries) {
    if (!['ERROR', 'CRITICAL', 'ALERT', 'EMERGENCY', 'WARNING'].includes(e.level)) continue;
    const key = `${e.level}|${e.message.slice(0, 300)}|${e.exception ? e.exception.file + e.exception.line : ''}`;
    const g = groups.get(key);
    if (g) { g.count++; g.last = e.date; continue; }
    const files = [];
    const view = e.body.match(/\(View: ([A-Za-z]:[^)]+?\.blade\.php)\)/);
    if (view) { const r = fileRef(project, view[1].replace(/\\\\/g, '\\')); if (r) files.push(r); }
    if (e.exception) { const r = fileRef(project, e.exception.file, e.exception.line); if (r && !files.some(x => x.path === r.path)) files.push(r); }
    for (const f of findFiles(project, e.body)) {
      if (!files.some(x => x.path === f.path && x.line === f.line)) files.push(f);
    }
    files.sort((a, b) => (b.app - a.app));
    groups.set(key, {
      source: 'log', level: e.level, message: e.message, exception: e.exception ? e.exception.class : null,
      count: 1, first: e.date, last: e.date, files: files.slice(0, 12), hint: hintFor(e.body), trace: e.body.slice(0, 20000)
    });
  }
  return [...groups.values()].sort((a, b) => (a.last < b.last ? 1 : -1));
}

// ---------- Console (sortie des serveurs et des commandes) ----------
const CONSOLE_ERROR = /(PHP (Fatal|Parse) error|PHP Warning|Uncaught|^\s*Error:|\w+Error:|error TS\d+|ERROR|\[vite\].*error|Internal server error|Failed to compile|Module not found|Cannot find module|npm ERR!|EADDRINUSE|SQLSTATE|Exception|⨯|✖)/m;

function consoleErrors(project, text) {
  const lines = text.split(/\r?\n/);
  const out = [];
  const seen = new Set();
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!CONSOLE_ERROR.test(line) || /^\s*>\s/.test(line)) continue;
    const block = lines.slice(i, i + 14).join('\n'); // l'erreur et les lignes qui suivent (pile, extrait de code)
    const message = line.replace(/^\s*(⨯|✖|\[\w+\])\s*/, '').trim().slice(0, 400);
    const key = message.replace(/\d{2}:\d{2}:\d{2}/g, '');
    if (seen.has(key)) { out.find(o => o.key === key).count++; continue; }
    seen.add(key);
    out.push({ key, source: 'console', level: 'ERROR', message, count: 1, files: findFiles(project, block, 8), hint: hintFor(block), trace: block });
    i += 3;
  }
  return out.reverse().slice(0, 50).map(({ key, ...e }) => e);
}

module.exports = { listLogs, readTail, parseLaravelLog, laravelErrors, consoleErrors, hintFor };
