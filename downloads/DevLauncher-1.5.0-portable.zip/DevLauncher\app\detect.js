// Détection de l'environnement (serveur local, PHP, MySQL) et des projets.
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SELF_NAME = 'dev-launcher';
const IGNORED_DIRS = new Set([
  'node_modules', 'vendor', '.git', 'dashboard', 'img', 'webalizer', 'xampp',
  'forbidden', 'restricted', '.idea', '.vscode', 'dist', 'build'
]);

function exists(p) {
  try { return fs.existsSync(p); } catch { return false; }
}

function readJson(p) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; }
}

function listDrives() {
  const drives = [];
  for (let c = 67; c <= 90; c++) { // C: à Z:
    const d = String.fromCharCode(c) + ':\\';
    if (exists(d)) drives.push(d);
  }
  return drives;
}

// Cherche un fichier exact (ex. "npm.cmd") dans les dossiers du PATH. Bien plus rapide que la commande "where".
function which(file) {
  const dirs = (process.env.PATH || process.env.Path || '').split(';').filter(Boolean);
  for (const d of dirs) {
    const p = path.join(d.trim().replace(/^"|"$/g, ''), file);
    if (exists(p)) return p;
  }
  return null;
}

// Cherche les serveurs locaux connus (XAMPP, WAMP, Laragon, MAMP, UwAmp) sur tous les disques.
function detectServers() {
  const servers = [];
  for (const drive of listDrives()) {
    const candidates = [
      { type: 'XAMPP', base: path.join(drive, 'xampp'), web: 'htdocs', php: 'php\\php.exe', mysqld: 'mysql\\bin\\mysqld.exe', myini: 'mysql\\bin\\my.ini' },
      { type: 'WAMP', base: path.join(drive, 'wamp64'), web: 'www' },
      { type: 'WAMP', base: path.join(drive, 'wamp'), web: 'www' },
      { type: 'Laragon', base: path.join(drive, 'laragon'), web: 'www' },
      { type: 'MAMP', base: path.join(drive, 'MAMP'), web: 'htdocs' },
      { type: 'UwAmp', base: path.join(drive, 'UwAmp'), web: 'www' }
    ];
    for (const c of candidates) {
      const root = path.join(c.base, c.web);
      if (!exists(root)) continue;
      const s = { type: c.type, base: c.base, root, php: null, mysqld: null, myini: null, httpd: null };
      s.httpd = exists(path.join(c.base, 'apache', 'bin', 'httpd.exe')) ? path.join(c.base, 'apache', 'bin', 'httpd.exe')
        : newestBin(path.join(c.base, 'bin', 'apache'), path.join('bin', 'httpd.exe'));
      if (c.php && exists(path.join(c.base, c.php))) s.php = path.join(c.base, c.php);
      if (c.mysqld && exists(path.join(c.base, c.mysqld))) {
        s.mysqld = path.join(c.base, c.mysqld);
        s.myini = path.join(c.base, c.myini);
      }
      // WAMP / Laragon : versions de PHP et MySQL dans bin\php\phpX.Y.Z et bin\mysql\mysqlX
      if (!s.php) s.php = newestBin(path.join(c.base, 'bin', 'php'), 'php.exe');
      if (!s.mysqld) {
        const m = newestBin(path.join(c.base, 'bin', 'mysql'), path.join('bin', 'mysqld.exe'))
          || newestBin(path.join(c.base, 'bin', 'mariadb'), path.join('bin', 'mysqld.exe'));
        if (m) { s.mysqld = m; s.myini = path.join(path.dirname(m), '..', 'my.ini'); }
      }
      // Client en ligne de commande, à côté du serveur (sert à tester et créer les bases)
      s.mysqlClient = s.mysqld && exists(path.join(path.dirname(s.mysqld), 'mysql.exe')) ? path.join(path.dirname(s.mysqld), 'mysql.exe') : null;
      s.phpmyadmin = exists(path.join(c.base, 'phpMyAdmin')) || exists(path.join(c.base, 'phpmyadmin')) || exists(path.join(c.base, 'etc', 'apps', 'phpMyAdmin'));
      servers.push(s);
    }
  }
  return servers;
}

function newestBin(dir, rel) {
  if (!exists(dir)) return null;
  try {
    const subs = fs.readdirSync(dir).sort().reverse();
    for (const s of subs) {
      const p = path.join(dir, s, rel);
      if (exists(p)) return p;
    }
  } catch { /* ignore */ }
  return null;
}

// Version de PHP, mise en cache tant que l'exécutable ne change pas (les rescans restent instantanés).
const phpVersionCache = new Map();
function phpVersion(exe) {
  let mtime = 0;
  try { mtime = fs.statSync(exe).mtimeMs; } catch { return null; }
  const cached = phpVersionCache.get(exe);
  if (cached && cached.mtime === mtime) return cached.version;
  let version = null;
  // Deux essais, 15 s chacun : juste après une installation ou au démarrage de Windows, l'antivirus peut retarder php.exe.
  for (let i = 0; i < 2 && !version; i++) {
    try {
      version = execSync(`"${exe}" -n -r "echo PHP_VERSION;"`, { stdio: ['ignore', 'pipe', 'ignore'], timeout: 15000, windowsHide: true }).toString().trim() || null;
    } catch { /* php momentanément indisponible */ }
  }
  // Seul un résultat valide est mémorisé : un échec passager sera retenté à la prochaine détection (bouton Actualiser).
  if (version) phpVersionCache.set(exe, { mtime, version });
  return version;
}

function cmpVersion(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
}

// Toutes les versions de PHP disponibles (serveurs locaux + PATH), de la plus récente à la plus ancienne.
function detectPhps(servers) {
  const seen = new Set();
  const list = [];
  const add = (exe, server) => {
    if (!exe || seen.has(exe.toLowerCase())) return;
    seen.add(exe.toLowerCase());
    const version = phpVersion(exe);
    if (version) list.push({ exe, version, server });
  };
  for (const s of servers) {
    add(s.php, s.base);
    const dir = path.join(s.base, 'bin', 'php');
    try { for (const d of fs.readdirSync(dir)) add(path.join(dir, d, 'php.exe'), s.base); } catch { /* pas de bin\php */ }
  }
  add(which('php.exe'), null);
  return list.sort((a, b) => cmpVersion(b.version, a.version));
}

// Choisit le PHP adapté au projet : celui de son serveur s'il respecte la version requise, sinon la plus récente compatible.
function pickPhp(phps, project) {
  if (!phps.length) return null;
  const composerJson = readJson(path.join(project.path, 'composer.json')) || {};
  const m = String((composerJson.require || {}).php || '').match(/(\d+)\.(\d+)/);
  const min = m ? `${m[1]}.${m[2]}.0` : '0.0.0';
  const ok = phps.filter(p => cmpVersion(p.version, min) >= 0);
  const own = ok.find(p => p.server && project.path.toLowerCase().startsWith(p.server.toLowerCase() + '\\'));
  return own || ok[0] || phps[0];
}

function detectTools(servers) {
  const phps = detectPhps(servers);
  const php = phps.length ? phps[0].exe : null;
  const composer = which('composer.bat') || which('composer.cmd') || null;
  const node = which('node.exe');
  const npm = which('npm.cmd');
  const yarn = which('yarn.cmd');
  const pnpm = which('pnpm.cmd');
  return { php, phps, composer, node, npm, yarn, pnpm };
}

// Identifie le type d'un dossier projet. Retourne null si ce n'est pas un projet reconnu.
function detectProject(dir) {
  const hasArtisan = exists(path.join(dir, 'artisan'));
  const composerJson = readJson(path.join(dir, 'composer.json'));
  const pkg = readJson(path.join(dir, 'package.json'));

  if (pkg && pkg.name === SELF_NAME) return null;

  const deps = pkg ? { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) } : {};
  const scripts = (pkg && pkg.scripts) || {};
  const pm = exists(path.join(dir, 'pnpm-lock.yaml')) ? 'pnpm'
    : exists(path.join(dir, 'yarn.lock')) ? 'yarn' : 'npm';

  const base = {
    name: path.basename(dir),
    path: dir,
    pm,
    hasNodeModules: exists(path.join(dir, 'node_modules')),
    hasVendor: exists(path.join(dir, 'vendor')),
    hasEnv: exists(path.join(dir, '.env')),
    hasEnvExample: exists(path.join(dir, '.env.example')),
    hasPrisma: !!deps.prisma || !!deps['@prisma/client'],
    hasVite: !!deps.vite,
    scripts: Object.keys(scripts)
  };

  if (hasArtisan && composerJson) {
    let envText = '';
    try { envText = fs.readFileSync(path.join(dir, '.env'), 'utf8'); } catch { /* pas de .env */ }
    base.needsKey = !/^APP_KEY=\S+/m.test(envText);
    const ver = ((composerJson.require || {})['laravel/framework'] || '').replace(/[^\d.]/g, '');
    return { ...base, type: 'laravel', label: 'Laravel' + (ver ? ' ' + ver.split('.')[0] : ''), defaultPort: 8000 };
  }
  if (!pkg) {
    if (composerJson || exists(path.join(dir, 'index.php'))) {
      return { ...base, type: 'php', label: 'PHP', defaultPort: 8000 };
    }
    // PHP dont la page d'entrée est seulement dans public/ (structure courante sans framework)
    if (exists(path.join(dir, 'public', 'index.php'))) {
      return { ...base, type: 'php', label: 'PHP (public/)', docroot: 'public', defaultPort: 8000 };
    }
    // Site HTML simple : servi par le petit serveur intégré de DevLauncher
    if (exists(path.join(dir, 'index.html'))) return { ...base, type: 'static', label: 'Site HTML', defaultPort: 5500 };
    return null;
  }
  if (deps.next) return { ...base, type: 'next', label: 'Next.js', defaultPort: 3000 };
  if (deps.nuxt || deps['nuxt3']) return { ...base, type: 'nuxt', label: 'Nuxt', defaultPort: 3000 };
  if (deps['@angular/core'] && deps['@angular/cli']) return { ...base, type: 'angular', label: 'Angular', defaultPort: 4200 };
  if (deps['@sveltejs/kit']) return { ...base, type: 'vite', label: 'SvelteKit', defaultPort: 5173 };
  if (deps['@remix-run/dev'] && deps.vite) return { ...base, type: 'vite', label: 'Remix', defaultPort: 5173 };
  if (deps.astro) return { ...base, type: 'astro', label: 'Astro', defaultPort: 4321 };
  if (deps['react-scripts']) return { ...base, type: 'cra', label: 'React (CRA)', defaultPort: 3000 };
  if (deps['@vue/cli-service']) return { ...base, type: 'vuecli', label: 'Vue CLI', defaultPort: 8080 };
  if (deps.vite) {
    const label = deps.react ? 'React (Vite)' : deps.vue ? 'Vue (Vite)' : deps.svelte ? 'Svelte (Vite)' : 'Vite';
    return { ...base, type: 'vite', label, defaultPort: 5173 };
  }
  if (scripts.dev || scripts.start) {
    const label = deps.express ? 'Node (Express)' : deps['@nestjs/core'] ? 'NestJS' : 'Node.js';
    return { ...base, type: 'node', label, defaultPort: 3000 };
  }
  // package.json sans script de lancement (outils de mise en forme seulement) mais une page HTML : site statique
  if (exists(path.join(dir, 'index.html'))) return { ...base, type: 'static', label: 'Site HTML', defaultPort: 5500 };
  return null;
}

// Parcourt la racine du serveur jusqu'à 4 niveaux, sans descendre dans un dossier déjà reconnu comme projet.
function scanRoot(root, maxDepth = 4) {
  const found = [];
  const walk = (dir, depth) => {
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (!e.isDirectory() || e.name.startsWith('.') || IGNORED_DIRS.has(e.name)) continue;
      const full = path.join(dir, e.name);
      const p = detectProject(full);
      if (p) found.push(p);
      else if (depth < maxDepth) walk(full, depth + 1);
    }
  };
  walk(root, 1);
  return found;
}

// ---------- Recherche de projets sur tout le PC ----------
// Dossiers jamais parcourus : système, programmes, caches et dépendances.
const SKIP_SEARCH = new Set([...IGNORED_DIRS, 'appdata', 'application data', 'program files', 'program files (x86)', 'programdata', 'windows',
  '$recycle.bin', 'system volume information', 'recovery', 'perflogs', 'msocache', 'intel', 'amd', 'nvidia', 'drivers', 'onedrivetemp',
  'bower_components', 'coverage', 'out', 'target', 'bin', 'obj', 'venv', '.venv', '__pycache__', 'site-packages', 'library',
  'temp', 'tmp', 'cache', 'logs', 'storage', 'public', 'assets', 'images', 'fonts', 'go', 'android', 'sdk']);

// Noms de dossiers qui regroupent des projets (personnels ou racines web) : parcourus, jamais pris pour un projet.
const CONTAINER_NAMES = new Set(['downloads', 'téléchargements', 'desktop', 'bureau', 'documents', 'onedrive', 'htdocs', 'www',
  'public_html', 'sites', 'projets', 'projects', 'dev', 'code', 'workspace', 'repos', 'source', 'github']);

function hasChildProject(dir) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return false; }
  return entries.some(e => e.isDirectory() && !e.name.startsWith('.') && !SKIP_SEARCH.has(e.name.toLowerCase()) && (() => {
    try { const c = detectProject(path.join(dir, e.name)); return c && c.type !== 'static'; } catch { return false; }
  })());
}

// Dossiers de départ : dossier personnel (Bureau, Documents, Téléchargements, OneDrive...) et autres disques.
function searchBases() {
  const os = require('os');
  const home = os.homedir();
  const bases = [{ dir: home, depth: 5 }];
  for (let c = 67; c <= 90; c++) { // C: à Z:
    const drive = String.fromCharCode(c) + ':\\';
    try { fs.accessSync(drive); } catch { continue; }
    if (home.toLowerCase().startsWith(drive.toLowerCase()) && c === 67) bases.push({ dir: drive, depth: 3, skipUsers: true });
    else bases.push({ dir: drive, depth: 4 });
  }
  return bases;
}

/**
 * Parcourt le PC à la recherche de projets (sans bloquer : lecture asynchrone des dossiers).
 * @param opts.skip dossiers à ne pas parcourir (racines de serveurs déjà analysées)
 * @param opts.known projets déjà dans la liste (signalés, non proposés)
 * @param opts.onFound / onProgress rappels ; opts.cancelled() arrête la recherche
 */
async function searchProjects({ skip = [], known = [], onFound, onProgress, cancelled = () => false, maxDirs = 150000, maxMs = 90000 } = {}) {
  const skipSet = new Set(skip.map(d => path.resolve(d).toLowerCase()));
  const knownSet = new Set(known.map(d => path.resolve(d).toLowerCase()));
  const seen = new Set();
  const found = [];
  const started = Date.now();
  let visited = 0, lastTick = 0;
  const walk = async (dir, depth, skipUsers) => {
    if (cancelled() || visited > maxDirs || Date.now() - started > maxMs) return;
    const key = dir.toLowerCase();
    if (seen.has(key) || skipSet.has(key)) return;
    seen.add(key);
    visited++;
    if (onProgress && Date.now() - lastTick > 200) { lastTick = Date.now(); onProgress({ dir, visited, found: found.length }); }
    let entries;
    try { entries = await fs.promises.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (e.name.startsWith('.') || e.name.startsWith('$') || e.isFile()) continue;
      const lower = e.name.toLowerCase();
      if (SKIP_SEARCH.has(lower) || (skipUsers && lower === 'users')) continue;
      const full = path.join(dir, e.name);
      // OneDrive (fichiers à la demande) et liens de dossiers ne sont pas vus comme des dossiers : vérification directe.
      if (!e.isDirectory()) {
        try { if (!(await fs.promises.stat(full)).isDirectory()) continue; } catch { continue; }
      }
      if (skipSet.has(full.toLowerCase())) continue;
      let p = null;
      // Dossiers personnels et racines web : toujours des conteneurs, jamais un projet (un index.php isolé n'y suffit pas).
      if (!CONTAINER_NAMES.has(lower)) { try { p = detectProject(full); } catch { /* dossier illisible */ } }
      // Signal faible (PHP simple, page HTML) : si le dossier contient lui-même des projets, c'est un conteneur.
      if (p && (p.type === 'php' || p.type === 'static') && !p.docroot && hasChildProject(full)) p = null;
      if (p) {
        if (!knownSet.has(full.toLowerCase())) { found.push(p); if (onFound) onFound(p); }
      } else if (depth > 1) await walk(full, depth - 1, false);
      if (cancelled()) return;
    }
  };
  for (const b of searchBases()) await walk(b.dir, b.depth, b.skipUsers);
  return { found, visited, ms: Date.now() - started, truncated: visited > maxDirs || Date.now() - started > maxMs, cancelled: cancelled() };
}

module.exports = { detectServers, detectTools, detectProject, scanRoot, pickPhp, searchProjects };
