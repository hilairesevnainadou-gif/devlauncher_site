// Boîte mail de test : serveur SMTP local qui capture les mails envoyés par les projets (rien n'est réellement envoyé).
const net = require('net');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { EventEmitter } = require('events');

const MAX_MAILS = 300;

// ---------- Décodage MIME ----------
function decodeBytes(buf, charset) {
  const cs = String(charset || 'utf-8').toLowerCase().replace(/^"|"$/g, '');
  try { return new TextDecoder(cs === 'us-ascii' ? 'utf-8' : cs).decode(buf); } catch { return buf.toString('latin1'); }
}

function decodeQP(str) {
  const s = str.replace(/=\r?\n/g, '');
  const bytes = [];
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '=' && /^[0-9A-Fa-f]{2}$/.test(s.substr(i + 1, 2))) { bytes.push(parseInt(s.substr(i + 1, 2), 16)); i += 2; }
    else bytes.push(s.charCodeAt(i) & 0xff);
  }
  return Buffer.from(bytes);
}

// Mots encodés des en-têtes : =?UTF-8?B?...?= et =?UTF-8?Q?...?=
function decodeWords(value) {
  if (!value) return '';
  // En-têtes en UTF-8 brut (8BITMIME) : les octets arrivent en latin1, on les relit en UTF-8 si c'est valide.
  if (/[\x80-\xff]/.test(value)) {
    try { value = new TextDecoder('utf-8', { fatal: true }).decode(Buffer.from(value, 'latin1')); } catch { /* vrai latin1 */ }
  }
  return value
    .replace(/(=\?[^?]+\?[BbQq]\?[^?]*\?=)\s+(?==\?)/g, '$1')
    .replace(/=\?([^?]+)\?([BbQq])\?([^?]*)\?=/g, (_, cs, enc, txt) => {
      const buf = enc.toUpperCase() === 'B' ? Buffer.from(txt, 'base64') : decodeQP(txt.replace(/_/g, ' '));
      return decodeBytes(buf, cs);
    });
}

function parseHeaders(block) {
  const headers = [];
  for (const line of block.replace(/\r?\n[ \t]+/g, ' ').split(/\r?\n/)) {
    const i = line.indexOf(':');
    if (i > 0) headers.push({ name: line.slice(0, i).trim(), value: line.slice(i + 1).trim() });
  }
  return headers;
}

const header = (headers, name) => (headers.find(h => h.name.toLowerCase() === name.toLowerCase()) || {}).value || '';

// "text/html; charset=utf-8; boundary=x" -> { value, params }
function parseParams(v) {
  const [value, ...rest] = String(v || '').split(';');
  const params = {};
  for (const r of rest) {
    const m = r.match(/^\s*([^=]+?)\*?=\s*"?([^"]*)"?\s*$/);
    if (m) params[m[1].toLowerCase()] = m[2].replace(/^utf-8''/i, '');
  }
  return { value: value.trim().toLowerCase(), params };
}

// Analyse récursive d'une partie MIME (chaîne "latin1" = octets bruts).
function parsePart(raw, out) {
  const sep = raw.search(/\r?\n\r?\n/);
  const head = sep >= 0 ? raw.slice(0, sep) : raw;
  let body = sep >= 0 ? raw.slice(sep).replace(/^\r?\n\r?\n/, '') : '';
  const headers = parseHeaders(head);
  const ct = parseParams(header(headers, 'content-type') || 'text/plain');
  const cd = parseParams(header(headers, 'content-disposition'));
  const enc = header(headers, 'content-transfer-encoding').toLowerCase();

  if (ct.value.startsWith('multipart/') && ct.params.boundary) {
    const b = '--' + ct.params.boundary;
    const chunks = body.split(b);
    for (let i = 1; i < chunks.length; i++) {
      if (chunks[i].startsWith('--')) break;
      parsePart(chunks[i].replace(/^\r?\n/, '').replace(/\r?\n$/, ''), out);
    }
    return headers;
  }
  if (ct.value === 'message/rfc822') { out.attachments.push(makeAttachment(Buffer.from(body, 'latin1'), 'message.eml', ct.value, null)); return headers; }

  const buf = enc === 'base64' ? Buffer.from(body.replace(/[^A-Za-z0-9+/=]/g, ''), 'base64')
    : enc === 'quoted-printable' ? decodeQP(body) : Buffer.from(body, 'latin1');
  const filename = decodeWords(cd.params.filename || ct.params.name || '');
  const cid = header(headers, 'content-id').replace(/^<|>$/g, '');
  const isAttachment = cd.value === 'attachment' || (filename && !ct.value.startsWith('text/')) || (cid && !ct.value.startsWith('text/'));

  if (!isAttachment && ct.value === 'text/html' && out.html == null) out.html = decodeBytes(buf, ct.params.charset);
  else if (!isAttachment && ct.value === 'text/plain' && out.text == null) out.text = decodeBytes(buf, ct.params.charset);
  else out.attachments.push(makeAttachment(buf, filename || (cid ? cid : 'fichier'), ct.value, cid || null, cd.value === 'inline'));
  return headers;
}

function makeAttachment(buf, filename, contentType, cid, inline = false) {
  return { filename, contentType, cid, inline, size: buf.length, data: buf };
}

function addresses(v) {
  return decodeWords(v).split(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/).map(s => s.trim()).filter(Boolean);
}

function parseMail(rawBuf) {
  const raw = rawBuf.toString('latin1');
  const out = { html: null, text: null, attachments: [] };
  const headers = parsePart(raw, out);
  const decodedHeaders = headers.map(h => ({ name: h.name, value: decodeWords(h.value) }));
  return {
    subject: decodeWords(header(headers, 'subject')) || '(sans objet)',
    from: decodeWords(header(headers, 'from')),
    to: addresses(header(headers, 'to')),
    cc: addresses(header(headers, 'cc')),
    replyTo: decodeWords(header(headers, 'reply-to')),
    date: header(headers, 'date'),
    headers: decodedHeaders,
    html: out.html,
    text: out.text,
    attachments: out.attachments
  };
}

// ---------- Stockage ----------
class MailStore extends EventEmitter {
  constructor(dir) {
    super();
    this.dir = dir;
    this.mails = [];
    fs.mkdirSync(dir, { recursive: true });
    const files = fs.readdirSync(dir).filter(f => f.endsWith('.eml'))
      .map(f => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs })).sort((a, b) => b.t - a.t).slice(0, MAX_MAILS);
    for (const { f } of files) {
      const id = f.slice(0, -4);
      let meta = {};
      try { meta = JSON.parse(fs.readFileSync(path.join(dir, id + '.json'), 'utf8')); } catch { /* pas de métadonnées */ }
      try { this.mails.push(this.build(id, fs.readFileSync(path.join(dir, f)), meta)); } catch { /* mail illisible */ }
    }
  }

  build(id, raw, meta) {
    const m = parseMail(raw);
    return { id, raw, ...m, receivedAt: meta.receivedAt || Date.now(), envelope: meta.envelope || {}, project: meta.project || null, read: !!meta.read };
  }

  add(raw, envelope, project) {
    const id = Date.now().toString(36) + crypto.randomBytes(3).toString('hex');
    const meta = { receivedAt: Date.now(), envelope, project, read: false };
    fs.writeFileSync(path.join(this.dir, id + '.eml'), raw);
    fs.writeFileSync(path.join(this.dir, id + '.json'), JSON.stringify(meta));
    const mail = this.build(id, raw, meta);
    this.mails.unshift(mail);
    while (this.mails.length > MAX_MAILS) this.remove(this.mails[this.mails.length - 1].id);
    this.emit('mail', this.summary(mail));
    return mail;
  }

  get(id) { return this.mails.find(m => m.id === id); }

  markRead(id) {
    const m = this.get(id);
    if (!m || m.read) return;
    m.read = true;
    try { fs.writeFileSync(path.join(this.dir, id + '.json'), JSON.stringify({ receivedAt: m.receivedAt, envelope: m.envelope, project: m.project, read: true })); } catch { /* ignore */ }
  }

  remove(id) {
    this.mails = this.mails.filter(m => m.id !== id);
    for (const ext of ['.eml', '.json']) { try { fs.unlinkSync(path.join(this.dir, id + ext)); } catch { /* déjà supprimé */ } }
  }

  clear() { for (const m of [...this.mails]) this.remove(m.id); }

  summary(m) {
    return {
      id: m.id, subject: m.subject, from: m.from, to: m.to, cc: m.cc, date: m.date, receivedAt: m.receivedAt,
      project: m.project, read: m.read, size: m.raw.length, hasHtml: m.html != null,
      // Les images intégrées au HTML (cid:) ne sont pas des pièces jointes pour le destinataire.
      attachments: m.attachments.filter(a => !(a.cid && m.html && m.html.includes('cid:' + a.cid))).map(a => ({ filename: a.filename, size: a.size }))
    };
  }

  detail(m) {
    return {
      ...this.summary(m), replyTo: m.replyTo, headers: m.headers, text: m.text, envelope: m.envelope,
      attachments: m.attachments.map((a, index) => ({
        index, filename: a.filename, contentType: a.contentType, size: a.size, cid: a.cid,
        embedded: !!(a.cid && m.html && m.html.includes('cid:' + a.cid))
      }))
    };
  }
}

// ---------- Serveur SMTP ----------
// resolveProject(ehloName) -> chemin du projet qui envoie (via MAIL_EHLO_DOMAIN), ou null.
function startSmtp(port, store, resolveProject) {
  return new Promise((resolve, reject) => {
    const server = net.createServer(socket => {
      let buffer = '';
      let mode = 'cmd';
      let ehlo = '';
      let env = { from: '', to: [] };
      let data = [];
      const reply = s => socket.write(s + '\r\n');
      reply('220 devlauncher ESMTP DevLauncher Mail Catcher');

      const handle = line => {
        if (mode === 'data') {
          if (line === '.') {
            mode = 'cmd';
            const raw = Buffer.from(data.join('\r\n') + '\r\n', 'latin1');
            data = [];
            try { store.add(raw, env, resolveProject(ehlo)); reply('250 2.0.0 OK : mail capturé par DevLauncher'); }
            catch (e) { reply('451 4.3.0 ' + e.message); }
            env = { from: '', to: [] };
          } else data.push(line.startsWith('..') ? line.slice(1) : line);
          return;
        }
        if (mode === 'auth-plain') { mode = 'cmd'; return reply('235 2.7.0 Authentification acceptée'); }
        if (mode === 'auth-user') { mode = 'auth-pass'; return reply('334 UGFzc3dvcmQ6'); }
        if (mode === 'auth-pass') { mode = 'cmd'; return reply('235 2.7.0 Authentification acceptée'); }

        const [verb, ...rest] = line.split(' ');
        const arg = rest.join(' ');
        switch (verb.toUpperCase()) {
          case 'EHLO':
            ehlo = arg;
            return socket.write('250-devlauncher\r\n250-SIZE 52428800\r\n250-8BITMIME\r\n250-SMTPUTF8\r\n250-AUTH PLAIN LOGIN\r\n250 OK\r\n');
          case 'HELO': ehlo = arg; return reply('250 devlauncher');
          case 'AUTH': {
            const [type, initial] = arg.split(' ');
            if (/^plain$/i.test(type)) { if (initial) return reply('235 2.7.0 Authentification acceptée'); mode = 'auth-plain'; return reply('334 '); }
            if (/^login$/i.test(type)) { if (initial) { mode = 'auth-pass'; return reply('334 UGFzc3dvcmQ6'); } mode = 'auth-user'; return reply('334 VXNlcm5hbWU6'); }
            return reply('504 5.5.4 Mécanisme non supporté');
          }
          case 'MAIL': env.from = (arg.match(/<([^>]*)>/) || [])[1] || ''; return reply('250 2.1.0 OK');
          case 'RCPT': env.to.push((arg.match(/<([^>]*)>/) || [])[1] || arg); return reply('250 2.1.5 OK');
          case 'DATA': mode = 'data'; return reply('354 Envoie le message, termine par <CRLF>.<CRLF>');
          case 'RSET': env = { from: '', to: [] }; data = []; return reply('250 2.0.0 OK');
          case 'NOOP': return reply('250 2.0.0 OK');
          case 'VRFY': return reply('252 2.0.0 OK');
          case 'QUIT': reply('221 2.0.0 Au revoir'); return socket.end();
          default: return reply('502 5.5.2 Commande non reconnue');
        }
      };

      socket.on('data', chunk => {
        buffer += chunk.toString('latin1');
        let i;
        while ((i = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, i).replace(/\r$/, '');
          buffer = buffer.slice(i + 1);
          handle(line);
        }
      });
      socket.on('error', () => { /* client déconnecté */ });
      socket.setTimeout(120000, () => socket.destroy());
    });
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => resolve(server));
  });
}

module.exports = { MailStore, startSmtp, parseMail };
