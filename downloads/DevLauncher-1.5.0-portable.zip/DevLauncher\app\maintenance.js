// Maintenance du serveur local : diagnostic MySQL / Apache, réparations guidées, arrêt et démarrage propres.
// Règle : toute réparation qui modifie des fichiers commence par en garder une copie.
const fs = require('fs');
const path = require('path');
const net = require('net');
const { spawn, execFile } = require('child_process');
const { listeningPorts, sh } = require('./external');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15); // 20261026-181502
const same = (a, b) => !!a && !!b && path.normalize(a).toLowerCase() === path.normalize(b).toLowerCase();

function isPortOpen(port) {
  return new Promise(resolve => {
    const s = net.connect({ port, host: '127.0.0.1' });
    s.setTimeout(500);
    s.once('connect', () => { s.destroy(); resolve(true); });
    s.once('timeout', () => { s.destroy(); resolve(false); });
    s.once('error', () => resolve(false));
  });
}

// ---------- Processus ----------
async function processes(filter) {
  const ps = `Get-CimInstance Win32_Process -Filter "${filter}" | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | ConvertTo-Json -Compress`;
  const out = await sh(`powershell -NoProfile -NonInteractive -EncodedCommand ${Buffer.from(ps, 'utf16le').toString('base64')}`);
  try { const r = JSON.parse(out); return (Array.isArray(r) ? r : [r]).map(p => ({ pid: p.ProcessId, ppid: p.ParentProcessId, name: p.Name, exe: p.ExecutablePath || '', cmd: p.CommandLine || '' })); }
  catch { return []; }
}

// Programme qui écoute sur un port (nom, chemin), ou null.
async function portOwner(port) {
  const ports = await listeningPorts();
  const pid = ports.get(port);
  if (!pid) return null;
  if (pid === 4) return { pid, name: 'System', exe: '', system: true }; // http.sys : IIS, WinRM, partage...
  const [p] = await processes(`ProcessId=${pid}`);
  return p || { pid, name: '?', exe: '' };
}

function killPid(pid, tree = true) {
  return new Promise(resolve => execFile('taskkill', ['/PID', String(pid), '/F', ...(tree ? ['/T'] : [])], { windowsHide: true }, err => resolve(!err)));
}

// ---------- Configuration ----------
function readIni(file) {
  const out = {};
  let section = '';
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const s = line.match(/^\s*\[([^\]]+)\]/);
      if (s) { section = s[1].trim().toLowerCase(); continue; }
      const m = line.match(/^\s*([\w-]+)\s*=\s*(.*?)\s*$/);
      if (m && !line.trim().startsWith('#') && !line.trim().startsWith(';')) {
        const key = `${section}.${m[1].toLowerCase().replace(/-/g, '_')}`;
        if (!(key in out)) out[key] = m[2].replace(/^"(.*)"$/, '$1');
      }
    }
  } catch { /* ini absent */ }
  return out;
}

function mysqlConfig(server) {
  if (!server.mysqld) return null;
  const ini = readIni(server.myini);
  const bin = path.dirname(server.mysqld);
  const datadir = path.normalize(ini['mysqld.datadir'] || (fs.existsSync(path.join(server.base, 'mysql', 'data')) ? path.join(server.base, 'mysql', 'data') : path.join(bin, '..', 'data')));
  let log = ini['mysqld.log_error'];
  if (log) log = path.isAbsolute(log) ? path.normalize(log) : path.join(datadir, log);
  else {
    // Sans log_error : <nom-du-pc>.err dans le dossier data (le plus récent)
    try {
      const errs = fs.readdirSync(datadir).filter(f => f.endsWith('.err')).map(f => path.join(datadir, f));
      log = errs.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0] || null;
    } catch { log = null; }
  }
  const backupDir = path.join(server.base, 'mysql', 'backup'); // dossier de secours fourni par XAMPP
  return {
    port: Number(ini['mysqld.port'] || ini['client.port'] || 3306),
    datadir, log, bin,
    mysqladmin: fs.existsSync(path.join(bin, 'mysqladmin.exe')) ? path.join(bin, 'mysqladmin.exe') : null,
    mysqldump: fs.existsSync(path.join(bin, 'mysqldump.exe')) ? path.join(bin, 'mysqldump.exe') : null,
    client: fs.existsSync(path.join(bin, 'mysql.exe')) ? path.join(bin, 'mysql.exe') : null,
    backupDir: fs.existsSync(backupDir) ? backupDir : null,
    mariadb: fs.existsSync(path.join(datadir, 'aria_log_control')) || /mariadb/i.test(server.mysqld + (fs.existsSync(path.join(bin, 'mariadbd.exe')) ? 'mariadb' : ''))
  };
}

function apacheConfig(server) {
  if (!server.httpd) return null;
  const root = path.normalize(path.join(path.dirname(server.httpd), '..'));
  const conf = path.join(root, 'conf', 'httpd.conf');
  const ssl = path.join(root, 'conf', 'extra', 'httpd-ssl.conf');
  const read = f => { try { return fs.readFileSync(f, 'utf8'); } catch { return ''; } };
  const text = read(conf), sslText = read(ssl);
  const listens = t => [...t.matchAll(/^\s*Listen\s+(?:[\d.]+:)?(\d+)/gim)].map(m => Number(m[1]));
  const sslOn = /^\s*Include\s+"?conf\/extra\/httpd-ssl\.conf/im.test(text);
  let log = (text.match(/^\s*ErrorLog\s+"?([^"\r\n]+)"?/im) || [])[1] || 'logs/error.log';
  log = path.isAbsolute(log) ? path.normalize(log) : path.join(root, log);
  return {
    root, conf, ssl: sslOn && sslText ? ssl : null, log,
    ports: [...new Set([...listens(text), ...(sslOn ? listens(sslText) : [])])],
    editable: fs.existsSync(conf) && /xampp/i.test(server.type) // Laragon et WAMP régénèrent leur configuration
  };
}

// ---------- Logs ----------
function readTail(file, bytes = 400000) {
  if (!file || !fs.existsSync(file)) return '';
  const st = fs.statSync(file);
  const start = Math.max(0, st.size - bytes);
  const fd = fs.openSync(file, 'r');
  try { const b = Buffer.alloc(st.size - start); fs.readSync(fd, b, 0, b.length, start); return b.toString('utf8'); }
  finally { fs.closeSync(fd); }
}
const fileSize = f => { try { return fs.statSync(f).size; } catch { return 0; } };
function readFrom(file, offset) {
  if (!file || !fs.existsSync(file)) return '';
  const size = fileSize(file);
  if (size <= offset) return '';
  const fd = fs.openSync(file, 'r');
  try { const b = Buffer.alloc(Math.min(size - offset, 200000)); fs.readSync(fd, b, 0, b.length, offset); return b.toString('utf8'); }
  finally { fs.closeSync(fd); }
}

const START_RE = /(Starting MariaDB|mysqld(?:\.exe)? \(mysqld [\d.]+\) starting as process|\[Server\] .*mysqld.*starting as process|Starting MySQL)/i;

// Problèmes MySQL reconnus dans le log (dernière session) et leur réparation.
const MYSQL_RULES = [
  { id: 'port', re: /Do you already have another mysqld server running|Can't start server: Bind on TCP\/IP port|Address already in use/i,
    title: 'Le port de MySQL est déjà utilisé', detail: 'Un autre MySQL (Laragon, WAMP, un service MySQL de Windows...) ou un autre programme occupe le port. Arrête-le, puis redémarre MySQL.', fix: 'kill-port' },
  { id: 'lock', re: /Unable to lock .*ibdata1|ibdata1 must be writable|InnoDB: Operating system error number 3[23]/i,
    title: 'Fichiers MySQL verrouillés', detail: 'Un autre processus mysqld utilise déjà ce dossier de données (instance restée bloquée). Il faut l\'arrêter avant de relancer.', fix: 'kill-mysqld' },
  { id: 'aria', re: /Aria recovery failed|Aria engine: log initialization failed|Could not open required aria_log_control|aria_log_control.*(corrupt|wrong)|Plugin 'Aria' (init function returned error|registration)/i,
    title: 'Journaux Aria endommagés', detail: 'Les journaux internes Aria de MariaDB sont corrompus (souvent après un arrêt brutal). Ils peuvent être réinitialisés sans toucher à tes bases.', fix: 'aria' },
  { id: 'privileges', re: /Can't open and lock privilege tables|Table 'mysql\.(user|db|plugin|global_priv)' doesn't exist|Fatal error: Can't open and lock privilege/i,
    title: 'Tables système MySQL endommagées', detail: 'Les tables internes de MySQL (comptes, droits) sont abîmées. La méthode de restauration XAMPP les remplace par des tables saines en conservant tes bases.', fix: 'restore-system' },
  { id: 'innodb', re: /log sequence number .* is in the future|Database page corruption|InnoDB: Plugin initialization aborted|Plugin 'InnoDB' (init function returned error|registration as a STORAGE ENGINE failed)|Unknown\/unsupported storage engine: InnoDB|Upgrade after a crash is not supported|InnoDB: Corrupt|Missing MLOG_CHECKPOINT|InnoDB: Assertion failure/i,
    title: 'Moteur InnoDB endommagé', detail: 'Les fichiers InnoDB sont incohérents (arrêt brutal, coupure de courant, copie partielle du dossier data). Sauvegarde d\'abord tes bases, puis utilise la restauration XAMPP.', fix: 'restore-system' },
  { id: 'tablespace', re: /Tablespace .* exists\. Please DISCARD|InnoDB: Cannot open datafile|InnoDB: Operating system error number 2 in a file operation/i,
    title: 'Fichier de table orphelin ou manquant', detail: 'Une table a un fichier .ibd orphelin ou introuvable. MySQL démarre souvent quand même ; supprime ou recrée la table concernée.', fix: null },
  { id: 'config', re: /unknown variable|unknown option|Found invalid value for|\[ERROR\] .*my\.ini/i,
    title: 'Erreur dans my.ini', detail: 'Le fichier de configuration contient une option inconnue ou invalide. Corrige la ligne indiquée dans le log.', fix: 'open-config' }
];

function analyseMysqlLog(text) {
  const lines = text.split(/\r?\n/);
  let lastStart = -1;
  lines.forEach((l, i) => { if (START_RE.test(l)) lastStart = i; });
  const session = lastStart >= 0 ? lines.slice(lastStart).join('\n') : lines.slice(-200).join('\n');
  const issues = [];
  for (const r of MYSQL_RULES) if (r.re.test(session)) issues.push({ id: r.id, title: r.title, detail: r.detail, fix: r.fix });
  // Historique : arrêts brutaux (récupération au démarrage) et corruptions passées
  const recoveries = (text.match(/Starting crash recovery|crash recovery/gi) || []).length;
  const pastCorruption = (text.match(/log sequence number .* is in the future|Database page corruption/gi) || []).length;
  const crashDates = [...text.matchAll(/^(\d{4}-\d\d-\d\d)\s+[\d:]+ \d+ \[ERROR\] InnoDB: (?:Page .*is in the future|Database page corruption)/gm)].map(m => m[1]);
  const ready = /ready for connections/i.test(session);
  return {
    session: session.split('\n').slice(-120).join('\n'),
    issues, ready,
    history: { recoveries, pastCorruption, lastCorruption: crashDates.pop() || null }
  };
}

const APACHE_RULES = [
  { id: 'port', re: /AH00072|make_sock: could not bind|could not bind to address|AH00451/i, title: 'Port d\'Apache déjà utilisé', detail: 'Un autre programme (IIS, Skype, VMware, un autre Apache...) occupe le port 80 ou 443.', fix: 'kill-port' },
  { id: 'module', re: /Cannot load .* into server|The specified module could not be found/i, title: 'Module Apache introuvable', detail: 'Un module (souvent PHP) ne se charge pas : fichier manquant ou Visual C++ Redistributable absent. Réinstalle le paquet VC++ 2015-2022 x64.', fix: null },
  { id: 'syntax', re: /Syntax error on line \d+|AH00526/i, title: 'Erreur dans la configuration Apache', detail: 'Le fichier httpd.conf (ou un fichier inclus) contient une erreur à la ligne indiquée.', fix: 'open-config' },
  { id: 'ssl', re: /SSLCertificateFile: file .* does not exist|AH02572|AH02312/i, title: 'Certificat SSL introuvable', detail: 'Le certificat déclaré dans httpd-ssl.conf est absent.', fix: 'open-config' }
];

function analyseApacheLog(text) {
  const lines = text.split(/\r?\n/);
  let last = -1;
  lines.forEach((l, i) => { if (/AH00455|AH00418|Apache\/[\d.]+ .*configured/i.test(l)) last = i; });
  const session = lines.slice(Math.max(0, (last >= 0 ? last : lines.length) - 40)).join('\n');
  const issues = [];
  for (const r of APACHE_RULES) if (r.re.test(session)) issues.push({ id: r.id, title: r.title, detail: r.detail, fix: r.fix });
  return { session: lines.slice(-80).join('\n'), issues, unclean: (text.match(/Unclean shutdown/gi) || []).length };
}

function configTest(server) {
  return new Promise(resolve => {
    if (!server.httpd) return resolve(null);
    execFile(server.httpd, ['-t'], { cwd: path.dirname(server.httpd), windowsHide: true, timeout: 15000 }, (err, stdout, stderr) => {
      const out = `${stdout}${stderr}`.trim();
      resolve({ ok: !err && /Syntax OK/i.test(out), output: out });
    });
  });
}

// Exécute un script SQL avec le client mysql (--force : continue après une erreur) et renvoie sortie + erreurs.
function mysqlScript(my, creds, sql) {
  return new Promise(resolve => {
    const child = spawn(my.client, ['--protocol=TCP', '-h', '127.0.0.1', '-P', String(my.port), '-u', creds.user || 'root', '--batch', '--skip-column-names', '--connect-timeout=4', '--force'],
      { windowsHide: true, env: { ...process.env, MYSQL_PWD: creds.password || '' } });
    let out = '', err = '';
    child.stdout.on('data', d => { out += d; });
    child.stderr.on('data', d => { err += d; });
    child.on('error', () => resolve({ out: '', err: 'client mysql introuvable', failed: true }));
    child.on('close', () => resolve({ out, err }));
    child.stdin.end(sql);
  });
}

const SKIP_DBS = "'mysql','information_schema','performance_schema','sys'";
const qid = s => '`' + String(s).replace(/`/g, '``') + '`';

/**
 * Teste l'accès réel à chaque table (SELECT … LIMIT 0 : aucune donnée lue).
 * Les métadonnées de MySQL peuvent annoncer une table InnoDB alors qu'elle est illisible (« doesn't exist in engine »).
 * Renvoie [{ name: base, tables: [tables illisibles] }].
 */
async function probeTables(my, creds = {}, onlyDb = null) {
  const where = onlyDb ? `table_schema = '${String(onlyDb).replace(/'/g, "''")}'` : `table_schema NOT IN (${SKIP_DBS})`;
  const list = await mysqlScript(my, creds, `SELECT table_schema, table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND ${where};`);
  if (list.failed || /ERROR (1045|2003)/.test(list.err)) return [];
  const tables = list.out.split(/\r?\n/).filter(Boolean).map(l => l.split('\t'));
  if (!tables.length) return [];
  const sql = tables.map(([d, t]) => `SELECT 1 FROM ${qid(d)}.${qid(t)} LIMIT 0;`).join('\n');
  const r = await mysqlScript(my, creds, sql);
  const broken = new Map();
  for (const m of r.err.matchAll(/ERROR (?:1932|1146|1033|1812|1030)[^\n]*?Table '([^'.]+)\.([^']+)'/g)) {
    if (!broken.has(m[1])) broken.set(m[1], new Set());
    broken.get(m[1]).add(m[2]);
  }
  // Erreurs sans nom de table (« Incorrect information in file ») : on retrouve la table par le numéro de ligne.
  for (const m of r.err.matchAll(/ERROR \d+ \(\w+\) at line (\d+): (?!.*Table ')/g)) {
    const t = tables[Number(m[1]) - 1];
    if (t) { if (!broken.has(t[0])) broken.set(t[0], new Set()); broken.get(t[0]).add(t[1]); }
  }
  return [...broken].map(([name, set]) => ({ name, tables: [...set], count: set.size })).sort((a, b) => a.name.localeCompare(b.name));
}

// ---------- Diagnostic ----------
// Un seul passage netstat + PowerShell pour tous les serveurs : ports en écoute et processus concernés.
async function snapshotProcesses() {
  const ports = await listeningPorts();
  const pids = [...new Set([...ports.values()])].filter(p => p > 4);
  const filter = ["Name='mysqld.exe'", "Name='mariadbd.exe'", "Name='httpd.exe'", ...pids.map(p => `ProcessId=${p}`)].join(' or ');
  const list = await processes(filter);
  return { ports, list };
}

// Diagnostic de tous les serveurs détectés (le programme qui occupe un port est identifié, y compris l'autre serveur local).
async function diagnoseAll(servers) {
  const snap = await snapshotProcesses();
  return Promise.all(servers.map(s => diagnose(s, servers, snap)));
}

async function diagnose(server, servers = [server], snap = null) {
  snap = snap || await snapshotProcesses();
  const ownerOf = port => {
    const pid = snap.ports.get(port);
    if (!pid) return null;
    if (pid === 4) return { pid, name: 'System', exe: '', system: true };
    const p = snap.list.find(x => x.pid === pid) || { pid, name: '?', exe: '' };
    const other = servers.find(s => s !== server && (same(p.exe, s.mysqld) || same(p.exe, s.httpd)));
    return other ? { ...p, server: other.type, serverId: other.base } : p;
  };
  const result = { id: server.base, type: server.type, base: server.base };
  const my = mysqlConfig(server);
  if (my) {
    const owner = ownerOf(my.port);
    const running = !!owner;
    const own = owner && same(owner.exe, server.mysqld);
    const procs = snap.list.filter(p => /^(mysqld|mariadbd)\.exe$/i.test(p.name) && same(p.exe, server.mysqld));
    const log = analyseMysqlLog(readTail(my.log));
    const issues = [...log.issues];
    if (running && !own) {
      issues.unshift(owner.server
        ? { id: 'port', title: `Le port ${my.port} est utilisé par le MySQL de ${owner.server}`, detail: `Un seul MySQL peut utiliser le port ${my.port} à la fois. Arrête celui de ${owner.server} pour démarrer celui-ci.`, fix: 'stop-other', other: owner.serverId, service: 'mysql' }
        : { id: 'port', title: `Le port ${my.port} est pris par un autre programme`, detail: `${owner.name}${owner.exe ? ` (${owner.exe})` : ''} écoute sur le port de MySQL : ce MySQL-ci ne peut pas démarrer.`, fix: 'kill-port', pid: owner.pid, port: my.port });
    }
    if (!running && procs.length) issues.unshift({ id: 'zombie', title: 'MySQL est bloqué', detail: `Le processus mysqld (PID ${procs.map(p => p.pid).join(', ')}) tourne mais n'accepte pas de connexion.`, fix: 'kill-mysqld' });
    const warnings = [];
    if (log.history.recoveries >= 2) warnings.push(`MySQL a été arrêté brutalement ${log.history.recoveries} fois (récupération après crash au démarrage). Arrête-le avec le bouton « Arrêter » plutôt qu'en fermant XAMPP ou l'ordinateur.`);
    if (log.history.pastCorruption) warnings.push(`Corruption InnoDB détectée dans l'historique${log.history.lastCorruption ? ` (dernière le ${log.history.lastCorruption})` : ''} : fais une sauvegarde de tes bases dès maintenant.`);
    if (fs.existsSync(path.join(my.datadir, 'mysqld.dmp'))) warnings.push(`Un fichier de crash (mysqld.dmp, ${new Date(fs.statSync(path.join(my.datadir, 'mysqld.dmp')).mtimeMs).toLocaleString('fr-FR')}) est présent : MySQL a planté au moins une fois.`);
    // Quand MySQL tourne normalement, les erreurs de la session en cours sont des alertes, pas une panne.
    // Tables connues de MySQL mais absentes du moteur InnoDB (« doesn't exist in engine ») : données inaccessibles.
    let broken = [];
    if (running && own && my.client) {
      // Deux tests d'accès espacés : on ne signale que les tables durablement illisibles (pas une erreur passagère).
      const first = await probeTables(my);
      if (first.length) {
        await sleep(1500);
        const second = await probeTables(my);
        broken = second.map(b => {
          const f = first.find(x => x.name === b.name);
          const tables = f ? b.tables.filter(t => f.tables.includes(t)) : [];
          return { name: b.name, tables, count: tables.length };
        }).filter(b => b.count);
      }
      if (broken.length) {
        const total = broken.reduce((n, b) => n + b.count, 0);
        issues.unshift({ id: 'orphan-tables', title: `${total} tables inaccessibles dans ${broken.length} base${broken.length > 1 ? 's' : ''}`,
          detail: 'MySQL connaît ces tables mais le moteur InnoDB ne les retrouve plus (« doesn\'t exist in engine ») : leurs données ne sont plus lisibles. Cause habituelle : arrêt brutal ou fichier ibdata1 remplacé. Solutions : restaurer la base depuis une sauvegarde, ou la recréer avec les migrations du projet.',
          fix: 'orphan', databases: broken });
      }
    }
    const status = running && own ? (issues.length || warnings.length ? 'warning' : 'ok') : running ? 'conflict' : 'stopped';
    result.mysql = {
      status, running: running && own, port: my.port, owner: own ? null : owner, pids: procs.map(p => p.pid),
      datadir: my.datadir, log: my.log, logTail: log.session, issues, warnings,
      canRestore: !!my.backupDir, mariadb: my.mariadb, canDump: !!my.mysqldump
    };
  }
  const ap = apacheConfig(server);
  if (ap) {
    const owners = ap.ports.map(port => { const o = ownerOf(port); return { port, owner: o, own: !!o && same(o.exe, server.httpd) }; });
    const running = owners.some(o => o.own);
    const test = await configTest(server);
    const log = analyseApacheLog(readTail(ap.log, 150000));
    const issues = [...log.issues];
    const seenOther = new Set();
    for (const o of owners) {
      if (!o.owner || o.own) continue;
      if (o.owner.server) {
        if (seenOther.has(o.owner.serverId)) continue;
        seenOther.add(o.owner.serverId);
        issues.unshift({ id: 'port', port: o.port, title: `Le port ${o.port} est utilisé par l'Apache de ${o.owner.server}`, detail: `Un seul Apache peut utiliser ces ports. Arrête celui de ${o.owner.server}${ap.editable ? ', ou change le port de celui-ci' : ''}.`, fix: 'stop-other', other: o.owner.serverId, service: 'apache' });
      } else {
        issues.unshift({ id: 'port', port: o.port, title: `Le port ${o.port} est pris par ${o.owner.system ? 'Windows (service HTTP)' : o.owner.name}`, detail: o.owner.system ? 'Le service HTTP de Windows (IIS, partage, WinRM...) utilise ce port. Le plus simple : changer le port d\'Apache.' : `${o.owner.exe || o.owner.name} empêche Apache d'utiliser ce port. Arrête ce programme ou change le port d'Apache.`, fix: o.owner.system ? 'apache-port' : 'kill-port', pid: o.owner.pid });
      }
    }
    if (test && !test.ok) issues.unshift({ id: 'syntax', title: 'Configuration Apache invalide', detail: test.output.split('\n').slice(0, 4).join(' '), fix: 'open-config' });
    const status = running ? (issues.some(i => i.id !== 'port') ? 'warning' : 'ok') : owners.some(o => o.owner && !o.own) ? 'conflict' : 'stopped';
    result.apache = {
      status, running, ports: owners.map(o => ({ port: o.port, own: o.own, owner: o.own ? null : o.owner })), conf: ap.conf, log: ap.log,
      logTail: log.session, issues, configTest: test, editablePorts: ap.editable,
      warnings: log.unclean ? [`Apache a été arrêté brutalement ${log.unclean} fois (« Unclean shutdown »).`] : []
    };
  }
  return result;
}

// ---------- Arrêt / démarrage ----------
async function stopMysql(server, { force = false, user = 'root', password = '' } = {}) {
  const my = mysqlConfig(server);
  if (!(await isPortOpen(my.port)) && !(await processes("Name='mysqld.exe' or Name='mariadbd.exe'")).some(p => same(p.exe, server.mysqld))) return { ok: true, message: 'MySQL est déjà arrêté.' };
  if (my.mysqladmin && !force) {
    // Arrêt propre : MySQL écrit ses journaux et ferme ses fichiers (évite la corruption).
    const ok = await new Promise(resolve => execFile(my.mysqladmin, ['--protocol=TCP', '-P', String(my.port), '-u', user, 'shutdown'],
      { windowsHide: true, timeout: 30000, env: { ...process.env, MYSQL_PWD: password } }, err => resolve(!err)));
    if (ok) {
      for (let i = 0; i < 40 && await isPortOpen(my.port); i++) await sleep(500);
      if (!(await isPortOpen(my.port))) return { ok: true, message: 'MySQL arrêté proprement.' };
    }
    if (!force) return { ok: false, needForce: true, message: 'L\'arrêt propre a échoué (mot de passe root ou MySQL bloqué).' };
  }
  for (const p of (await processes("Name='mysqld.exe' or Name='mariadbd.exe'")).filter(x => same(x.exe, server.mysqld))) await killPid(p.pid);
  for (let i = 0; i < 20 && await isPortOpen(my.port); i++) await sleep(300);
  return { ok: !(await isPortOpen(my.port)), message: 'MySQL arrêté (forcé).' };
}

async function startMysql(server) {
  const my = mysqlConfig(server);
  if (await isPortOpen(my.port)) {
    const o = await portOwner(my.port);
    if (o && same(o.exe, server.mysqld)) return { ok: true, message: 'MySQL est déjà démarré.' };
    return { ok: false, message: `Le port ${my.port} est utilisé par ${o ? o.name : 'un autre programme'}.` };
  }
  const offset = fileSize(my.log);
  const args = fs.existsSync(server.myini) ? [`--defaults-file=${server.myini}`, '--standalone'] : ['--standalone'];
  const child = spawn(server.mysqld, args, { cwd: my.bin, windowsHide: true, detached: true, stdio: 'ignore' });
  child.on('error', () => { /* binaire inutilisable */ });
  child.unref();
  for (let i = 0; i < 40; i++) {
    if (await isPortOpen(my.port)) return { ok: true, message: 'MySQL démarré.' };
    if (child.exitCode !== null) break;
    await sleep(500);
  }
  const excerpt = readFrom(my.log, offset);
  return { ok: false, message: 'MySQL n\'a pas démarré.', log: excerpt.split(/\r?\n/).slice(-60).join('\n'), issues: analyseMysqlLog(excerpt).issues };
}

async function stopApache(server) {
  const procs = (await processes("Name='httpd.exe'")).filter(p => same(p.exe, server.httpd));
  const parents = procs.filter(p => !procs.some(q => q.pid === p.ppid));
  for (const p of parents) await killPid(p.pid);
  await sleep(800);
  return { ok: true, message: procs.length ? 'Apache arrêté.' : 'Apache est déjà arrêté.' };
}

async function startApache(server) {
  const ap = apacheConfig(server);
  const test = await configTest(server);
  if (test && !test.ok) return { ok: false, message: 'La configuration Apache contient une erreur.', log: test.output };
  const offset = fileSize(ap.log);
  const child = spawn(server.httpd, [], { cwd: path.dirname(server.httpd), windowsHide: true, detached: true, stdio: 'ignore' });
  child.on('error', () => { /* binaire inutilisable */ });
  child.unref();
  const port = ap.ports[0] || 80;
  for (let i = 0; i < 30; i++) {
    if (await isPortOpen(port)) {
      const o = await portOwner(port);
      if (o && same(o.exe, server.httpd)) return { ok: true, message: 'Apache démarré.' };
    }
    if (child.exitCode !== null) break;
    await sleep(500);
  }
  const excerpt = readFrom(ap.log, offset);
  return { ok: false, message: 'Apache n\'a pas démarré.', log: excerpt.split(/\r?\n/).slice(-40).join('\n'), issues: analyseApacheLog(excerpt).issues };
}

// ---------- Réparations ----------
// Journaux Aria (MariaDB) : déplacés dans un dossier de sauvegarde, MariaDB les recrée au démarrage.
async function repairAria(server) {
  const my = mysqlConfig(server);
  const stop = await stopMysql(server, { force: true });
  if (!stop.ok) throw new Error('Impossible d\'arrêter MySQL.');
  const saveDir = path.join(path.dirname(my.datadir), `devlauncher-reparation-${stamp()}`);
  fs.mkdirSync(saveDir, { recursive: true });
  const moved = [];
  for (const f of fs.readdirSync(my.datadir)) {
    if (/^aria_log(_control|\.\d+)$/i.test(f) || /\.pid$/i.test(f)) { fs.renameSync(path.join(my.datadir, f), path.join(saveDir, f)); moved.push(f); }
  }
  const start = await startMysql(server);
  return { ...start, steps: [`Fichiers mis de côté dans ${saveDir} : ${moved.join(', ') || 'aucun'}`, start.message] };
}

// Méthode officielle XAMPP (« MySQL shutdown unexpectedly ») :
// data -> data_old_<date> (conservé), copie de mysql\backup -> data, puis on remet les dossiers des bases et ibdata1.
async function restoreSystem(server) {
  const my = mysqlConfig(server);
  if (!my.backupDir) throw new Error('Pas de dossier mysql\\backup : cette réparation n\'est disponible que pour XAMPP.');
  const stop = await stopMysql(server, { force: true });
  if (!stop.ok) throw new Error('Impossible d\'arrêter MySQL.');
  const steps = [];
  const old = `${my.datadir}_old_${stamp()}`;
  fs.renameSync(my.datadir, old);
  steps.push(`Dossier data actuel conservé : ${old}`);
  fs.cpSync(my.backupDir, my.datadir, { recursive: true });
  steps.push('Tables système saines copiées depuis mysql\\backup');
  const skip = new Set(['mysql', 'performance_schema', 'phpmyadmin']);
  const dbs = [];
  for (const e of fs.readdirSync(old, { withFileTypes: true })) {
    if (e.isDirectory() && !skip.has(e.name.toLowerCase())) { fs.cpSync(path.join(old, e.name), path.join(my.datadir, e.name), { recursive: true, force: true }); dbs.push(e.name); }
  }
  steps.push(`Bases remises en place : ${dbs.join(', ') || 'aucune'}`);
  if (fs.existsSync(path.join(old, 'ibdata1'))) { fs.copyFileSync(path.join(old, 'ibdata1'), path.join(my.datadir, 'ibdata1')); steps.push('Fichier ibdata1 (données InnoDB) remis en place'); }
  const start = await startMysql(server);
  steps.push(start.message);
  return { ...start, steps, oldDir: old };
}

// Change les ports d'Apache dans httpd.conf / httpd-ssl.conf (XAMPP), avec copie .devlauncher.bak.
function setApachePorts(server, http, https) {
  const ap = apacheConfig(server);
  if (!ap.editable) throw new Error('Le port d\'Apache se change dans le panneau de ce serveur (Laragon, WAMP).');
  const ok = n => Number.isInteger(n) && n > 0 && n < 65536;
  if (!ok(http) || (https !== undefined && !ok(https))) throw new Error('Port invalide.');
  const edit = (file, from, to, extra) => {
    let t = fs.readFileSync(file, 'utf8');
    fs.writeFileSync(file + '.devlauncher.bak', t);
    t = t.replace(new RegExp(`^(\\s*Listen\\s+(?:[\\d.]+:)?)${from}\\b`, 'gim'), `$1${to}`);
    t = extra(t);
    fs.writeFileSync(file, t);
  };
  const oldHttp = Number((fs.readFileSync(ap.conf, 'utf8').match(/^\s*Listen\s+(?:[\d.]+:)?(\d+)/im) || [])[1] || 80);
  edit(ap.conf, oldHttp, http, t => t.replace(new RegExp(`^(\\s*ServerName\\s+[^:\\s]+):${oldHttp}\\b`, 'gim'), `$1:${http}`));
  if (ap.ssl && https) {
    const oldHttps = (fs.readFileSync(ap.ssl, 'utf8').match(/^\s*Listen\s+(?:[\d.]+:)?(\d+)/im) || [])[1] || 443;
    edit(ap.ssl, oldHttps, https, t => t.replace(new RegExp(`(<VirtualHost\\s+[^:>]+):${oldHttps}>`, 'gi'), `$1:${https}>`).replace(new RegExp(`^(\\s*ServerName\\s+[^:\\s]+):${oldHttps}\\b`, 'gim'), `$1:${https}`));
  }
  return { ok: true, message: `Apache écoutera sur le port ${http}${https ? ` (HTTPS : ${https})` : ''}.` };
}

module.exports = { diagnose, diagnoseAll, readTail, probeTables, mysqlConfig, apacheConfig, stopMysql, startMysql, stopApache, startApache, repairAria, restoreSystem, setApachePorts, portOwner, killPid, isPortOpen, processes, same };
