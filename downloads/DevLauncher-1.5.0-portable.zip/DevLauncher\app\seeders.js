// Seeders Laravel : liste des fichiers, ordre d'appel par DatabaseSeeder, tables / modèles remplis, lecture du code.
const fs = require('fs');
const path = require('path');
const Hz = require('./humanize');

function seedersDir(p) {
  for (const d of ['database/seeders', 'database/seeds']) {
    const full = path.join(p.path, d);
    if (fs.existsSync(full)) return full;
  }
  return null;
}

// Classes appelées par $this->call(...) / ->call([...]), dans l'ordre du fichier.
function callsOf(src) {
  const out = [];
  const re = /->\s*call(?:Silent|With)?\s*\(\s*(\[[\s\S]*?\]|[^;]*?)\s*\)\s*;/g;
  let m;
  while ((m = re.exec(src))) {
    for (const c of m[1].matchAll(/([\\\w]+)::class/g)) out.push(c[1].split('\\').pop());
  }
  return out;
}

// Modèles et tables remplis : Model::create / factory / firstOrCreate..., DB::table('x')->insert...
function targetsOf(src) {
  const models = new Set(), tables = new Set();
  for (const m of src.matchAll(/\b([A-Z]\w+)::(?:create|factory|firstOrCreate|updateOrCreate|insert|upsert|firstOrNew|forceCreate|query\(\)\s*->\s*(?:create|insert|updateOrCreate))\b/g)) {
    if (!['DB', 'Hash', 'Str', 'Carbon', 'Schema', 'Arr', 'Log', 'Role', 'Permission'].includes(m[1]) || ['Role', 'Permission'].includes(m[1])) models.add(m[1]);
  }
  for (const m of src.matchAll(/DB::table\(\s*['"]([\w.]+)['"]\s*\)/g)) tables.add(m[1]);
  // Écriture indirecte (new Modele(...)->save(), Modele::query()->...) : à défaut, les modèles importés en tête du fichier.
  if (!models.size && !tables.size) {
    for (const m of src.matchAll(/^use\s+App\\Models\\(\w+)\s*;/gm)) if (new RegExp(`\\b${m[1]}\\b`).test(src.split(/class\s+\w+/)[1] || '')) models.add(m[1]);
  }
  return { models: [...models], tables: [...tables] };
}

// Libellé en français de ce que remplit un seeder (« Devises, Rôles et permissions »).
function describe(t) {
  const labels = [
    ...t.models.map(m => { try { return Hz.modelLabel(m); } catch { return m; } }),
    ...t.tables.map(tb => 'table ' + tb)
  ];
  return [...new Set(labels)];
}

function list(p) {
  const dir = seedersDir(p);
  if (!dir) return { dir: null, seeders: [], order: [] };
  const files = [];
  const walk = (d, depth) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, e.name);
      if (e.isDirectory() && depth < 2) walk(full, depth + 1);
      else if (e.isFile() && e.name.endsWith('.php')) files.push(full);
    }
  };
  walk(dir, 0);
  const seeders = files.map(file => {
    const src = fs.readFileSync(file, 'utf8');
    const cls = (src.match(/class\s+(\w+)\s+extends/) || [])[1] || path.basename(file, '.php');
    const ns = (src.match(/namespace\s+([\w\\]+)\s*;/) || [])[1] || '';
    const targets = targetsOf(src);
    const st = fs.statSync(file);
    return {
      class: cls, fqcn: ns ? `${ns}\\${cls}` : cls, file: path.relative(p.path, file).replace(/\\/g, '/'),
      calls: callsOf(src), fills: describe(targets), models: targets.models, tables: targets.tables,
      lines: src.split('\n').length, mtime: st.mtimeMs, main: cls === 'DatabaseSeeder'
    };
  }).sort((a, b) => (b.main - a.main) || a.class.localeCompare(b.class));

  // Ordre réel de DatabaseSeeder, appels imbriqués compris (un seeder qui en appelle d'autres).
  const byClass = new Map(seeders.map(s => [s.class, s]));
  const order = [];
  const visit = (cls, stack) => {
    const s = byClass.get(cls);
    if (!s || stack.includes(cls)) return;
    for (const c of s.calls) { if (!order.includes(c) && byClass.has(c)) order.push(c); visit(c, [...stack, cls]); }
  };
  visit('DatabaseSeeder', []);
  for (const s of seeders) s.position = order.indexOf(s.class) + 1; // 0 : non appelé par DatabaseSeeder
  return { dir: path.relative(p.path, dir).replace(/\\/g, '/'), seeders, order };
}

function read(p, file) {
  const dir = seedersDir(p);
  const full = path.resolve(p.path, String(file || ''));
  if (!dir || !full.startsWith(path.resolve(dir) + path.sep) || !full.endsWith('.php')) throw new Error('Fichier de seeder introuvable.');
  const text = fs.readFileSync(full, 'utf8');
  return { file, path: full, text: text.length > 200000 ? text.slice(0, 200000) + '\n// (fichier tronqué)' : text };
}

module.exports = { list, read, seedersDir, callsOf, targetsOf };
