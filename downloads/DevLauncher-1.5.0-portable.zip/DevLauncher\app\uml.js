// Diagrammes UML d'un projet : fichiers .puml (docs/uml), génération depuis le code, export PNG / PDF.
// Syntaxe : sous-ensemble de PlantUML (classes, séquence, activité).
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const Hz = require('./humanize');
// Versions « langage courant » (chargées à la demande : umlHuman.js utilise ce module)
const Hm = () => require('./umlHuman');

const SKIP = /[\\/](vendor|node_modules|\.git|storage|bootstrap[\\/]cache|public[\\/]build|\.next|\.nuxt|dist|build|coverage)([\\/]|$)/i;
const read = f => { try { return fs.readFileSync(f, 'utf8'); } catch { return ''; } };

function walk(dir, exts, limit = 4000, out = []) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    if (out.length >= limit) break;
    const full = path.join(dir, e.name);
    if (SKIP.test(full) || e.name.startsWith('.')) continue;
    if (e.isDirectory()) walk(full, exts, limit, out);
    else if (exts.test(e.name)) out.push(full);
  }
  return out;
}

// ---------- Fichiers de diagrammes ----------
const umlDir = p => path.join(p.path, 'docs', 'uml');
const safeName = n => String(n || '').trim().replace(/[<>:"/\\|?*\x00-\x1f]/g, '').replace(/\s+/g, ' ').slice(0, 80);

function typeOf(text) {
  const m = text.match(/^'\s*type\s*:\s*(class|sequence|activity)/m);
  if (m) return m[1];
  if (/^\s*(start|stop)\s*$/m.test(text) || /^\s*:[^;]*;/m.test(text)) return 'activity';
  if (/^\s*(actor|participant|database|entity|boundary|control)\s/m.test(text) || /^\s*\w+\s*-+>>?\s*\w+\s*:/m.test(text)) return 'sequence';
  return 'class';
}

function list(p) {
  const dir = umlDir(p);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter(f => f.endsWith('.puml')).map(f => {
    const full = path.join(dir, f);
    const text = read(full);
    const name = f.slice(0, -5);
    return {
      name, type: typeOf(text), mtime: fs.statSync(full).mtimeMs,
      png: fs.existsSync(path.join(dir, name + '.png')), pdf: fs.existsSync(path.join(dir, name + '.pdf'))
    };
  }).sort((a, b) => b.mtime - a.mtime);
}

function readDiagram(p, name) {
  const f = path.join(umlDir(p), safeName(name) + '.puml');
  if (!fs.existsSync(f)) throw new Error('Diagramme introuvable.');
  return read(f);
}

function save(p, name, text) {
  const n = safeName(name);
  if (!n) throw new Error('Nom de diagramme invalide.');
  fs.mkdirSync(umlDir(p), { recursive: true });
  fs.writeFileSync(path.join(umlDir(p), n + '.puml'), text);
  return { name: n };
}

function remove(p, name) {
  const n = safeName(name);
  for (const ext of ['.puml', '.png', '.pdf']) fs.rmSync(path.join(umlDir(p), n + ext), { force: true });
  return true;
}

// ---------- Analyse de code (PHP / JS / TS) ----------
// Supprime commentaires et contenu des chaînes en gardant les longueurs (positions stables pour les accolades).
function maskCode(src) {
  let out = '', i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i], d = src[i + 1];
    if (c === '/' && d === '/' || c === '#' && d !== '[') { const e = src.indexOf('\n', i); const end = e < 0 ? n : e; out += ' '.repeat(end - i); i = end; continue; }
    if (c === '/' && d === '*') { const e = src.indexOf('*/', i + 2); const end = e < 0 ? n : e + 2; out += src.slice(i, end).replace(/[^\n]/g, ' '); i = end; continue; }
    if (c === '"' || c === "'" || c === '`') {
      let j = i + 1;
      while (j < n && src[j] !== c) { if (src[j] === '\\') j++; j++; }
      out += c + src.slice(i + 1, j).replace(/[^\n]/g, '_') + (j < n ? c : '');
      i = j + 1;
      continue;
    }
    out += c; i++;
  }
  return out;
}

// Indice de la parenthèse / accolade fermante correspondante.
function matchClose(m, open) {
  const pairs = { '(': ')', '{': '}', '[': ']' };
  const stack = [];
  for (let i = open; i < m.length; i++) {
    const ch = m[i];
    if (pairs[ch]) stack.push(pairs[ch]);
    else if (ch === stack[stack.length - 1]) { stack.pop(); if (!stack.length) return i; }
  }
  return m.length - 1;
}

const clean = s => s.replace(/\s+/g, ' ').trim();

// Découpe un bloc de code en instructions structurées : stmt, if, loop, try, return, switch.
function parseBlock(src, m, start, end) {
  const out = [];
  let i = start;
  const ws = () => { while (i < end && /\s/.test(m[i])) i++; };
  const kw = word => new RegExp(`^${word}\\b`).test(m.slice(i, i + word.length + 1));
  const readParen = () => { ws(); if (m[i] !== '(') return ''; const c = matchClose(m, i); const txt = src.slice(i + 1, c); i = c + 1; return clean(txt); };
  const readBody = () => {
    ws();
    if (m[i] === '{') { const c = matchClose(m, i); const body = parseBlock(src, m, i + 1, c); i = c + 1; return body; }
    if (m[i] === ':') { // syntaxe alternative PHP (if: ... endif;) : on prend jusqu'au mot de fin
      const rest = m.slice(i + 1, end); const e = rest.search(/\b(endif|endforeach|endwhile|endfor|else|elseif)\b/);
      const stop = e < 0 ? end : i + 1 + e; const body = parseBlock(src, m, i + 1, stop); i = stop; return body;
    }
    const s = i; const body = []; // instruction unique sans accolades
    const one = parseBlock(src, m, s, end);
    if (one.length) { body.push(one[0]); i = one[0]._end; }
    return body;
  };
  while (i < end) {
    ws();
    if (i >= end) break;
    const at = i;
    if (kw('if')) {
      i += 2;
      const node = { type: 'if', branches: [{ cond: readParen(), body: readBody() }], else: null };
      for (;;) {
        ws();
        if (kw('elseif')) { i += 6; node.branches.push({ cond: readParen(), body: readBody() }); continue; }
        if (kw('else')) {
          const save = i; i += 4; ws();
          if (kw('if')) { i += 2; node.branches.push({ cond: readParen(), body: readBody() }); continue; }
          i = save + 4; node.else = readBody(); break;
        }
        break;
      }
      ws(); if (kw('endif')) { i += 5; ws(); if (m[i] === ';') i++; }
      node._end = i; out.push(node); continue;
    }
    const loop = ['foreach', 'for', 'while'].find(k => kw(k));
    if (loop) {
      i += loop.length;
      const node = { type: 'loop', kind: loop, cond: readParen(), body: readBody() };
      ws(); if (/^end(foreach|for|while)\b/.test(m.slice(i, i + 12))) { i = m.indexOf(';', i) + 1 || end; }
      node._end = i; out.push(node); continue;
    }
    if (kw('do')) {
      i += 2; const body = readBody(); ws();
      let cond = '';
      if (kw('while')) { i += 5; cond = readParen(); ws(); if (m[i] === ';') i++; }
      out.push({ type: 'loop', kind: 'do', cond, body, _end: i }); continue;
    }
    if (kw('try')) {
      i += 3; const node = { type: 'try', body: readBody(), catches: [], _end: 0 };
      for (;;) {
        ws();
        if (kw('catch')) { i += 5; node.catches.push({ type: readParen(), body: readBody() }); continue; }
        if (kw('finally')) { i += 7; node.finally = readBody(); continue; }
        break;
      }
      node._end = i; out.push(node); continue;
    }
    if (kw('switch')) {
      i += 6; const cond = readParen(); ws();
      if (m[i] === '{') i = matchClose(m, i) + 1;
      out.push({ type: 'stmt', text: `switch (${cond})`, _end: i }); continue;
    }
    // Instruction jusqu'au ';' de niveau 0 (les fermetures et tableaux imbriqués sont sautés)
    let j = i;
    while (j < end) {
      const ch = m[j];
      if (ch === '(' || ch === '{' || ch === '[') { j = matchClose(m, j) + 1; continue; }
      if (ch === ';') break;
      if (ch === '}') break;
      j++;
    }
    const text = clean(src.slice(i, j));
    i = j + 1;
    if (!text) continue;
    if (/^(return|throw)\b/.test(text)) out.push({ type: 'return', text, _end: i });
    else if (!/^(use|namespace|declare|import|export\s+\{)\b/.test(text)) out.push({ type: 'stmt', text, _end: i });
    if (i <= at) i = at + 1;
  }
  return out;
}

// Fonctions d'un fichier (méthodes de classe, fonctions, fonctions fléchées nommées).
function functionsOf(file) {
  const src = read(file);
  const m = maskCode(src);
  const fns = [];
  const classes = [...m.matchAll(/\b(class|trait)\s+(\w+)[^{]*\{/g)].map(c => ({ name: c[2], start: c.index + c[0].length - 1, end: matchClose(m, c.index + c[0].length - 1) }));
  const classAt = pos => (classes.find(c => pos > c.start && pos < c.end) || {}).name || null;
  const re = /\b(?:(public|protected|private|static|async|export|default)\s+)*function\s*\*?\s*(\w+)\s*\(|\b(?:const|let)\s+(\w+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|\w+)\s*=>\s*\{|^\s*(?:(?:public|private|protected|static|async|get|set)\s+)*(\w+)\s*\([^)]*\)\s*(?::\s*[\w<>[\]|, .]+)?\s*\{/gm;
  let r;
  while ((r = re.exec(m))) {
    const name = r[2] || r[3] || r[4];
    if (!name || /^(if|for|foreach|while|switch|catch|function|return|constructor)$/.test(name) && name !== 'constructor') continue;
    const brace = m.indexOf('{', r.index + r[0].length - 1 >= 0 ? r.index : 0);
    const open = m[r.index + r[0].length - 1] === '{' ? r.index + r[0].length - 1 : m.indexOf('{', r.index + r[0].length);
    if (open < 0) continue;
    // Méthode abstraite / d'interface (pas de corps) : on l'ignore
    const between = m.slice(r.index + r[0].length, open);
    if (between.includes(';')) continue;
    const close = matchClose(m, open);
    const params = r[0].includes('(') ? clean(src.slice(r.index + r[0].indexOf('(') + 1, matchClose(m, r.index + r[0].indexOf('(')))) : '';
    fns.push({ name, class: classAt(r.index), line: src.slice(0, r.index).split('\n').length, start: open, end: close, params });
    void brace;
  }
  return { src, m, fns };
}

// ---------- Diagramme d'activité ----------
const ACTION_RULES = [
  [/^\$?\w*\s*=?\s*\$request->validate\(/, () => 'Valider les données de la requête'],
  [/->validated\(\)/, () => 'Récupérer les données validées'],
  [/^(?:\$\w+\s*=\s*)?([A-Z]\w+)::create\(/, m => `Créer ${m[1]}`],
  [/^(?:\$\w+\s*=\s*)?([A-Z]\w+)::(?:find|findOrFail|first|firstOrFail)\(/, m => `Charger ${m[1]}`],
  [/^(?:\$\w+\s*=\s*)?([A-Z]\w+)::(?:where|query|with|latest|orderBy|all|paginate)\b/, m => `Rechercher des ${m[1]}`],
  [/->update\(/, () => 'Mettre à jour l\'enregistrement'],
  [/->save\(\)/, () => 'Enregistrer'],
  [/->delete\(\)/, () => 'Supprimer l\'enregistrement'],
  [/^Mail::|->notify\(|Notification::send/, () => 'Envoyer une notification / un mail'],
  [/^(?:event|dispatch)\(|::dispatch\(/, () => 'Déclencher un événement / une tâche'],
  [/^DB::transaction|^DB::beginTransaction/, () => 'Démarrer une transaction'],
  [/^Auth::(?:login|attempt)|auth\(\)->(?:login|attempt)/, () => 'Authentifier l\'utilisateur'],
  [/^Storage::|->store\(|->storeAs\(/, () => 'Enregistrer le fichier'],
  [/^(?:await\s+)?fetch\(/, () => 'Appeler l\'API (fetch)'],
  [/^(?:await\s+)?(?:axios|api)\.(get|post|put|patch|delete)\(/, m => `Requête HTTP ${m[1].toUpperCase()}`],
  [/^(?:const|let|var)?\s*\[?(\w+)\]?,?\s*\w*\]?\s*=\s*useState\(/, m => `État ${m[1]}`]
];
const RETURN_RULES = [
  [/^return\s+view\(\s*['"]([^'"]+)/, m => `Afficher la vue ${m[1]}`],
  [/^return\s+(?:redirect\(\)|back\(\)|to_route\(|redirect\()/, () => 'Rediriger'],
  [/^return\s+response\(\)->json|^return\s+(?:Response|NextResponse)\.json|^return\s+res\.(?:json|status)/, () => 'Répondre en JSON'],
  [/^return\s+Inertia::render\(\s*['"]([^'"]+)/, m => `Afficher la page ${m[1]}`],
  [/^throw\s+new\s+(\w+)/, m => `Lever ${m[1]}`],
  [/^return\s+</, () => 'Afficher le rendu (JSX)']
];
const summarize = (text, rules) => {
  for (const [re, f] of rules) { const m = text.match(re); if (m) return f(m); }
  const t = text.replace(/\$this->/g, '').replace(/^\$/, '').replace(/\s*=(?![=>])\s*/, ' = ');
  return t.length > 70 ? t.slice(0, 67) + '…' : t;
};
const condText = c => { const t = c.replace(/\$this->/g, '').replace(/\$/g, ''); return t.length > 48 ? t.slice(0, 45) + '…' : t; };
const esc1 = s => String(s).replace(/;/g, ',').replace(/[\r\n]+/g, ' ');

function activityLines(nodes, depth = 1) {
  const pad = '  '.repeat(depth);
  const lines = [];
  let buffer = [];
  const flush = () => {
    if (!buffer.length) return;
    // Jusqu'à 3 instructions simples regroupées dans une même action
    for (let k = 0; k < buffer.length; k += 3) lines.push(`${pad}:${buffer.slice(k, k + 3).map(esc1).join('\\n')};`);
    buffer = [];
  };
  for (const n of nodes) {
    if (n.type === 'stmt') { buffer.push(summarize(n.text, ACTION_RULES)); continue; }
    flush();
    if (n.type === 'return') { lines.push(`${pad}:${esc1(summarize(n.text, RETURN_RULES))};`, `${pad}stop`); continue; }
    if (n.type === 'if') {
      n.branches.forEach((b, k) => {
        lines.push(`${pad}${k === 0 ? 'if' : 'elseif'} (${esc1(condText(b.cond))} ?) then (oui)`);
        lines.push(...activityLines(b.body, depth + 1));
      });
      if (n.else) { lines.push(`${pad}else (non)`); lines.push(...activityLines(n.else, depth + 1)); }
      lines.push(`${pad}endif`);
      continue;
    }
    if (n.type === 'loop') {
      const label = n.kind === 'foreach' ? `pour chaque ${condText(n.cond.replace(/^.*\bas\b/i, '').trim() || n.cond)}` : condText(n.cond);
      lines.push(`${pad}while (${esc1(label)} ?) is (oui)`);
      lines.push(...activityLines(n.body, depth + 1));
      lines.push(`${pad}endwhile (non)`);
      continue;
    }
    if (n.type === 'try') {
      lines.push(...activityLines(n.body, depth));
      for (const c of n.catches) {
        lines.push(`${pad}if (erreur ${esc1(c.type.split(/\s+/)[0].split('\\').pop())} ?) then (oui)`);
        lines.push(...activityLines(c.body, depth + 1));
        lines.push(`${pad}endif`);
      }
    }
  }
  flush();
  return lines;
}

function generateActivity(p, file, fnName, lang = 'human') {
  if (lang !== 'tech') return Hm().activityHuman(p, file, fnName);
  const full = path.join(p.path, file);
  if (!full.startsWith(p.path) || !fs.existsSync(full)) throw new Error('Fichier introuvable.');
  const { src, m, fns } = functionsOf(full);
  const fn = fns.find(f => f.name === fnName);
  if (!fn) throw new Error('Fonction introuvable dans ce fichier.');
  const body = parseBlock(src, m, fn.start + 1, fn.end);
  const title = `${fn.class ? fn.class + '::' : ''}${fn.name}()`;
  return [`@startuml`, `' type: activity`, `' source: ${file.replace(/\\/g, '/')} (ligne ${fn.line})`, `title Activité : ${title}`, 'start', ...activityLines(body), 'stop', '@enduml', ''].join('\n')
    .replace(/(\n\s*stop)\nstop\n@enduml/, '$1\n@enduml'); // pas de double « stop » final
}

// ---------- Diagramme de séquence (route Laravel) ----------
function controllerFile(p, name) {
  const short = name.split('\\').pop();
  if (name.includes('\\')) {
    const rel = name.replace(/^\\?App\\/, 'app\\').replace(/\\/g, path.sep) + '.php';
    if (fs.existsSync(path.join(p.path, rel))) return path.join(p.path, rel);
  }
  return walk(path.join(p.path, 'app'), new RegExp(`^${short}\\.php$`)).shift() || null;
}

// Routes avec leur intitulé en langage courant (title)
function routes(p) {
  return routesRaw(p).map(r => ({ ...r, title: Hz.routeTitle(r) }));
}

function routesRaw(p) {
  if (p.type !== 'laravel') return [];
  const out = [];
  for (const file of ['web.php', 'api.php', 'auth.php', 'admin.php'].map(f => path.join(p.path, 'routes', f)).filter(f => fs.existsSync(f))) {
    const src = read(file);
    const uses = Object.fromEntries([...src.matchAll(/^use\s+([\w\\]+?)(?:\s+as\s+(\w+))?;/gm)].map(u => [u[2] || u[1].split('\\').pop(), u[1]]));
    const fq = n => uses[n] || n;
    const prefix = path.basename(file) === 'api.php' ? '/api' : '';
    for (const r of src.matchAll(/Route::(get|post|put|patch|delete|any|match)\(\s*['"]([^'"]*)['"]\s*,\s*(?:\[\s*([\w\\]+)::class\s*,\s*['"](\w+)['"]\s*\]|['"]([\w\\]+)@(\w+)['"]|([\w\\]+)::class)/g)) {
      const ctrl = r[3] || r[5] || r[7];
      const method = r[4] || r[6] || '__invoke';
      out.push({ verb: r[1].toUpperCase(), uri: prefix + '/' + r[2].replace(/^\//, ''), controller: fq(ctrl), method, file: path.basename(file) });
    }
    for (const r of src.matchAll(/Route::(api)?[Rr]esources?\(\s*['"]([^'"]+)['"]\s*,\s*([\w\\]+)::class/g)) {
      const base = prefix + '/' + r[2].replace(/^\//, '');
      const param = `{${r[2].split('.').pop().replace(/s$/, '')}}`;
      const acts = [['GET', '', 'index'], ['POST', '', 'store'], ['GET', '/' + param, 'show'], ['PUT', '/' + param, 'update'], ['DELETE', '/' + param, 'destroy']];
      if (!r[1]) acts.splice(1, 0, ['GET', '/create', 'create']), acts.splice(4, 0, ['GET', `/${param}/edit`, 'edit']);
      for (const [verb, suffix, method] of acts) out.push({ verb, uri: base + suffix, controller: fq(r[3]), method, file: path.basename(file), resource: true });
    }
  }
  return out;
}

// Appels repérés dans une instruction : modèle, service injecté, façade, vue, redirection...
function callsIn(text, ctx) {
  const calls = [];
  for (const m of text.matchAll(/\b([A-Z]\w+)::(\w+)\(/g)) {
    if (['Auth', 'DB', 'Mail', 'Storage', 'Cache', 'Log', 'Hash', 'Session', 'Str', 'Arr', 'Carbon', 'Validator', 'Gate', 'Event', 'Notification', 'Http', 'Route', 'Response', 'Redirect', 'View', 'Inertia', 'Config', 'URL'].includes(m[1])) {
      if (['Str', 'Arr', 'Carbon', 'Log', 'Config', 'URL', 'Route', 'Response', 'Redirect', 'View', 'Inertia'].includes(m[1])) continue;
      calls.push({ to: m[1], label: `${m[2]}()`, ret: m[1] === 'DB' || m[1] === 'Http' ? 'résultat' : null });
    } else if (ctx.models.has(m[1]) || /^[A-Z]\w+$/.test(m[1]) && ctx.knownClasses.has(m[1])) {
      calls.push({ to: m[1], label: `${m[2]}()`, ret: /^(create|find|findOrFail|first|firstOrFail|where|all|paginate|get|query|with|latest|count|exists|pluck)/.test(m[2]) ? (/^(create)$/.test(m[2]) ? `nouveau ${m[1]}` : m[1]) : null });
    }
  }
  for (const m of text.matchAll(/\$this->(\w+)->(\w+)\(/g)) {
    const type = ctx.props[m[1]] || m[1];
    calls.push({ to: type, label: `${m[2]}()`, ret: 'résultat' });
  }
  for (const m of text.matchAll(/\$(\w+)->(save|update|delete|load|refresh|attach|detach|sync|fill)\(/g)) {
    const t = ctx.vars[m[1]];
    if (t) calls.push({ to: t, label: `${m[2]}()`, ret: null });
  }
  if (/\$request->validate\(|->validated\(\)/.test(text)) calls.push({ to: ctx.request || 'Request', label: 'validate()', ret: 'données validées' });
  if (/\bevent\(|::dispatch\(|dispatch\(/.test(text) && !calls.some(c => c.to === 'Event')) calls.push({ to: 'Event', label: 'dispatch()', ret: null, async: true });
  return calls;
}

function generateSequence(p, routeIndex, lang = 'human') {
  if (lang !== 'tech') return Hm().sequenceHuman(p, routeIndex);
  const r = routes(p)[Number(routeIndex)];
  if (!r) throw new Error('Route introuvable.');
  const file = controllerFile(p, r.controller);
  const ctrl = r.controller.split('\\').pop();
  const lines = ['@startuml', "' type: sequence", `' source: routes/${r.file} → ${ctrl}@${r.method}`, `title Séquence : ${r.verb} ${r.uri}`, 'actor Utilisateur', 'participant Routeur', `participant ${ctrl}`];
  const pad = d => '  '.repeat(d);
  const out = [`Utilisateur -> Routeur : ${r.verb} ${r.uri}`, `Routeur -> ${ctrl} : ${r.method}()`];
  let finalReturn = null;
  if (file) {
    const { src, m, fns } = functionsOf(file);
    const fn = fns.find(f => f.name === r.method && f.class === ctrl) || fns.find(f => f.name === r.method);
    const models = new Set(walk(path.join(p.path, 'app', 'Models'), /\.php$/).map(f => path.basename(f, '.php')));
    const ctx = { models, knownClasses: models, props: {}, vars: {}, request: null };
    // Propriétés injectées (constructeur) : private PostService $service
    const ctor = fns.find(f => f.name === '__construct');
    if (ctor) for (const pm of ctor.params.matchAll(/(\w+)\s+\$(\w+)/g)) { ctx.props[pm[2]] = pm[1]; ctx.knownClasses.add(pm[1]); }
    if (fn) {
      for (const pm of fn.params.matchAll(/(\w+)\s+\$(\w+)/g)) {
        if (/Request$/.test(pm[1]) && pm[1] !== 'Request') { ctx.request = pm[1]; }
        if (models.has(pm[1])) ctx.vars[pm[2]] = pm[1];
      }
      if (ctx.request) out.push(`${ctrl} -> ${ctx.request} : validation (FormRequest)`, `${ctx.request} --> ${ctrl} : données validées`);
      const seen = new Set();
      const walkNodes = (nodes, d) => {
        for (const n of nodes) {
          if (n.type === 'stmt' || n.type === 'return') {
            const vm = n.text.match(/^\$(\w+)\s*=\s*([A-Z]\w+)::/);
            if (vm && models.has(vm[2])) ctx.vars[vm[1]] = vm[2];
            for (const c of callsIn(n.text, ctx)) {
              seen.add(c.to);
              out.push(`${pad(d)}${ctrl} ${c.async ? '->>' : '->'} ${c.to} : ${c.label}`);
              if (c.ret) out.push(`${pad(d)}${c.to} --> ${ctrl} : ${c.ret}`);
            }
            if (n.type === 'return') {
              let label = summarize(n.text, RETURN_RULES).replace(/^return\s+/, '');
              if (label.length > 48) label = label.slice(0, 45) + '…';
              if (d === 1) finalReturn = label; else out.push(`${pad(d)}${ctrl} --> Utilisateur : ${label}`);
            }
          } else if (n.type === 'if') {
            n.branches.forEach((b, k) => { out.push(`${pad(d)}${k === 0 ? 'alt' : 'else'} ${condText(b.cond)}`); walkNodes(b.body, d + 1); });
            if (n.else) { out.push(`${pad(d)}else sinon`); walkNodes(n.else, d + 1); }
            out.push(`${pad(d)}end`);
          } else if (n.type === 'loop') {
            out.push(`${pad(d)}loop ${condText(n.cond)}`); walkNodes(n.body, d + 1); out.push(`${pad(d)}end`);
          } else if (n.type === 'try') {
            walkNodes(n.body, d);
            for (const c of n.catches) { out.push(`${pad(d)}opt erreur ${c.type.split(/\s+/)[0].split('\\').pop()}`); walkNodes(c.body, d + 1); out.push(`${pad(d)}end`); }
          }
        }
      };
      walkNodes(parseBlock(src, m, fn.start + 1, fn.end), 1);
      // Participants dans l'ordre d'apparition
      for (const s of seen) {
        const kind = models.has(s) ? 'entity' : /Request$/.test(s) ? 'control' : ['DB'].includes(s) ? 'database' : 'participant';
        lines.push(`${kind} ${s}`);
      }
      if (ctx.request && !seen.has(ctx.request)) lines.push(`control ${ctx.request}`);
    } else out.push(`note over ${ctrl} : méthode ${r.method}() introuvable`);
  } else out.push(`note over ${ctrl} : contrôleur introuvable`);
  out.push(`${ctrl} --> Utilisateur : ${finalReturn || 'réponse'}`);
  return [...lines, ...dropEmptyFragments(out), '@enduml', ''].join('\n');
}

// Retire les blocs alt / loop / opt qui ne contiennent aucun message (conditions sans appel visible).
function dropEmptyFragments(lines) {
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < lines.length; i++) {
      if (!/^\s*(alt|opt|loop)\b/.test(lines[i])) continue;
      let depth = 0, j = i + 1, hasMsg = false;
      for (; j < lines.length; j++) {
        const t = lines[j].trim();
        if (/^(alt|opt|loop|group|par)\b/.test(t)) depth++;
        else if (t === 'end') { if (depth === 0) break; depth--; }
        else if (depth === 0 && /-+>>?|<-/.test(t)) hasMsg = true;
        else if (depth > 0 && /-+>>?/.test(t)) hasMsg = true;
      }
      if (!hasMsg && j < lines.length) {
        // Bloc sans aucun message (toutes branches confondues) : supprimé entièrement
        lines.splice(i, j - i + 1);
        changed = true;
        break;
      }
    }
  }
  return lines;
}

// ---------- Diagramme de classes ----------
const snake = s => s.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase();
const plural = s => (/(s|x|ch|sh)$/.test(s) ? s + 'es' : /[^aeiou]y$/.test(s) ? s.slice(0, -1) + 'ies' : s + 's');

// Colonnes des tables d'après les migrations (create + table).
function migrationColumns(p) {
  const tables = {};
  const files = walk(path.join(p.path, 'database', 'migrations'), /\.php$/).sort();
  const TYPES = { id: 'bigint', bigIncrements: 'bigint', increments: 'int', foreignId: 'bigint', foreignUuid: 'uuid', string: 'string', char: 'string', text: 'text', longText: 'text', mediumText: 'text', integer: 'int', bigInteger: 'bigint', unsignedBigInteger: 'bigint', unsignedInteger: 'int', smallInteger: 'int', tinyInteger: 'int', boolean: 'bool', decimal: 'decimal', float: 'float', double: 'double', date: 'date', dateTime: 'datetime', timestamp: 'datetime', time: 'time', json: 'json', jsonb: 'json', uuid: 'uuid', enum: 'enum', year: 'int', binary: 'binary', ipAddress: 'string', rememberToken: 'string' };
  for (const f of files) {
    const src = read(f);
    for (const blk of src.matchAll(/Schema::(create|table)\(\s*['"](\w+)['"]\s*,\s*function\s*\([^)]*\)\s*\{([\s\S]*?)\n\s*\}\s*\)/g)) {
      const t = tables[blk[2]] || (tables[blk[2]] = []);
      for (const c of blk[3].matchAll(/\$table->(\w+)\(\s*(?:['"](\w+)['"])?/g)) {
        const [, fn, col] = c;
        if (fn === 'timestamps' || fn === 'timestampsTz' || fn === 'nullableTimestamps') { t.push({ name: 'created_at', type: 'datetime' }, { name: 'updated_at', type: 'datetime' }); continue; }
        if (fn === 'softDeletes') { t.push({ name: 'deleted_at', type: 'datetime' }); continue; }
        if (fn === 'id' && !col) { t.push({ name: 'id', type: 'bigint', pk: true }); continue; }
        if (fn === 'rememberToken') { t.push({ name: 'remember_token', type: 'string' }); continue; }
        if (fn === 'morphs' && col) { t.push({ name: col + '_id', type: 'bigint' }, { name: col + '_type', type: 'string' }); continue; }
        if (fn === 'dropColumn' && col) { const k = t.findIndex(x => x.name === col); if (k >= 0) t.splice(k, 1); continue; }
        if (TYPES[fn] && col && !t.some(x => x.name === col)) t.push({ name: col, type: TYPES[fn], fk: fn.startsWith('foreign') });
      }
    }
  }
  return tables;
}

function phpClasses(files) {
  const out = [];
  for (const f of files) {
    const src = read(f);
    const m = maskCode(src);
    const c = m.match(/\b(abstract\s+|final\s+)?(class|interface|trait|enum)\s+(\w+)(?:\s*:\s*\w+)?(?:\s+extends\s+([\w\\]+))?(?:\s+implements\s+([\w\\,\s]+))?\s*\{/);
    if (!c) continue;
    const open = c.index + c[0].length - 1;
    const close = matchClose(m, open);
    const body = src.slice(open + 1, close);
    const mb = m.slice(open + 1, close);
    const arr = name => { const r = body.match(new RegExp(`\\$${name}\\s*=\\s*\\[([\\s\\S]*?)\\]`)); return r ? [...r[1].matchAll(/['"](\w+)['"]\s*(?:=>\s*['"]?([\w:\\]+)['"]?)?/g)].map(x => ({ key: x[1], val: x[2] })) : []; };
    const methods = [];
    const relations = [];
    for (const fm of mb.matchAll(/\b(public|protected|private)?\s*(static\s+)?function\s+(\w+)\s*\(/g)) {
      const name = fm[3];
      const pOpen = fm.index + fm[0].length - 1;
      const params = clean(body.slice(pOpen + 1, matchClose(mb, pOpen)));
      const after = mb.slice(matchClose(mb, pOpen) + 1, matchClose(mb, pOpen) + 120);
      const ret = (after.match(/^\s*:\s*\??([\w\\|]+)/) || [])[1];
      const bOpen = mb.indexOf('{', matchClose(mb, pOpen));
      const fnBody = bOpen > 0 && !after.trim().startsWith(';') ? body.slice(bOpen, matchClose(mb, bOpen) + 1) : '';
      const rel = fnBody.match(/\$this->(hasMany|hasOne|belongsTo|belongsToMany|morphMany|morphOne|morphTo|morphToMany|morphedByMany|hasManyThrough|hasOneThrough)\(\s*([\w\\]+)::class/);
      const relTo = fnBody.match(/\$this->(morphTo)\(/);
      if (rel || relTo) { relations.push({ name, kind: (rel || relTo)[1], target: rel ? rel[2].split('\\').pop() : null }); continue; }
      if (/^(boot|booted|casts|getRouteKeyName|newFactory)$/.test(name)) continue;
      const vis = { public: '+', protected: '#', private: '-' }[fm[1] || 'public'];
      const shortParams = params.replace(/\$(\w+)(\s*=\s*[^,]+)?/g, '$1').replace(/[\w\\]+\\(\w+)/g, '$1');
      methods.push(`${vis}${fm[2] ? '{static} ' : ''}${name}(${shortParams.length > 40 ? '…' : shortParams})${ret ? ': ' + ret.split('\\').pop() : ''}`);
    }
    const props = [...mb.matchAll(/\b(public|protected|private)\s+(?:readonly\s+)?(?:static\s+)?(?:\??([\w\\]+)\s+)?\$(\w+)/g)]
      .filter(x => !['fillable', 'hidden', 'casts', 'guarded', 'table', 'appends', 'with', 'dates', 'primaryKey', 'keyType', 'incrementing', 'timestamps', 'connection', 'perPage', 'attributes', 'visible', 'touches', 'observables', 'dispatchesEvents'].includes(x[3]))
      .map(x => ({ vis: { public: '+', protected: '#', private: '-' }[x[1]], type: x[2] ? x[2].split('\\').pop() : null, name: x[3] }));
    // Propriétés promues du constructeur (PHP 8)
    const ctor = mb.match(/function\s+__construct\s*\(/);
    if (ctor) {
      const po = ctor.index + ctor[0].length - 1;
      for (const x of body.slice(po + 1, matchClose(mb, po)).matchAll(/(public|protected|private)\s+(?:readonly\s+)?\??([\w\\]+)\s+\$(\w+)/g)) props.push({ vis: { public: '+', protected: '#', private: '-' }[x[1]], type: x[2].split('\\').pop(), name: x[3], injected: true });
    }
    const traits = [...mb.matchAll(/^\s*use\s+([\w\\, ]+);/gm)].flatMap(x => x[1].split(',').map(s => s.trim().split('\\').pop()));
    out.push({
      file: f, kind: c[2], abstract: !!(c[1] && c[1].includes('abstract')), name: c[3],
      parent: c[4] ? c[4].split('\\').pop() : null, interfaces: c[5] ? c[5].split(',').map(s => s.trim().split('\\').pop()).filter(Boolean) : [],
      table: (body.match(/\$table\s*=\s*['"](\w+)['"]/) || [])[1] || null,
      fillable: arr('fillable').map(x => x.key), casts: Object.fromEntries(arr('casts').map(x => [x.key, x.val])),
      methods, relations, props, traits
    });
  }
  return out;
}

const MULT = { hasMany: ['1', '*'], hasOne: ['1', '1'], belongsTo: ['*', '1'], belongsToMany: ['*', '*'], morphMany: ['1', '*'], morphOne: ['1', '1'], morphToMany: ['*', '*'], morphedByMany: ['*', '*'], hasManyThrough: ['1', '*'], hasOneThrough: ['1', '1'] };

function classDsl(classes, { attributes = true, methods = true, columns = {}, title = 'Diagramme de classes', dependencies = false }) {
  const names = new Set(classes.map(c => c.name));
  const lines = ['@startuml', "' type: class", `title ${title}`];
  for (const c of classes) {
    const head = `${c.kind === 'interface' ? 'interface' : c.kind === 'enum' ? 'enum' : c.abstract ? 'abstract class' : 'class'} ${c.name}${c.stereo ? ` <<${c.stereo}>>` : ''}`;
    const members = [];
    if (attributes) {
      const cols = columns[c.table || plural(snake(c.name))];
      if (cols && cols.length) for (const col of cols) members.push(`  +${col.name}: ${c.casts && c.casts[col.name] ? c.casts[col.name].split(':')[0] : col.type}${col.pk ? ' {PK}' : col.fk ? ' {FK}' : ''}`);
      else for (const f of c.fillable || []) members.push(`  +${f}${c.casts && c.casts[f] ? ': ' + c.casts[f] : ''}`);
      for (const pr of c.props || []) members.push(`  ${pr.vis}${pr.name}${pr.type ? ': ' + pr.type : ''}`);
      for (const f of c.fields || []) members.push(`  ${c.kind === 'enum' ? '' : '+'}${f.name}${f.type ? ': ' + f.type : ''}`);
    }
    if (methods) {
      for (const r of c.relations || []) members.push(`  +${r.name}(): ${r.kind.charAt(0).toUpperCase() + r.kind.slice(1)}`);
      for (const mt of (c.methods || []).slice(0, 14)) members.push(`  ${mt}`);
      if ((c.methods || []).length > 14) members.push(`  … ${(c.methods.length - 14)} autres méthodes`);
    }
    lines.push(members.length ? `${head} {` : head, ...members, ...(members.length ? ['}'] : []));
  }
  const done = new Set();
  for (const c of classes) {
    if (c.parent && names.has(c.parent)) lines.push(`${c.parent} <|-- ${c.name}`);
    for (const i of c.interfaces || []) if (names.has(i)) lines.push(`${i} <|.. ${c.name}`);
    for (const r of c.relations || []) {
      if (!r.target || !names.has(r.target)) continue;
      const pair = [c.name, r.target].sort().join('|');
      const [a, b] = MULT[r.kind] || ['', ''];
      // Une seule association par couple : hasMany/hasOne d'un côté et belongsTo de l'autre décrivent la même relation.
      if (r.kind === 'belongsTo' && classes.some(o => o.name === r.target && (o.relations || []).some(x => x.target === c.name && /^has/.test(x.kind)))) continue;
      const key = `${pair}|${r.kind === 'belongsToMany' ? 'm2m' : r.name}`;
      if (done.has(key) || (r.kind === 'belongsToMany' && done.has(`${pair}|m2m`))) continue;
      done.add(key);
      lines.push(r.kind === 'belongsTo' ? `${r.target} "${b}" -- "${a}" ${c.name} : ${r.name}` : `${c.name} "${a}" ${r.kind.startsWith('belongsToMany') || r.kind === 'morphToMany' ? '--' : '-->'} "${b}" ${r.target} : ${r.name}`);
    }
    if (dependencies) for (const pr of (c.props || []).filter(x => x.injected && names.has(x.type))) lines.push(`${c.name} ..> ${pr.type} : utilise`);
    // Prisma : Post[] = un-à-plusieurs ; le champ inverse (author User) décrit la même relation et n'est pas redessiné.
    for (const r of c.prismaRels || []) {
      if (!names.has(r.target)) continue;
      const other = classes.find(o => o.name === r.target);
      const back = (other.prismaRels || []).find(x => x.target === c.name);
      if (!r.many && back && back.many) continue;
      const key = [c.name, r.target].sort().join('|') + '|prisma';
      if (r.many && back && back.many) { if (done.has(key)) continue; done.add(key); lines.push(`${c.name} "*" -- "*" ${r.target} : ${r.name}`); continue; }
      lines.push(r.many ? `${c.name} "1" --> "*" ${r.target} : ${r.name}` : `${c.name} "*" --> "1" ${r.target} : ${r.name}`);
    }
  }
  lines.push('@enduml', '');
  return lines.join('\n');
}

// Prisma : modèles, champs, relations
function prismaClasses(p) {
  const file = [path.join(p.path, 'prisma', 'schema.prisma'), ...walk(path.join(p.path, 'prisma'), /\.prisma$/)].find(f => fs.existsSync(f));
  if (!file) return null;
  const src = read(file);
  const models = [...src.matchAll(/^(model|enum)\s+(\w+)\s*\{([\s\S]*?)^\}/gm)];
  const names = new Set(models.map(m => m[2]));
  const modelNames = new Set(models.filter(m => m[1] === 'model').map(m => m[2]));
  void names;
  return models.map(m => {
    if (m[1] === 'enum') return { kind: 'enum', name: m[2], fields: m[3].split('\n').map(l => l.trim()).filter(l => /^\w+$/.test(l)).map(v => ({ name: v, type: '' })) };
    const fields = [], prismaRels = [];
    for (const l of m[3].split('\n')) {
      const f = l.trim().match(/^(\w+)\s+(\w+)(\[\])?(\?)?(.*)$/);
      if (!f || f[1].startsWith('@@')) continue;
      // Champ dont le type est un autre modèle : c'est une relation, pas un attribut
      if (modelNames.has(f[2])) { prismaRels.push({ name: f[1], target: f[2], many: !!f[3] }); continue; }
      fields.push({ name: f[1], type: f[2] + (f[3] || '') + (f[4] || '') + (/@id\b/.test(f[5]) ? ' {PK}' : '') });
    }
    return { kind: 'class', name: m[2], fields, prismaRels, stereo: 'Prisma' };
  });
}

// Classes et interfaces TypeScript
function tsClasses(p) {
  const files = walk(p.path, /\.(ts|tsx)$/, 1500).filter(f => !/\.d\.ts$/.test(f));
  const out = [];
  for (const f of files) {
    const src = read(f);
    const m = maskCode(src);
    for (const c of m.matchAll(/\b(?:export\s+)?(?:default\s+)?(abstract\s+)?(class|interface)\s+(\w+)(?:<[^>{]*>)?(?:\s+extends\s+([\w.]+)(?:<[^>{]*>)?)?(?:\s+implements\s+([\w,\s.<>]+))?\s*\{/g)) {
      const open = c.index + c[0].length - 1, close = matchClose(m, open);
      const body = src.slice(open + 1, close), mb = m.slice(open + 1, close);
      const fields = [], methods = [];
      // Texte de premier niveau : les corps de méthodes { ... } sont retirés, les paramètres ( ... ) gardés.
      let flat = '', depth = 0;
      for (let i = 0; i < mb.length; i++) {
        const ch = mb[i];
        if (ch === '{') { if (depth === 0) flat += ';'; depth++; continue; }
        if (ch === '}') { depth = Math.max(0, depth - 1); continue; }
        if (depth === 0) flat += body[i];
      }
      for (const raw of flat.split(/[;\n]/)) {
        const t = clean(raw.replace(/^@\w+(\([^)]*\))?\s*/, ''));
        if (!t) continue;
        const mm = t.match(/^(?:(?:public|private|protected|readonly|static|async|abstract|override|declare|get|set)\s+)*(\w+)(\?)?\s*(\(.*?\))?\s*(?::\s*([^=]+?))?\s*(?:=.*)?$/);
        if (!mm || /^(constructor|return|if|super|this)$/.test(mm[1])) continue;
        const vis = /\bprivate\b/.test(t) ? '-' : /\bprotected\b/.test(t) ? '#' : '+';
        if (mm[3]) methods.push(`${vis}${mm[1]}()${mm[4] ? ': ' + mm[4].trim().slice(0, 30) : ''}`);
        else fields.push({ name: mm[1] + (mm[2] || ''), type: (mm[4] || 'any').trim().slice(0, 30) });
      }
      out.push({ kind: c[2], abstract: !!c[1], name: c[3], parent: c[4] ? c[4].split('.').pop() : null, interfaces: c[5] ? c[5].split(',').map(s => s.trim().replace(/<.*$/, '')).filter(Boolean) : [], fields, methods, file: f });
      void close;
    }
  }
  return out;
}

function generateClass(p, opts = {}) {
  if (opts.lang !== 'tech') return Hm().classHuman(p, opts);
  const source = opts.source || (p.type === 'laravel' ? 'models' : 'typescript');
  let classes, title;
  if (source === 'prisma') {
    classes = prismaClasses(p);
    if (!classes) throw new Error('Fichier prisma/schema.prisma introuvable.');
    title = `Modèle de données (Prisma) : ${p.name}`;
  } else if (source === 'typescript') {
    classes = tsClasses(p);
    title = `Classes et interfaces : ${p.name}`;
  } else {
    const dir = source === 'models' ? path.join(p.path, 'app', 'Models') : path.join(p.path, opts.folder || 'app');
    const files = walk(fs.existsSync(dir) ? dir : path.join(p.path, 'app'), /\.php$/, 800);
    classes = phpClasses(files);
    if (source === 'models') classes = classes.filter(c => /Model|Authenticatable|Pivot|User/.test(c.parent || '') || c.relations.length || classes.some(o => o.parent === c.name));
    title = source === 'models' ? `Modèles : ${p.name}` : `Classes de ${opts.folder || 'app'} : ${p.name}`;
    for (const c of classes) if (['Authenticatable', 'Model', 'Pivot'].includes(c.parent)) c.stereo = c.parent === 'Model' ? null : c.parent;
  }
  if (!classes.length) throw new Error('Aucune classe trouvée pour cette source.');
  if (classes.length > 60) classes = classes.slice(0, 60);
  const columns = source === 'models' && opts.columns !== false ? migrationColumns(p) : {};
  return classDsl(classes, { attributes: opts.attributes !== false, methods: opts.methods !== false, columns, title, dependencies: source === 'folder' });
}

function sourceFiles(p) {
  return walk(p.path, /\.(php|js|jsx|ts|tsx|vue)$/, 3000).filter(f => !/\.(min|d)\.(js|ts)$/.test(f) && !/[\\/](database[\\/]migrations|config|lang)[\\/]/.test(f)).map(f => path.relative(p.path, f));
}

function functions(p, file) {
  const full = path.join(p.path, file);
  if (!full.startsWith(p.path) || !fs.existsSync(full)) throw new Error('Fichier introuvable.');
  return functionsOf(full).fns.map(f => ({ name: f.name, class: f.class, line: f.line, title: Hz.phrase(f.name, Hz.words(f.class || '')) || f.name }));
}

function sources(p) {
  return {
    laravel: p.type === 'laravel',
    models: fs.existsSync(path.join(p.path, 'app', 'Models')),
    prisma: fs.existsSync(path.join(p.path, 'prisma', 'schema.prisma')),
    typescript: fs.existsSync(path.join(p.path, 'tsconfig.json')),
    folders: ['app', 'app/Http/Controllers', 'app/Services', 'app/Models', 'src'].filter(d => fs.existsSync(path.join(p.path, d)))
  };
}

// ---------- Génération en lot ----------
const slug = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[{}]/g, '').replace(/[^\w]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase();
const sequenceName = r => `sequence-${r.verb.toLowerCase()}-${slug(r.uri) || 'racine'}`;
const activityName = (file, fn) => `activite-${path.basename(file).replace(/\.\w+$/, '')}-${fn}`;

// Actions de contrôleur appelées par les routes (une entrée par Contrôleur@méthode).
function actions(p) {
  const map = new Map();
  routes(p).forEach(r => {
    const key = `${r.controller}@${r.method}`;
    if (!map.has(key)) {
      const file = controllerFile(p, r.controller);
      map.set(key, { key, title: r.title, controller: r.controller.split('\\').pop(), method: r.method, file: file ? path.relative(p.path, file) : null, routes: [] });
    }
    map.get(key).routes.push(`${r.verb} ${r.uri}`);
  });
  return [...map.values()].filter(a => a.file);
}

/**
 * Génère plusieurs diagrammes d'un coup.
 * jobs : [{ kind: 'class', opts } | { kind: 'sequence', route } | { kind: 'activity', file, fn }]
 * Un diagramme existant est conservé, sauf si overwrite.
 */
function generateBatch(p, jobs, { overwrite = false, onProgress = () => {} } = {}) {
  const existing = new Set(list(p).map(d => d.name.toLowerCase()));
  const allRoutes = routes(p);
  const used = new Set();
  const result = { created: [], replaced: [], skipped: [], failed: [] };
  jobs.forEach((job, i) => {
    let name;
    try {
      const human = job.lang !== 'tech';
      if (human) name = job.kind === 'class' ? Hm().nameFor.class(job.opts) : job.kind === 'sequence' ? Hm().nameFor.sequence(p, job.route) : Hm().nameFor.activity(p, job.file, job.fn);
      else if (job.kind === 'class') name = job.name || `classes-${job.opts && job.opts.source === 'folder' ? slug(job.opts.folder) : (job.opts && job.opts.source) || 'projet'}`;
      else if (job.kind === 'sequence') name = sequenceName(allRoutes[job.route]);
      else name = activityName(job.file, job.fn);
      // Deux routes au même nom de fichier (ex. GET et HEAD) : suffixe
      name = safeName(name);
      let n = name, k = 2;
      while (used.has(n.toLowerCase())) n = human ? `${name} (${k++})` : `${name}-${k++}`;
      name = n;
      used.add(name.toLowerCase());
      onProgress({ i: i + 1, n: jobs.length, name });
      if (existing.has(name.toLowerCase()) && !overwrite) { result.skipped.push(name); return; }
      const lang = human ? 'human' : 'tech';
      const text = job.kind === 'class' ? generateClass(p, { ...(job.opts || {}), lang }) : job.kind === 'sequence' ? generateSequence(p, job.route, lang) : generateActivity(p, job.file, job.fn, lang);
      save(p, name, text);
      (existing.has(name.toLowerCase()) ? result.replaced : result.created).push(name);
    } catch (err) {
      result.failed.push({ name: name || `#${i + 1}`, error: err.message });
    }
  });
  return result;
}

// ---------- Export ----------
function exportPng(p, name, base64) {
  if (!p) throw new Error('Projet introuvable.');
  const data = Buffer.from(String(base64 || '').replace(/^data:image\/png;base64,/, ''), 'base64');
  // Image vide (navigateur à court de mémoire) : on le dit plutôt que d'écrire un fichier inutilisable.
  if (data.length < 100) throw new Error('L\'image générée est vide : le diagramme est probablement trop grand. Essaie l\'export PDF.');
  const n = safeName(name);
  fs.mkdirSync(umlDir(p), { recursive: true });
  const file = path.join(umlDir(p), n + '.png');
  try { fs.writeFileSync(file, data); }
  catch (err) { throw new Error(err.code === 'EBUSY' || err.code === 'EPERM' ? 'Le fichier PNG est ouvert dans un autre programme : ferme-le puis réessaie.' : err.message); }
  return { file };
}

// PDF : la page SVG est imprimée par Edge (sans en-tête ni pied de page), au format exact du diagramme.
function exportPdf(p, name, svg, width, height, edge) {
  return new Promise((resolve, reject) => {
    if (!p) return reject(new Error('Projet introuvable.'));
    if (!edge) return reject(new Error('Microsoft Edge (ou Chrome) est nécessaire pour l\'export PDF.'));
    const n = safeName(name);
    fs.mkdirSync(umlDir(p), { recursive: true });
    const file = path.join(umlDir(p), n + '.pdf');
    const w0 = Math.ceil(Number(width) || 800), h0 = Math.ceil(Number(height) || 600);
    // Une page PDF ne dépasse pas 200 pouces (19 200 px) : un très grand diagramme est réduit pour tenir sur la page.
    const k = Math.min(1, 19000 / Math.max(w0, h0));
    const w = Math.ceil(w0 * k), h = Math.ceil(h0 * k);
    const tmp = path.join(os.tmpdir(), `devlauncher-uml-${Date.now()}`);
    fs.mkdirSync(tmp, { recursive: true });
    const html = path.join(tmp, 'diagramme.html');
    fs.writeFileSync(html, `<!doctype html><meta charset="utf-8"><style>@page{size:${w}px ${h}px;margin:0}html,body{margin:0;background:#fff}svg{display:block;width:${w}px;height:${h}px}</style>${String(svg)}`);
    try { fs.rmSync(file, { force: true }); }
    catch { return reject(new Error('Le fichier PDF est ouvert dans un autre programme (lecteur PDF) : ferme-le puis réessaie.')); }
    // Délai large : Edge peut être lent à démarrer sur un PC chargé ou juste après une installation.
    execFile(edge, ['--headless=new', '--disable-gpu', '--no-pdf-header-footer', '--print-to-pdf-no-header', '--no-first-run', '--no-default-browser-check',
      `--user-data-dir=${path.join(tmp, 'profil')}`, `--print-to-pdf=${file}`, 'file:///' + html.replace(/\\/g, '/')],
      { windowsHide: true, timeout: 150000 }, err => {
        try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* fichiers temporaires encore verrouillés */ }
        if (fs.existsSync(file) && fs.statSync(file).size > 0) return resolve({ file, scaled: k < 1 });
        reject(new Error(err && err.killed ? 'Edge n\'a pas répondu à temps (plus de 2 min 30) : réessaie, ou exporte en PNG.'
          : `La génération du PDF a échoué${err && err.message ? ' (' + err.message.split('\n')[0].slice(0, 160) + ')' : ''}.`));
      });
  });
}

module.exports = { list, readDiagram, save, remove, routes, sourceFiles, functions, sources, generateClass, generateSequence, generateActivity, actions, generateBatch, sequenceName, activityName, exportPng, exportPdf, umlDir, parseBlock, maskCode, functionsOf,
  controllerFile, dropEmptyFragments, prismaClasses, tsClasses, phpClasses, walk, migrationColumns, plural, snake, MULT };
