// Chargé dans <head>, avant tout affichage : applique le thème enregistré (l'écran d'ouverture ne clignote pas en clair).
try { if (localStorage.getItem('theme') === 'dark') document.documentElement.dataset.theme = 'dark'; } catch { /* stockage indisponible */ }
